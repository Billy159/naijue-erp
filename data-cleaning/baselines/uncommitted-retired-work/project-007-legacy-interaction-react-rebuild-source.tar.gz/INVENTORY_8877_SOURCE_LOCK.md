# 库存模块 8877 工程源码锁定清单

读取对象：`outputs/ERP-V2-Demo-V1/ui-structure-prototype/` 中由 `index.html` 实际加载的文件；不是归档源码或截图。基础渲染来自 `inventory-workbench.js`，最后由 `inventory-matrix-experiment.js` 的捕获阶段事件和矩阵渲染增强，再受 `real-data-bridge.mjs` 的真实 API 数据覆盖。CSS 按 `index.html` 加载顺序层叠；下列尺寸不采用单张截图估算。

## 页面与数据结构

| 顺序 | 源码 | 锁定行为 |
| --- | --- | --- |
| 页头 | `inventory-workbench.js:36` | 左侧 20px/600 的“库存状况表”；右侧导出、刷新、更多操作。`inventory-matrix-experiment.js:28` 后插入扫码，**本轮用户裁决移除**。 |
| 主筛选 | `inventory-workbench.js:32` | 商品同框关键词与批量选择 → 分类树 → 仓库多选 → 更多筛选 → 查询 → 重置；关键词后置占位由 `inventory-matrix-experiment.js:28` 改为“输入货号后几位／商品名称”。 |
| 商品联想最终实现 | `inventory-matrix-experiment.js:3,9,40` → `product-finder.js:5–22` → `entry-shared.css:1–3` | 输入时捕获阶段调用共享 `PRODUCT_FINDER`，覆盖 `inventory-workbench.js:49` 的早期单列候选。浮层上限 **660px 宽、350px 高**，锚点下方 4px，空间不足上翻；两栏比例 **1.4fr : 1fr**。左侧最多先显示 8 条，按准确条码/完整款号→尾号→前缀→中间片段→名称→货品条码匹配分级，再按款号排序；空关键词在输入事件后返回按款号排序的前 8 个商品；每条款号与名称并列，命中词高亮。右侧随鼠标或上下键高亮切换，显示图片状态、款号、商品名、颜色、分类、年份、季节、版型、供应商、零售价等**来源已提供**字段，空值行省略。底部“查看更多匹配”每次加 20 条；键盘越过第 8 项时自动增加显示上限。选择候选立即查询该商品；未选择时 Enter 执行当前关键词查询；Escape/Tab/外点关闭，输入法组合中不得误提交。无关键字聚焦时 `inventory-matrix-experiment.js:11–14` 显示最近 15 条搜索历史，历史浮层**等宽于输入框**而非 660px；历史项、删除和清空按钮高 32px。 |
| 附加筛选 | `inventory-workbench.js:32`、`inventory-matrix-experiment.js:42` | 供应商、版型、季节依序呈现；后置捕获事件将三者变成**多选**，仓库也使用多选实体浮层。未执行查询前只更新草稿并显示提示。 |
| 结果工具 | `inventory-workbench.js:33` | 当前结果范围、款数、仓库数、库存合计；右侧展开全部、折叠全部、显示设置。折叠作用于当前页；范围由已执行查询而非草稿决定。 |
| 矩阵 | `inventory-matrix-experiment.js:22–24`、`inventory-workbench.js:60–65`、`product-current.js:83` | 按正式尺码组分段；每段列为商品名称／款号 240、颜色 92、仓库 110、该组尺码各 76、合计 76、操作 110。每条仓库明细同一行显示商品、颜色、仓库；之后颜色小计、商品合计。商品与颜色分别可折叠，折叠后为对应汇总行。尺码组标题默认隐藏。商品列前 240、颜色列随后 92、仓库列随后 110 sticky；合计与操作固定在右。`detailValue` 对本商品该尺码列无可用 SKU 时显示**0**，有 SKU 但库存来源未知时显示“未知”；小计 `reduce(...,0)` 也显示 **0**。只有真实有效 SKU 的数量格可点击流水；操作列调用 `openPhoto`，后者调用 `TRANSFER_UI.openProductDetail`，该函数首先 `return PRODUCT_UI.openReadOnly`，因此实际在**新浏览器标签页**打开只读商品详情，原库存页的滚动与条件保留。 |
| 显示设置 | `inventory-workbench.js:44`、`inventory-matrix-experiment.js:43–44` | 辅助字段：分类、供应商、版型、尺码组、季节；汇总：颜色小计、商品合计、显示尺码组说明。默认分类/两级小计开，其余关。勾选立即生效、偏好保存本地；恢复默认。版型显示切换会重新查询真实结果。 |
| 分页 | `inventory-workbench.js:35,73–94` | 底部依次为每页数 100/200/500、当前范围和总明细条数；有多页时上一页、当前页/总页、跳至页码、跳转、下一页。切页重置矩阵滚动位置。错误页码反馈；Enter 可跳转。真实模式由服务端分页。 |
| 导出 | `inventory-matrix-experiment.js:30,35` | “导出库存”弹窗，默认库存明细与银泰库存模板二选一；说明按当前已执行条件**导出全量、不受分页影响且不含小计**。确认时全量读取，再下载；失败在弹窗内重试。默认表按尺码组分段、仓库明细逐行；银泰按颜色/尺码合并所选仓库并保留版型条码。 |
| 打印 | `inventory-matrix-experiment.js:38` | 更多操作 → 打印 → 全量查询结果的“库存打印预览”弹窗及 iframe → 打印/关闭；打印不局限当前页。 |
| 库存流水 | `gold.js:29–31`、`real-data-bridge.mjs:76` | 点击有效尺码数量格打开右侧 880px Drawer。身份摘要之后是开始/结束日期 → 业务类型 → 来源单号 → 查询；下方六列表头为时间、业务类型、变化、变化前→后、来源单据、操作人。20 条一页、上一页/页数/下一页；来源销售/调拨进入真实单据，历史进货仅只读预览。`inventory-workbench.css:26` 把流水行压到 26px，内边距 3px 6px。 |

## 事件和键盘锁定

- `inventory-workbench.js:73–90`：所有 `data-i` 点击动作、分类展开/选中、批量选择/全选搜索结果/清空/确认、仓库确认非空、查询/重置/刷新/重试、汇总折叠、流水与页码。
- `inventory-workbench.js:91–97`：关键词输入出现候选，弹层搜索，设置与勾选，Enter 搜索或页码跳转、Escape 关闭、上下箭头移动、Enter 切换勾选；数量格 Enter/空格打开流水。页面和视口变化关闭或重定位浮层。
- `inventory-matrix-experiment.js:40–44`：捕获阶段接管输入法组合过程、关键词 Enter、查询、供应商/版型/季节多选、仓库多选、导出模板、全量打印、显示设置默认恢复。它覆盖早期同名处理，应以此最后行为为准。
- `inventory-workbench.js:21`：请求序号丢弃过期结果，执行查询后清空折叠并回到第一页，刷新保留当前查询与页码；错误保留上一次成功结果。新 React 继续使用共有的 `usePagedQuery` Abort/stale 机制。
- `inventory-workbench.js:18,29,64`：用户同时保留已选款号与输入新关键词时，执行查询前 `queryDraft()` 清空已选款号，按新关键词查询；候选单选则立即查询已选款号。商品详情操作在新标签页只读打开，不能替换库存当前页。

## 源码尺寸与层叠结果

`inventory-workbench.css:8–17,46–61`：工作区单列，标题行 32 高、下距 8；主筛选最终是 **`minmax(280px,2.8fr) minmax(135px,1fr) minmax(135px,1fr) 116px 58px 82px`** 六列，间隔 8；商品框 32 高；附加筛选 `grid` 四列、宽度为主筛选宽减 280px、上距 8/下距 2；结果工具至少 36；结果区独立滚动；分页至少 40，后置 `ui-review.css:29` 将分页间隔改为 8px；选择浮层内选项至少 32。低于 1100px 时主筛选换为三列，并把三个动作**作为同一 flex 组**移到下一行，宽度依次 116/58/82、间隔 8；低于 740px 时两列。`styles.css:173–180` 还把 1100px 以下侧栏改为 184px、页面左右间距改为 12px，760px 以下侧栏改为 156px、页面间距 10px。默认附加筛选收起，截图中展开态需用同一状态做验收。

`entry-shared.css:1–3`：联想列表按钮上下 padding 9px、左右 10px、`font-size:13px`、款号 `font-weight:700`；预览右栏 padding 10px、行间隔 6px、左边框 1px，预览标签 `12px/18px`；无图提示高 70px。`inventory-workbench.css:63` 进一步把预览最大高度限制为 330px；小于 700px 时改成上下栏。运行时继承 `Arial, "PingFang SC", "Microsoft YaHei", sans-serif`，不可被 Stage05 的 Inter 字体覆盖。

`matrix-experiments.css:1–13` 定义矩阵列固定宽、sticky、表头和数据高 36、字体继承、折叠图标及小计背景；`interaction-common.css:5` 后置把单元格上下 padding 从 5 改成 **4px**，左右仍为 8px。`ui-review.css`、`final-ui.css` 继续约束全局控件、颜色与分页。颜色在 React 只取 Theme 1376。

已运行 8877 的 `getComputedStyle` 与矩形见 `evidence/legacy-8877/runtime-source-trace-1440.json`，用于确认源码层叠：侧栏 208，顶栏 45，页面内边距 12/16/16，主筛选控件 32，标题 20/600，表头约 36，单元格最终 4px 8px。`LEGACY_8877_TYPOGRAPHY_METRICS.md` 与 `LEGACY_8877_LAYOUT_METRICS.md` 保存其余可核查值。截图仅为模块完成后的视觉验收证据。

## 用户裁决和业务事实

库存扫码按钮移除；单一关键词框额外解析空格、换行、逗号分隔的多个款号，保留批量选择；不显示负库存解释徽标；五个正式业务尺码组依商品分段；历史 SKU 及未知数据保持真实；查询与导出必须使用真实 API、服务端分页和真实 SKU 投影。与 8877 前端实现不同处记录于 `LEGACY_REBUILD_DIFF.md`。
