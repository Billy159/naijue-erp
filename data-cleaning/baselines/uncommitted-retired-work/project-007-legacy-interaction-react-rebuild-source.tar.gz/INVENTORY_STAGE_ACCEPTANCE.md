# 库存模块阶段验收（8877 源码驱动）

范围：`/inventory` 的源码清单、React + Arco 实现和同状态浏览器核对。本记录是模块阶段结果；全站重建、终验、提交和冻结 Tag 尚未完成。

## 被指出的商品联想差异

正式生效链为 `inventory-matrix-experiment.js` 捕获输入 → `product-finder.js` → `entry-shared.css`，早期 `inventory-workbench.js` 单列候选已被覆盖。新版现为双栏：左侧款号/名称及高亮，右侧随选中项变化的商品字段；包含 8 条初显、每次增加 20 条、键盘越界扩展、Enter/Escape/Tab/输入法处理和等宽历史搜索浮层。

以 `026` 为样本，两版前 8 个候选的款号与顺序一致。使用 8877 页面与 React 页面运行时的 DOM/计算样式核对，双栏浮层在三个视口均为 660×338，位置如下：

| 视口 | 8877 浮层 | React 浮层 | 主查询行/结果区 |
| --- | --- | --- | --- |
| 1440×900 | x225 y133 | x225 y133 | 均为查询 x224 y97 w1200；结果 x224 y233 |
| 1280×800 | x225 y133 | x225 y133 | 均为查询宽 1040、结果高 516 |
| 1024×768 | x197 y133 | x197 y133 | 均为侧栏 184、查询 x196 w816、结果 x196 y313 h404 |

联想列表单行 37.5px、字号 13px、款号字重 700；预览标签 12px/18px；预览右栏 padding 10px、间隔 6px。空输入聚焦时历史浮层与输入框等宽，历史按钮 32px 高。1024px 时主查询动作按源码集中在第二行，依次为 x196/w116、x320/w58、x386/w82。分页恢复旧版按钮与跳页顺序，1024px 下其末组从 x624 起，各按钮、文字和页码框位置与 8877 相同（允许小于 0.2px 的字体小数差）。

## 同状态阶段截图

各组均为同视口、筛选展开、输入 `026`、候选双栏展开，业务数据显示各自来源；旧版扫码按钮按用户新裁决在 React 中移除。

| 视口 | 8877 | React |
| --- | --- | --- |
| 1440×900 | [8877](evidence/legacy-rebuild/screenshots/1440x900/inventory-8877-stage.png) | [React](evidence/legacy-rebuild/screenshots/1440x900/inventory-react-stage.png) |
| 1280×800 | [8877](evidence/legacy-rebuild/screenshots/1280x800/inventory-8877-stage.png) | [React](evidence/legacy-rebuild/screenshots/1280x800/inventory-react-stage.png) |
| 1024×768 | [8877](evidence/legacy-rebuild/screenshots/1024x768/inventory-8877-stage.png) | [React](evidence/legacy-rebuild/screenshots/1024x768/inventory-react-stage.png) |

## 真实数据与已执行功能核对

- 8878 `runtime/catalog` 有 2941 款。其 `year` / `season` 直接字段为空，但 `historicalCategory` 保留原“所属类别”；新版按 8877 `adapter.mjs:12–16` 同一明确解析规则展示与筛选年份、季节。联想按 `product-finder.js` 的货号、名称及明确条码排序，`026` 为 21 项，与 8877 一致。
- 真实库存全量读取为 9863 条明细、库存合计 80794。选中 `0002` 可查得 1 款、2 条仓库明细、合计 15；库存数量格进入真实流水 Drawer；操作图标在新标签打开只读商品页。
- 默认/银泰两种 XLSX 已经在浏览器实际下载核对，款号 `0002` 保持文本类型与前导零；打印预览使用当前已执行筛选的全部结果，非当前页。
- 最新代码的 typecheck、`build:legacy`、客户端定向测试 10 项通过。全站测试与逐页终验仍需后续阶段执行。

## 留待全站终验的事实

年份、季节已从原“所属类别”中的明确字样解析，并保持来源可追溯。其他模块仍有 Stage05 迁入页面，不能以本模块截图或测试宣称全站 PASS，也不创建最终冻结 Tag。
