# LEGACY 8877 Layout Metrics

先从 `index.html` 实际加载的 CSS 顺序和声明提取控件宽高、列宽、padding、margin、gap、边框与圆角，规则和源码行号见 `evidence/legacy-8877/source-map.json`；再以 1440×900 运行页面的 `getBoundingClientRect()` / `getComputedStyle()` 核对层叠结果。源码与运行差异见 [LEGACY_8877_SOURCE_LOCK.md](LEGACY_8877_SOURCE_LOCK.md)。下表单位均为 CSS px，原始含 x/y/position 和匹配规则值见 `evidence/legacy-8877/runtime-source-trace-1440.json`、`metrics-1440.json`；截图只供视觉验收。

| 页面 | 元素 | 宽×高 | padding | margin | gap | border-width | border-radius |
| --- | --- | ---: | --- | --- | --- | --- | --- |
| inventory | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| inventory | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| inventory | main | 1232×860 | 12px 16px 16px | 0px | normal | 0px | 0px |
| inventory | section | 1200×96 | 0px | 0px 0px 4px | normal | 0px | 0px |
| inventory | input | 455.3×32 | 4px 6px | 0px | normal | 0px | 4px |
| inventory | button | 85×32 | 4px 9px | 0px | 6px | 1px | 4px |
| inventory | table | 1464×11345.5 | 0px | 0px | normal | 0px | 0px |
| inventory | th | 240×36 | 4px 8px | 0px | normal | 0px 0px 1px | 0px |
| inventory | td | 240×55 | 4px 8px | 0px | normal | 0px 0px 1px | 0px |
| inventory | tr | 1464×55 | 0px | 0px | normal | 0px | 0px |
| inventory | pagination | 59×32 | 4px 9px | 0px | 6px | 1px | 4px |
| transfer-list | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| transfer-list | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| transfer-list | main | 1232×877.2 | 12px 16px 16px | 0px | normal | 0px | 0px |
| transfer-list | section | 1200×849.2 | 0px | 0px | normal | 0px | 0px |
| transfer-list | input | 125×32 | 4px 9px | 0px | normal | 1px | 4px |
| transfer-list | button | 85×32 | 4px 9px | 0px 0px 0px 1007px | 6px | 1px | 4px |
| transfer-list | table | 1238.1×812 | 0px | 0px | normal | 0px | 0px |
| transfer-list | th | 146.5×32 | 4px 10px | 0px | normal | 0px 0px 1px | 0px |
| transfer-list | td | 146.5×39 | 4px 10px | 0px | normal | 0px 0px 1px | 0px |
| transfer-list | tr | 1238.1×39 | 0px | 0px | normal | 0px | 0px |
| transfer-list | pagination | 55×28 | 2px 7px | 0px | 6px | 1px | 4px |
| transfer-new | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| transfer-new | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| transfer-new | main | 1232×852 | 12px 16px 16px | 0px | normal | 0px | 0px |
| transfer-new | section | 1200×824 | 0px | 0px | normal | 0px | 0px |
| transfer-new | input | 160×32 | 4px 9px | 0px | normal | 1px | 4px |
| transfer-new | select | 131×32 | 4px 9px | 0px | normal | 1px | 4px |
| transfer-new | button | 72×32 | 4px 9px | 0px | 6px | 1px | 4px |
| transfer-new | table | 1198×41 | 0px | 0px | normal | 0px | 0px |
| transfer-new | td | 240×40.5 | 4px 8px | 0px | normal | 0px 0px 1px | 0px |
| transfer-new | tr | 1198×40.5 | 0px | 0px | normal | 0px | 0px |
| sales-list | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| sales-list | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| sales-list | main | 1232×1040 | 12px 16px 16px | 0px | normal | 0px | 0px |
| sales-list | section | 1200×1012 | 0px | 0px | 16px | 0px | 0px |
| sales-list | input | 140×34 | 4px 9px | 0px | normal | 1px | 4px |
| sales-list | select | 140×34 | 4px 48px 4px 9px | 0px | normal | 1px | 4px |
| sales-list | button | 89×32 | 0px 11px | 0px | 6px | 1px | 4px |
| sales-list | table | 1309.8×1436.9 | 0px | 0px | normal | 0px | 0px |
| sales-list | th | 126.6×40.5 | 11px 12px | 0px | normal | 0px 0px 1px | 0px |
| sales-list | td | 126.6×69.8 | 11px 12px | 0px | normal | 0px 0px 1px | 0px |
| sales-list | tr | 1309.8×69.8 | 0px | 0px | normal | 0px | 0px |
| sales-list | pagination | 63×32 | 0px 11px | 0px | 6px | 1px | 4px |
| sales-new | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| sales-new | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| sales-new | main | 1232×703.2 | 12px 16px 16px | 0px | normal | 0px | 0px |
| sales-new | section | 1200×675.2 | 0px | 0px | 10px | 0px | 0px |
| sales-new | input | 185.7×34 | 4px 9px | 6px 0px 0px | normal | 1px | 4px |
| sales-new | select | 185.7×34 | 4px 48px 4px 9px | 0px | normal | 1px | 4px |
| sales-new | button | 76×32 | 0px 11px | 0px | 6px | 1px | 4px |
| sales-new | table | 1198×74.5 | 0px | 0px | normal | 0px | 0px |
| sales-new | th | 310×36 | 8px | 0px | normal | 0px 0px 1px | 0px |
| sales-new | td | 310×38 | 3px 8px | 0px | normal | 0px 0px 1px | 0px |
| sales-new | tr | 1198×38 | 0px | 0px | normal | 0px | 0px |
| products | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| products | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| products | main | 1232×387.7 | 12px 16px 16px | 0px | normal | 0px | 0px |
| products | section | 1200×177.5 | 0px | 0px | normal | 1px | 6px |
| products | input | 624×32 | 5px 8px | 0px | normal | 1px | 4px |
| products | select | 128×32 | 5px 8px | 0px | normal | 1px | 4px |
| products | button | 76×32 | 0px 11px | 0px | 6px | 1px | 4px |
| products | table | 1198×85.5 | 0px | 0px | normal | 0px | 0px |
| products | th | 176.2×36 | 4px 10px | 0px | normal | 0px 0px 1px | 0px |
| products | td | 176.2×49.5 | 4px 10px | 0px | normal | 0px 0px 1px | 0px |
| products | tr | 1198×49.5 | 0px | 0px | normal | 0px | 0px |
| products | pagination | 63×32 | 0px 11px | 0px | 6px | 1px | 4px |
| product-settings | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| product-settings | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| product-settings | main | 1232×7332.5 | 12px 16px 16px | 0px | normal | 0px | 0px |
| product-settings | section | 1200×7260.5 | 0px | 0px | normal | 1px | 6px |
| product-settings | input | 240×32 | 5px 8px | 0px | normal | 1px | 4px |
| product-settings | button | 88×35.5 | 7px 14px | 0px | normal | 0px 0px 2px | 0px |
| product-settings | table | 1166×7134 | 0px | 0px | normal | 0px | 0px |
| product-settings | th | 528×36 | 4px 10px | 0px | normal | 0px 0px 1px | 0px |
| product-settings | td | 528×39 | 4px 10px | 0px | normal | 0px 0px 1px | 0px |
| product-settings | tr | 1166×39 | 0px | 0px | normal | 0px | 0px |
| stores | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| stores | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| stores | main | 1232×1938.5 | 12px 16px 16px | 0px | normal | 0px | 0px |
| stores | section | 1200×1910.5 | 0px | 0px | normal | 0px | 0px |
| stores | input | 260×32 | 5px 8px | 0px | normal | 1px | 4px |
| stores | button | 76×32 | 0px 11px | 0px | 6px | 1px | 4px |
| stores | table | 1198×1756.5 | 0px | 0px | normal | 0px | 0px |
| stores | th | 182.4×36 | 6px 10px | 0px | normal | 0px 0px 1px | 0px |
| stores | td | 182.4×43 | 6px 10px | 0px | normal | 0px 0px 1px | 0px |
| stores | tr | 1198×43 | 0px | 0px | normal | 0px | 0px |
| fund-accounts-new-dialog | sidebar | 208×900 | 16px 10px | 0px | normal | 0px 1px 0px 0px | 0px |
| fund-accounts-new-dialog | topbar | 1232×45 | 6px 16px | 0px | 12px | 0px 0px 1px | 0px |
| fund-accounts-new-dialog | main | 1232×3658.5 | 12px 16px 16px | 0px | normal | 0px | 0px |
| fund-accounts-new-dialog | section | 1200×3630.5 | 0px | 0px | normal | 0px | 0px |
| fund-accounts-new-dialog | input | 260×32 | 5px 8px | 0px | normal | 1px | 4px |
| fund-accounts-new-dialog | button | 76×32 | 0px 11px | 0px | 6px | 1px | 4px |
| fund-accounts-new-dialog | table | 4075×3476.5 | 0px | 0px | normal | 0px | 0px |
| fund-accounts-new-dialog | th | 215.8×36 | 6px 10px | 0px | normal | 0px 0px 1px | 0px |
| fund-accounts-new-dialog | td | 215.8×43 | 6px 10px | 0px | normal | 0px 0px 1px | 0px |
| fund-accounts-new-dialog | tr | 4075×43 | 0px | 0px | normal | 0px | 0px |
| fund-accounts-new-dialog | modal | 840×407.2 | 24px | 246.398px 300px 246.406px | normal | 1px | 6px |
| fund-accounts-new-dialog | modalTitle | 96×24 | 0px | 0px | normal | 0px | 0px |
| fund-accounts-new-dialog | modalLabel | 385×56.5 | 0px | 0px | 5px | 0px | 0px |
| fund-accounts-new-dialog | modalButton | 30×32 | 5px | 0px | 6px | 0px | 4px |

## 全站关键定位

- 侧栏 208px、sticky、全视口高；顶部条 45px；主内容使用剩余宽度，内边距 12px 16px 16px。
- 基础资料 Modal 宽 840px，固定居中，padding 24px，边框 1px，圆角 6px；标题 16px/600/24px。
- 表格密度按页面：库存表头 36px/数据首行 55px；调拨列表 32px/39px；销售列表约 40.5px/69.8px；商品列表 36px/49.5px；基础资料 36px/43px。
- 1024×768 下旧版筛选会换行，侧栏仍在；表格在内容区域内部水平滚动，不让整个页面横向滚动。见三视口截图。
- 圆角需按元素而非 Theme 默认值：普通按钮和输入常见 4px，侧栏选中项 3px，基础资料 Modal 6px。
- 旧版 Drawer padding：已走查页面未出现 Drawer，暂无可验证数值；正式版不应凭空套入 Drawer。
