# 8877 Golden Master：工程源码锁定

读取日期：2026-09-24。源码根目录为原项目的 `outputs/ERP-V2-Demo-V1/ui-structure-prototype/`。8877 的 Python HTTP 服务以该目录为工作目录，服务返回的 `index.html` SHA-256 与磁盘一致：`cba5c8938257d58b58b66083e9dafe8f6ae013f526f309b6a089b143c38d6539`。本文件先记录源码，再记录运行结果。`evidence/legacy-8877/source-map.json` 按 `index.html` 的真实加载顺序保存 14 个 CSS、43 个 JS/MJS 的哈希、1235 条 CSS 尺寸/排版规则、628 个具名函数和 175 个事件监听。生成方法为 `node evidence/legacy-8877/extract-source.cjs`。

## 加载和渲染顺序

`index.html:1–17` 给出侧栏、一级/二级导航、`#page`、顶部面包屑、两个初始 dialog，以及全部资源加载顺序。脚本主要渲染链：`app.js:11` 初始路由 → `gold.js:12` 库存/早期调拨 → `product-current.js:85` 商品 → `transfer-current.js:53` 正式调拨 → `sales-current.js:56` 销售 → `inventory-matrix-experiment.js:29` 库存矩阵增强 → `basic-settings.js:27` 账户/权限/六个基础资料页面 → `real-data-bridge.mjs:7` 异步真实数据守门与商品、单据加载。`real-data-bridge.mjs` 是最后加载的 module，不能把之前的示例数据行为当作最终运行行为。

CSS 顺序由 `index.html:1` 确定：`ui-tokens.css`、`styles.css`、`gold.css`、`product-current.css`、`inventory-workbench.css`、`transfer-current.css`、`sales-current.css`、`entry-shared.css`、`matrix-experiments.css`、`interaction-common.css`、`sales-returns.css`、`basic-settings.css`、`ui-review.css`、`final-ui.css`，另有 `index.html` 内联样式和脚本注入样式。计算值应按完整层叠结果读取，不能取任一较早 CSS 文件的声明作为最终值。

## 15 个主入口的源码结构与事件

| 路由 | 页面/字段/列顺序来源 | 事件与状态来源 | 主要布局来源 |
| --- | --- | --- | --- |
| `#inventory` | `inventory-workbench.js:32–36` 查询、统计、结果、分页；`inventory-matrix-experiment.js:24–28` 尺码矩阵与后置按钮 | `inventory-workbench.js:73–97` 查询、批量/分类/仓库浮层、折叠、页码、流水、导出/打印和键盘；`inventory-matrix-experiment.js:40–44` 输入联想、扫码入口、矩阵操作 | `styles.css:19–73`、`inventory-workbench.css:8–17`、`matrix-experiments.css:1–13`、`interaction-common.css:5` |
| `#transfer` | `transfer-current.js:70` 日期、单号、调出/调入、状态、表列和分页 | `transfer-current.js:124–149` 查询、选择、单据查看、翻页、草稿保护 | `transfer-current.css:4–11,25–26` |
| `#transfer/new` | `transfer-current.js:74–75` 单据头及明细；`transfer-matrix-experiment.js:12–18,35–37` 分组矩阵、追加行和批量弹层 | `transfer-current.js:118,124–149` 保存/审核/弃审/删除、租约、扫描与键盘；`transfer-matrix-experiment.js:40–50` 批量、替换、数量输入 | `transfer-current.css:12–20,26–27`、`matrix-experiments.css` |
| `#sales` | `sales-current.js:37` 快筛、日期/关键字/业务类型/状态/营业厅/营业员、更多筛选、表列、页脚 | `sales-current.js:27,85–115` 查询、快筛、翻页、查看和未审核编辑 | `sales-current.css:1–8`、`final-ui.css:4` |
| `#sales/new` | `sales-current.js:53` 页头、业务类型→营业厅→出库仓→营业员→客户→日期→调整金额→资金→明细→备注→汇总；`sales-current.js:40,46` 商品行与退换分区 | `sales-current.js:59–74,85–115,119–164` 批量、扫描、行内编辑、保存/审核/弃审、草稿与键盘；`real-data-bridge.mjs:59–67` 0..N 支付记录 | `sales-current.css:1–12`、`matrix-experiments.css:24–26`、`final-ui.css:4,6,8` |
| `#products` | `product-current.js:26` 找商品→年份→分类→季节→更多筛选→查询/重置，九列表头和分页 | `product-current.js:88–123` 搜索、分页、详情、草稿离开保护 | `product-current.css:2–7,13–16,50–52` |
| `#product-categories` | `product-current.js:19,43` 左树、右编辑、一级/子分类 | `product-current.js:48,88–123` 节点、展开、排序、保存和删除确认 | `product-current.css:4–8,36–42` |
| `#product-settings` | `product-current.js:54` 颜色→尺码组→版型→季节→商品属性五页签及各表列 | `product-current.js:60–62,80–81,88–123` 字典编辑、历史尺码弹层、页签、拖动 | `product-current.css:8,21,50,54` |
| `#barcode-schemes` | `product-current.js:58–59,63` 方案表、查看详情 | `product-current.js:88–107` 查看方案 | `product-current.css:21`、`styles.css` |
| `#settings/stores` | `basic-settings.js:10–18,23–24` 搜索、表列、默认客户/仓库、编辑弹窗 | `basic-settings.js:19–28` 查询、新增、编辑、记录、表单和关闭确认 | `basic-settings.css:1`、`ui-review.css:7–12,36–37` |
| `#settings/warehouses` | `basic-settings.js:10–18,23–24` 所属营业厅字段和表列 | 同上；实体选择器 `entity-select.js` | 同上 |
| `#settings/parties` | `basic-settings.js:10–18,23–25` 标签、维护标签和表列 | 同上；标签筛选 | 同上 |
| `#settings/staff` | `basic-settings.js:10–18,23–25` 角色/营业厅/联系方式及登录账号字段 | 同上；角色、营业厅筛选和密码字段 | 同上 |
| `#settings/payments` | `basic-settings.js:10–18,23–24` 名称表列 | `basic-settings.js:25–26` 编辑与拖动排序 | 同上 |
| `#settings/fundAccounts` | `basic-settings.js:10–18,23–24` 所属方式/关联营业厅字段和表列 | `basic-settings.js:21–25` 方式、营业厅选择与保存 | 同上 |

基础资料 `basic-settings.js:22` 原可调用 `M.save`，但实际真实数据启动后 `real-data-bridge.mjs:37–54` 将该保存路径覆盖为“当前阶段基础资料仅查询，修改未提交”；商品资料写入也同样被覆盖。新版本若要做到可写，必须接通真实写 API 和权限，不能把弹窗打开或本地表单当成持久化成功。

## 源码中的尺寸与层叠关键点

- `ui-tokens.css:28–36` 定义 208px 侧栏、名义 44px 顶栏、32px 控件、13px 正文、22px 标题、4px 控件圆角、6px 卡片圆角。`styles.css:19–35` 实施全站网格、sticky 侧栏和 `#page` 的 `12px 16px 16px` 内边距；`ui-review.css:5` 给顶栏上下各 6px 和边框，实际外框高 45px。
- 库存 `inventory-workbench.css:8–17` 改标题为 20px、定义筛选区和浮层；`matrix-experiments.css:1` 给矩阵格子 `5px 8px`，`interaction-common.css:5` 再把上下覆盖为 4px，最终是 `4px 8px`。
- 调拨 `transfer-current.css:9–16,26` 定义筛选、列表和单据头；销售 `sales-current.css:2–8` 定义列表/单据头，后续 `interaction-common.css:1`、`matrix-experiments.css:24–26`、`ui-review.css:43–44`、`final-ui.css:4,6` 再改销售头的网格。1440 宽最终应用 `final-ui.css:6` 的四列，950 以下改两列。
- 基础资料 `basic-settings.css:1` 起初有 24px 页内边距及 `13px 16px` 表格内边距；后续 `ui-review.css:7–9` 覆盖为页面 0、表格 `6px 10px`。弹窗仍由 `basic-settings.css:1` 的宽 `min(840px,94vw)`、内边距 24px 定义，边框和圆角由 `ui-review.css:34–37` 补齐。
- 商品 `product-current.css:4–8,50–54` 定义列表树、表格、分页、筛选网格和属性区，`ui-review.css` 和 `final-ui.css` 在后续加载时仍可能改变通用按钮与弹窗。

## 源码与浏览器的冲突追溯

源码是读取入口，最终事实由已运行页面的 `getComputedStyle` 和实际事件决定。`evidence/legacy-8877/runtime-source-trace-1440.json` 对 15 个路由保存所选元素的矩形、计算样式和匹配 CSS 规则；三视口截图仅用于最终视觉差异核对。

| 初读源码 | 最终运行 | 源码原因 |
| --- | --- | --- |
| `inventory-workbench.js:36` 页头没有扫码按钮，搜索占位是“商品款号 / 名称 / 条码” | 显示“扫码查库存”，占位为“输入货号后几位／商品名称” | `inventory-matrix-experiment.js:28–29` 在前一模块渲染之后插入按钮并覆盖占位。最新用户要求移除该按钮。 |
| `matrix-experiments.css:1` 矩阵格子 `5px 8px` | 计算值 `4px 8px` | `interaction-common.css:5` 后置覆盖上下内边距。 |
| `basic-settings.css:1` 基础表格 `13px 16px`，页面 24px | 计算值 `6px 10px`，页面无额外内边距 | `ui-review.css:7–9` 后置覆盖。 |
| `sales-funds-ui.js:18–22` 是单组方式/账户选择 | 实际支付明细可重复 0..N 行 | `real-data-bridge.mjs:59–67` 覆盖 `SALES_FUNDS_UI.field/open` 并添加行事件。 |
| `basic-settings.js:22` 和 `product-current.js:41` 看似可保存 | 真实数据模式的基础/商品资料写入返回未提交 | `real-data-bridge.mjs:37–54` 启动时替换保存函数。 |

截图不用于反推上述尺寸或事件；浏览器读取只验证源码层叠、异步渲染和运行状态。原始源码行号均指 `ui-structure-prototype` 顶层文件，不引用归档副本。
