# Legacy Rebuild Diff

差异按页面记录。只有 COLOR_THEME、TECHNICAL_CORRECTION、LATEST_USER_OVERRIDE、UNRESOLVED 四类；FREE_DESIGN 不允许。

8877 基线以 [LEGACY_8877_SOURCE_LOCK.md](LEGACY_8877_SOURCE_LOCK.md) 的正式工程文件和加载顺序为起点，`runtime-source-trace-1440.json` 的运行计算值为最终事实。截图只用于差异截图验收。

| 页面 | 8877 行为 | React 行为 | 原因 | 类型 |
| --- | --- | --- | --- | --- |
| 全站 | 旧配色 | Theme 1376 语义颜色 | 用户唯一颜色例外 | COLOR_THEME |
| 销售与调拨日期、实体选择、展开菜单 | 8877 使用浏览器原生日期输入和工程自绘弹层 | React 使用 Arco DatePicker、Select、Collapse 与 Dropdown；保留日期时分和业务选择结果 | 用户明确要求基础 UI 直接采用 Arco 官方组件 | LATEST_USER_OVERRIDE |
| 库存 | 页头有扫码查库存 | 移除入口 | 最新用户裁决 | LATEST_USER_OVERRIDE |
| 库存 | 单款关键词 | 同框可粘贴多个款号 | 最新用户裁决 | LATEST_USER_OVERRIDE |
| 库存 | 正负相抵等解释 | 直接展示有符号数量 | 最新用户裁决 | LATEST_USER_OVERRIDE |
| 库存数量格 | 8877 对尺码组中不存在的 SKU 显示 0，对存在但来源未给数量的 SKU 也可能显示 0 | 无 SKU 的展示占位显示 0；有真实 SKU 但 8878 未给该仓库数量时仍显示“未读取”，不写入或补造库存 | 8878 `runtime/inventory` 仅从余额源与增量构建 `cells`，无来源值不能作已确认库存 0 | TECHNICAL_CORRECTION |
| 库存分页汇总 | 8877 只消费可定位的颜色小计 | 8878 某些页含 `first/last=null` 且每列全零的无行占位记录；客户端仅跳过这种占位，非零或身份异常仍报错 | 真实接口的页内元数据边界，避免整页和全量导出误失败 | TECHNICAL_CORRECTION |
| 调拨列表 | 无货品信息摘要；操作为图标 | 增加摘要，操作用“查看” | 最新用户裁决 | LATEST_USER_OVERRIDE |
| 全站分页 | 旧页面可见控件 | Arco Pagination 接真实服务端分页 | 分页事实与请求保护 | TECHNICAL_CORRECTION |
| 销售列表页脚 | 8877 在本次真实列表页显示“已审核销售合计 0.00 元”，与当页已审核销售金额不符 | React 按当页已审核销售单的真实金额计算（本次首页为 20668.00 元） | 旧页面页脚沿用早期模型的金额投影，不能为贴图伪造 0 | TECHNICAL_CORRECTION |
| 全站 | 历史未知可能显示临时代称 | 保留“—/历史未提供/未设置” | 来源事实保护 | TECHNICAL_CORRECTION |

当前仍在重建，正式页面对比尚未完成；UNRESOLVED 与 FREE_DESIGN 数量不能提前宣称为 0。
