# 调拨模块 8877 工程源码锁定清单

本清单在修改 React 调拨模块前形成。正式加载链为 `index.html` 的 `transfer-current.js` → `transfer-matrix-experiment.js` → `real-data-bridge.mjs`，CSS 是 `transfer-current.css` → `matrix-experiments.css` → `interaction-common.css` → `ui-review.css` → `final-ui.css`。以下先按源码锁定；模块实现完成后才用 8877 运行页面的 computed style 和截图验收。如实际运行冲突，追溯后置覆盖规则。

## 路由、字段、列与顺序

| 区域 | 源码 | 锁定结构 |
| --- | --- | --- |
| `#transfer` 列表 | `transfer-current.js:52–70` | 面包屑“库存管理 / 调拨单列表”；标题“调拨单列表”与右侧“新增调拨单”。筛选同排：日期 → 至 → 调拨单号 → 调出仓 → 调入仓 → 状态 → 查询 → 重置。日期/单号输入，仓库多选实体选择器，状态单选。列表列：日期、调拨单号、调出仓、调入仓、状态、商品款数、总数量、创建者、审核、最后更新、操作。用户最新要求插入“货品信息”列、操作改文字“查看”、不显示“商品款数”列；货品信息为品类/款号/摘要。 |
| 列表分页 | `transfer-current.js:70,124–149` | 每页 20，底部“共 N 张调拨单 · 每页 20 张”，上一页、首/末页和当前前后各 1 页（间隔显示省略号）、下一页、“第 x / y 页”。查询回第 1 页，刷新保留已执行条件；列表区独立纵横滚动。 |
| 查询提示 | `ui-review.js:5–6`、`ui-review.css:15–16` | 后置脚本在筛选表单与结果之间插入常显 `ui-query-note`；未修改时为“修改条件后点击‘查询’；‘重置’恢复全部结果。”，待查询时改成条件已修改提示，padding 6px 0 8px、12px/1.6。 |
| `#transfer/new` 与 `#transfer/doc/:id` | `transfer-current.js:74–75`，后置 `transfer-matrix-experiment.js:12–18` | 面包屑“库存管理 / 新增调拨单”或“调拨单”。页头为标题→状态→保存状态→返回列表→保存未审核单/审核或弃审→更多操作。单头为“调出仓 → 调入仓”方向区、单据日期、单号/创建者/最后修改；后置矩阵脚本把“批量录入 → 扫码录入/扫码记录（N）→ 导出”移动到单头底部。商品区标题“调拨明细”，提示“空白或 0 不调拨”，下面独立滚动矩阵与“本次调拨：X款 · 共 Y件”尾部。 |
| 调拨矩阵 | `transfer-matrix-experiment.js:11–18` | 按正式尺码组分节，每节列为“商品名称／款号、颜色、该组各尺码、小计、操作”。首列 240px、颜色 92px、尺码最小 76px、小计 76px、操作 110px，整表至少 `518 + 76×尺码列数` px；商品和颜色左固定，小计和操作右固定。已有行逐规格填写 0–99999 整数，可查看商品详情、移除颜色。最后一行是原位输入：输入货号片段/商品名称→选择候选→选择颜色→在实际尺码格填写数量。无真实 SKU 的格子显示破折号。 |
| 批量、替换、扫描、打印、导出 | `transfer-matrix-experiment.js:18–53`、`transfer-current.js:77–149` | 批量 Modal 先商品 Finder，后全颜色×尺码矩阵，确认才追加；有未提交值时关闭要丢弃确认。已有行可更换商品/颜色，确认前保留旧数量，目标颜色行已有时需合并确认；Escape 取消更换。扫码工作台可扫条码、记录及撤销，真实工作日志和库存由服务端处理。导出矩阵 CSV，打印只取已保存版本并按 A4 横向分页。更多操作含操作历史、打印、删除未审核单等，实际可用性按真实后置桥接及权限判定。 |

**空白新增页的可点击状态**：`transfer-current.js:74` 始终渲染可点击的“保存未审核单 / 审核”，校验在点击后的 `commit()` 内执行（`:118`），不是预先禁用。`transfer-matrix-experiment.js:18` 仅按单据编辑资格决定是否显示“批量录入”，不要求先选调出/调入仓；“扫码录入”和“导出”也从空白页提供。`transfer-matrix-experiment.js:37–53` 的实际扫码/批量数量提交再校验资格和数量，`report()` 可导出只有表头的空白矩阵。因此 React 新增页的这几项操作必须可按，缺仓或空明细在实际提交时给出原因，不能把整个入口置灰。
| `#transfer/doc/:id` | `transfer-current.js:56–75,100–149` | 已审核只读，弃审后可编辑；未审核保留矩阵与输入能力。源工程此路由共用编辑 DOM，标题变“查看调拨单”或“编辑调拨单”，不是独立卡片式详情。 |

## 状态和事件

- `transfer-current.js:8–18,23–26,34–49`：列表筛选草稿/已执行值分离；单据以业务签名判断脏状态；路由离开、浏览器前后退、关闭页面拦截未保存修改；草稿暂存 sessionStorage。旧源有编辑租约/心跳/冲突阻断；React 的服务端命令以 `expectedVersion + requestKey` 保留真实并发约束，不能伪造租约事实。
- `transfer-current.js:70,90–93,124–149`：查询验证日期并重置滚动/页码；打开单据前同步服务端；分页保留条件；仓库筛选是多选，单据仓库单选且禁用相同调出/调入；弹层有仓库名/编码搜索和焦点返回。
- `transfer-matrix-experiment.js:3–18,20–42`：行内 Finder 用真实商品与条码解析；选商品后如只有一种颜色可直接加入颜色行，否则聚焦颜色；颜色行即使数量尚空也可显示，但空白/0 不进入调拨。数量 Enter/Tab 走下一可编辑格，Shift+Tab 反向，末格回商品输入；中文输入法组合期间不触发提交。批量输入按原 SKU/真实尺码格验证。替换事务确认前不删除旧行。
- `transfer-current.js:19–24,41,80–89,106–149`：Modal 打开关闭 Finder；扫码和撤销走工作记录事件，重复事件键抑制；保存/审核/弃审遵守服务端结果，失败保留草稿；成功历史仅记录已提交操作。只读商品详情含库存、商品信息、图片、条码页签。

## 源码中的最终尺寸与字体

| 对象 | 加载后应有的声明 |
| --- | --- |
| 全站 | `ui-tokens.css`、`styles.css`：侧栏 208px，顶栏外框 45px，`#page` padding `12px 16px 16px`，正文 Arial/PingFang 13px/1.5，按钮/输入名义高 32px。 |
| 列表 | `transfer-current.css:4–11,25–26`：页头 min-height 40px、底距 8px、标题 20px/600/28px；筛选一排 flex、gap 8px、底距 12px，日期 125px、单号 160px；结果容器 max-height `100dvh - 220px`，表 min-width 1050px、13px，表头 12px/400，单元高至少 32px、padding `4px 10px`；分页上下 padding 8px，按钮 28px。 |
| 单头 | `transfer-current.css:12–20,26–27` 后置自身规则：工作台高度 `100dvh - 顶栏 - 32px`；单头 `grid-template-columns:minmax(400px,650px) 160px`、列间 22px、padding `8px 12px 7px`，仓库方向三列（中间箭头 24px），标签 12px、控件高 32px，元信息 12px。≤1250/≤900/≤650px 各有网格与宽度调整。 |
| 录入与矩阵 | `matrix-experiments.css:1,3,5–11,29,31`：矩阵表 `table-layout:fixed`，初始单元 padding `5px 8px`、高 36px；后置 `interaction-common.css` 覆盖为最终 `4px 8px`，8877 空录入行 computed 高约 40.5px。输入 64×28px；原位商品输入整首列、颜色 Select 32px；结果框独立滚动、商品/颜色左固定、小计右固定；详情按钮经 `interaction-common.js` 装饰为图标。 |
| 弹层 | `transfer-current.css:19–20`：普通 dialog 宽 540px，确认 390px，更多 260px，商品详情右侧抽屉 660px，打印 1040px；`matrix-experiments.css:1` 批量弹层宽 `min(960px,100vw-32px)`、内边距 16px。 |

已保存的工程来源图谱见 `evidence/legacy-8877/source-map.json`，全站 1440px 旧运行计算值见 `evidence/legacy-8877/runtime-source-trace-1440.json`，它们用于模块完成后的验收比对。截图只作为阶段性视觉证据。
