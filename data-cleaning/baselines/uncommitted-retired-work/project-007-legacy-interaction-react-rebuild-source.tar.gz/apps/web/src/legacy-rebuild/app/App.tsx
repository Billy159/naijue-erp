import { useEffect, useState, useSyncExternalStore } from "react";
import { Alert, ConfigProvider, Spin } from "@arco-design/web-react";
import zhCN from "@arco-design/web-react/es/locale/zh-CN";
import { capabilitiesFor } from "@stage05/contracts/capability";
import { matchRoute, pathFor } from "@stage05/contracts/route";
import type { SessionState } from "@stage05/contracts/session";
import { api, ApiError } from "@stage05/data/client";
import { AppShell } from "./AppShell";
import { LoginPage } from "./LoginPage";
import { RouteContent } from "./RouteContent";
import { afterLogin, locationSnapshot, loginTarget, navigate, subscribeLocation } from "@stage05/app/router";
import { forgetOperator, rememberOperator, restoreSession } from "@stage05/app/session";
import { ErrorState, FeedbackHost, NotFoundState } from "@stage05/shared/feedback";
import "../style.css";
import "../density.css";
import { skuProjectionRepository } from "@stage05/features/products/skuRepository";

function AppBody() {
  const location=useSyncExternalStore(subscribeLocation,locationSnapshot,()=>"/inventory");
  const [session,setSession]=useState<SessionState>({state:"checking"});
  const [loginLoading,setLoginLoading]=useState(false),[loginError,setLoginError]=useState<string|null>(null);
  useEffect(()=>{const controller=new AbortController();void restoreSession(controller.signal).then(async saved=>{
    if(!saved)return null;
    try { await api.listRuntimeDocuments("SALE",{page:1,pageSize:1},controller.signal);return saved; }
    catch(error){if(error instanceof ApiError&&error.kind==="unauthorized"){forgetOperator();return null;}throw error;}
  }).then(saved=>{if(!controller.signal.aborted)setSession(saved?{state:"authenticated",session:saved}:{state:"anonymous"});}).catch(error=>{if(!controller.signal.aborted)setSession({state:"error",reason:error instanceof Error?error.message:"会话验证失败"});});return ()=>controller.abort();},[]);
  const url=new URL(location,"http://stage05.local"),match=matchRoute(url.pathname);
  useEffect(()=>{
    if(session.state==="checking"||session.state==="error")return;
    if(url.pathname==="/") {navigate(session.state==="authenticated"?pathFor("inventory"):pathFor("login"),true);return;}
    if(session.state==="anonymous"&&url.pathname!=="/login"&&match)navigate(loginTarget(location),true);
    if(session.state==="authenticated"&&url.pathname==="/login")navigate(afterLogin(url.search),true);
  },[session.state,location,match,url.pathname,url.search]);
  async function login() {
    setLoginLoading(true);setLoginError(null);
    try {await api.getHealth();const operator=await api.login();rememberOperator(operator);setSession({state:"authenticated",session:{operator,boundary:"local-runtime",visibleScope:{kind:operator.id==="local-admin"&&operator.role==="ADMIN"?"all-runtime-data":"unknown",storeIds:null,evidence:operator.id==="local-admin"&&operator.role==="ADMIN"?"8878-local-admin-unscoped":"server-not-provided"},verifiedAt:Date.now()}});navigate(afterLogin(url.search),true);}
    catch(error){setLoginError(error instanceof Error?error.message:"登录失败");}
    finally{setLoginLoading(false);}
  }
  async function logout() {
    try {await api.logout();} catch { /* A missing or expired cookie still ends the local session. */ }
    skuProjectionRepository.clear();
    forgetOperator();setSession({state:"anonymous"});navigate(pathFor("login"),true);
  }
  if(session.state==="checking")return <main className="s05-boot"><Spin size={28} /></main>;
  if(session.state==="error")return <main className="s05-boot"><ErrorState message={session.reason} onRetry={()=>window.location.reload()} /></main>;
  if(!match&&url.pathname!=="/")return <NotFoundState title="页面不存在" onBack={()=>navigate(pathFor("inventory"))} />;
  if(session.state==="anonymous")return <LoginPage loading={loginLoading} error={loginError} onLogin={()=>void login()} />;
  if(!match||match.route.id==="login")return <main className="s05-boot"><Spin size={28} /></main>;
  const capabilities=capabilitiesFor(session.session),required=match.route.capability;
  if(required&&!capabilities[required].allowed)return <AppShell route={match.route} session={session.session} onLogout={()=>void logout()} routeParams={match.params}><Alert type="error" showIcon title="当前会话无权访问" content={capabilities[required].reason||"服务端能力未开放"} /></AppShell>;
  return <AppShell route={match.route} session={session.session} onLogout={()=>void logout()} routeParams={match.params}><RouteContent match={match} capabilities={capabilities} /></AppShell>;
}
export function LegacyRebuildApp() {return <ConfigProvider locale={zhCN} size="default"><FeedbackHost /><AppBody /></ConfigProvider>;}
