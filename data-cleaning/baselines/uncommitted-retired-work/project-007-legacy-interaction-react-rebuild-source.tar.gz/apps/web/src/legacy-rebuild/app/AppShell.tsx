import { useEffect, useState, type ReactNode } from "react";
import { Breadcrumb, Button, Menu } from "@arco-design/web-react";
import { pathFor, type RouteDefinition, type RouteId } from "@stage05/contracts/route";
import type { Session } from "@stage05/contracts/session";
import { navigate } from "./router";

type Item = { id: RouteId; label: string };
const inventory: Item[] = [{ id: "inventory", label: "库存状况表" }];
const transfer: Item[] = [{ id: "transfers", label: "调拨单列表" }, { id: "transfers-new", label: "新增调拨单" }];
const sales: Item[] = [{ id: "sales", label: "销货单列表" }, { id: "sales-new", label: "新增销货单" }];
const products: Item[] = [
  { id: "products", label: "商品信息" }, { id: "product-categories", label: "商品分类" },
  { id: "product-settings", label: "商品设置" }, { id: "barcode-schemes", label: "条码方案" },
];
const settings: Item[] = [
  { id: "stores", label: "营业厅配置" }, { id: "warehouses", label: "仓库" },
  { id: "parties", label: "往来单位" }, { id: "staff", label: "员工与账号" },
  { id: "payments", label: "收款方式" }, { id: "fund-accounts", label: "资金账户" },
];
const toRoute = new Map([...inventory, ...transfer, ...sales, ...products, ...settings].map(item => [item.id, item]));
function selectedRoute(id: RouteId): RouteId {
  if (id === "transfers-detail" || id === "transfers-edit") return "transfers";
  if (id === "sales-detail" || id === "sales-edit") return "sales";
  if (id === "products-detail" || id === "products-new") return "products";
  return id;
}
function crumb(route: RouteDefinition): string {
  if (route.id.startsWith("transfers")) return route.id === "transfers" ? "调拨单列表" : route.id === "transfers-new" ? "新增调拨单" : "调拨单";
  if (route.id.startsWith("sales")) return route.id === "sales" ? "销货单列表" : route.id === "sales-new" ? "新增销货单" : "销货单";
  if (route.id === "products-detail" || route.id === "products-new") return "商品信息";
  return route.title;
}

export function AppShell({ route, session, onLogout, children }: {
  route: RouteDefinition;
  session: Session;
  onLogout: () => void;
  children: ReactNode;
  routeParams: Record<string, string>;
}) {
  const selected = selectedRoute(route.id);
  const [transferOpen, setTransferOpen] = useState(route.id.startsWith("transfers"));
  const [salesOpen, setSalesOpen] = useState(route.id.startsWith("sales"));
  useEffect(() => { if (route.id.startsWith("transfers")) setTransferOpen(true); }, [route.id]);
  useEffect(() => { if (route.id.startsWith("sales")) setSalesOpen(true); }, [route.id]);
  const onSelect = (key: string) => { const item = toRoute.get(key as RouteId); if (item) navigate(pathFor(item.id)); };
  const menuItem = (item: Item) => <Menu.Item key={item.id}>{item.label}</Menu.Item>;
  return <div className="lr-shell">
    <aside className="lr-sidebar" aria-label="业务导航">
      <div className="lr-brand">奈爵服饰 <span>V2</span></div>
      <nav>
        <div className="lr-nav-group">库存管理</div>
        <Menu className="lr-menu" selectedKeys={[selected]} openKeys={transferOpen ? ["transfer-group"] : []} onClickSubMenu={(_key, keys) => setTransferOpen(keys.includes("transfer-group"))} onClickMenuItem={onSelect}>
          {inventory.map(menuItem)}
          <Menu.SubMenu key="transfer-group" title="调拨单" selectable={false}>
            {transferOpen && transfer.map(menuItem)}
          </Menu.SubMenu>
        </Menu>
        <div className="lr-nav-group">销售管理</div>
        <Menu className="lr-menu" selectedKeys={[selected]} openKeys={salesOpen ? ["sales-group"] : []} onClickSubMenu={(_key, keys) => setSalesOpen(keys.includes("sales-group"))} onClickMenuItem={onSelect}>
          <Menu.SubMenu key="sales-group" title="销货单" selectable={false}>
            {salesOpen && sales.map(menuItem)}
          </Menu.SubMenu>
        </Menu>
        <div className="lr-nav-group">商品管理</div>
        <Menu className="lr-menu" selectedKeys={[selected]} onClickMenuItem={onSelect}>{products.map(menuItem)}</Menu>
        <div className="lr-nav-group">基础设置</div>
        <Menu className="lr-menu" selectedKeys={[selected]} onClickMenuItem={onSelect}>{settings.map(menuItem)}</Menu>
      </nav>
    </aside>
    <div className="lr-main">
      <header className="lr-topbar">
        <Breadcrumb separator=" / "><Breadcrumb.Item>{route.group}</Breadcrumb.Item><Breadcrumb.Item>{crumb(route)}</Breadcrumb.Item></Breadcrumb>
        <div className="lr-account"><span>{session.operator.name || "—"}</span><Button onClick={onLogout}>退出</Button></div>
      </header>
      <main className="lr-page">{children}</main>
    </div>
  </div>;
}
