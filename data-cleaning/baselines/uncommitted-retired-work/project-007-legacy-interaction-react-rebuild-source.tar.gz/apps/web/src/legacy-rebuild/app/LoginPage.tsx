import { Alert, Button, Card, Space, Typography } from "@arco-design/web-react";
export function LoginPage({loading,error,onLogin}:{loading:boolean;error:string|null;onLogin:()=>void}) {
  return <main className="s05-login"><Card className="s05-login-card" bordered><Space direction="vertical" size="large" style={{width:"100%"}}>
    <div className="s05-login-identity"><span className="s05-brand-mark">奈</span><Typography.Title heading={3}>奈爵服饰</Typography.Title></div>
    <Typography.Text type="secondary">请使用当前服务已开放的操作会话进入系统。</Typography.Text>
    {error&&<Alert type="error" showIcon content={error} />}
    <Button type="primary" long loading={loading} onClick={onLogin}>进入系统</Button>
  </Space></Card></main>;
}
