import { Component, Suspense, lazy, type ReactNode } from "react";
import { Alert, Button } from "@arco-design/web-react";
import { type RouteMatch, type RouteId } from "@stage05/contracts/route";
import type { CapabilitySnapshot } from "@stage05/contracts/capability";
import { LoadingState, NotFoundState } from "@stage05/shared/feedback";
import { PageContainer } from "@stage05/shared/PageContainer";
import { navigate } from "@stage05/app/router";
import type { BasicDataRouteId } from "../features/basic/BasicDataRoute";

// Keep each business page behind its route. The shell, session and feedback
// remain mounted while Vite fetches a page chunk.
const InventoryRoute=lazy(()=>import("../features/inventory/InventoryRoute").then(module=>({default:module.InventoryRoute})));
const SalesListPage=lazy(()=>import("../features/sales/SalesListPage").then(module=>({default:module.SalesListPage})));
const SalesDetailPage=lazy(()=>import("../features/sales/SalesDetailPage").then(module=>({default:module.SalesDetailPage})));
const SalesEditorPage=lazy(()=>import("../features/sales/SalesEditorPage").then(module=>({default:module.SalesEditorPage})));
const ProductsRoute=lazy(()=>import("../features/products/ProductsRoute").then(module=>({default:module.ProductsRoute})));
const ProductDetailRoute=lazy(()=>import("../features/products/ProductDetailRoute").then(module=>({default:module.ProductDetailRoute})));
const ProductNewRoute=lazy(()=>import("../features/products/ProductNewRoute").then(module=>({default:module.ProductNewRoute})));
const CatalogCategoriesRoute=lazy(()=>import("../features/catalog-settings/CatalogCategoriesRoute").then(module=>({default:module.CatalogCategoriesRoute})));
const ProductSettingsRoute=lazy(()=>import("../features/catalog-settings/ProductSettingsRoute").then(module=>({default:module.ProductSettingsRoute})));
const BarcodeSchemesRoute=lazy(()=>import("../features/catalog-settings/BarcodeSchemesRoute").then(module=>({default:module.BarcodeSchemesRoute})));
const BasicDataRoute=lazy(()=>import("../features/basic/BasicDataRoute").then(module=>({default:module.BasicDataRoute})));
const TransferListPage=lazy(()=>import("../features/transfers/TransferListPage").then(module=>({default:module.TransferListPage})));
const TransferDetailPage=lazy(()=>import("../features/transfers/TransferDetailPage").then(module=>({default:module.TransferDetailPage})));
const TransferEditorPage=lazy(()=>import("../features/transfers/TransferEditorPage").then(module=>({default:module.TransferEditorPage})));

class RouteChunkBoundary extends Component<{children:ReactNode},{failed:boolean}> {
  state={failed:false};
  static getDerivedStateFromError(){return {failed:true};}
  render(){return this.state.failed?<PageContainer title="页面加载失败"><Alert type="error" showIcon title="页面文件未能加载" content={<Button onClick={()=>window.location.reload()}>重试加载</Button>} /></PageContainer>:this.props.children;}
}

const basicDataRouteIds: readonly BasicDataRouteId[] = ["stores", "warehouses", "parties", "staff", "payments", "fund-accounts"];
function isBasicDataRouteId(id: RouteId): id is BasicDataRouteId {
  return (basicDataRouteIds as readonly RouteId[]).includes(id);
}

export function RouteContent({match,capabilities}:{match:RouteMatch;capabilities:CapabilitySnapshot}) {
  let page:ReactNode;
  if(match.route.id==="inventory")page=<InventoryRoute />;
  else if(match.route.id==="transfers")page=<TransferListPage />;
  else if(match.route.id==="transfers-new")page=<TransferEditorPage />;
  else if(match.route.id==="transfers-detail")page=<TransferDetailPage id={match.params.id!} />;
  else if(match.route.id==="transfers-edit")page=<TransferEditorPage id={match.params.id!} />;
  else if(match.route.id==="sales")page=<SalesListPage />;
  else if(match.route.id==="sales-new")page=<SalesEditorPage />;
  else if(match.route.id==="sales-detail")page=<SalesDetailPage id={match.params.id!} />;
  else if(match.route.id==="sales-edit")page=<SalesEditorPage id={match.params.id!} />;
  else if(match.route.id==="products")page=<ProductsRoute />;
  else if(match.route.id==="products-detail")page=<ProductDetailRoute code={match.params.id!} />;
  else if(match.route.id==="products-new")page=<ProductNewRoute />;
  else if(match.route.id==="product-categories")page=<CatalogCategoriesRoute />;
  else if(match.route.id==="product-settings")page=<ProductSettingsRoute />;
  else if(match.route.id==="barcode-schemes")page=<BarcodeSchemesRoute />;
  else if(isBasicDataRouteId(match.route.id))page=<BasicDataRoute routeId={match.route.id} capabilities={capabilities} />;
  else page=<NotFoundState title="页面不存在" onBack={()=>navigate("/inventory")} />;
  return <RouteChunkBoundary key={`${match.route.id}:${match.params.id ?? ""}`}><Suspense fallback={<LoadingState text="正在加载页面" />}>{page}</Suspense></RouteChunkBoundary>;
}
