// Routes and return context remain the Stage05 contract in the isolated frontend.
export * from "@stage05/app/router";
