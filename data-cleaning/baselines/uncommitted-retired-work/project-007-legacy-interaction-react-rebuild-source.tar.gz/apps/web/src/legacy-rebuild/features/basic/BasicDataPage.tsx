import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  Alert,
  Button,
  Descriptions,
  Drawer,
  Input,
  Pagination,
  Space,
  Table,
  Tag,
  Tooltip,
  Typography,
} from "@arco-design/web-react";
import type { TableProps } from "@arco-design/web-react";
import {
  EmptyState,
  PageContainer,
  QueryFeedback,
  usePagedQuery,
  type PagedQueryController,
  type PageFetcher,
  type PagedQueryState,
} from "@stage05";
import { BASIC_PAGE_SIZE, emptySearch, pageSizeOptions, type SearchFilter } from "./data";
import "./basic-data.css";

export type BasicColumn = NonNullable<TableProps["columns"]>[number];

export interface BasicListProps<T extends { id: string }> {
  title: string;
  description: string;
  countLabel: string;
  emptyDescription: string;
  tableMinWidth: number;
  readOnlyReason: string;
  fetcher: PageFetcher<SearchFilter, T>;
  columns: BasicColumn[];
  detailTitle: (row: T) => string;
  renderDetails: (row: T, close: () => void) => ReactNode;
}

export function LongText({ children, width = 220 }: { children: string; width?: number }) {
  return <Tooltip content={children} position="top">
    <span className="basic-long-text" style={{ maxWidth: width }} title={children}>{children}</span>
  </Tooltip>;
}

export function DetailSection({ title, children }: { title: string; children: ReactNode }) {
  return <section className="basic-detail-section">
    <Typography.Title heading={6}>{title}</Typography.Title>
    {children}
  </section>;
}

export function StatusTag({ value }: { value: boolean | null }) {
  if (value === null) return <Tag color="gray">状态未提供</Tag>;
  return value ? <Tag color="green">启用</Tag> : <Tag color="gray">停用</Tag>;
}

export function BasicDataPage<T extends { id: string }>({
  title,
  description,
  countLabel,
  emptyDescription,
  tableMinWidth,
  readOnlyReason,
  fetcher,
  columns,
  detailTitle,
  renderDetails,
}: BasicListProps<T>) {
  const { state, controller } = usePagedQuery<SearchFilter, T>(emptySearch, BASIC_PAGE_SIZE, fetcher);
  const [selected, setSelected] = useState<T | null>(null);
  const triggerRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    void controller.reload();
  }, [controller]);

  function closeDrawer() {
    setSelected(null);
  }

  const allColumns: BasicColumn[] = [
    ...columns,
    {
      title: "操作",
      key: "action",
      width: 88,
      fixed: "right",
      render: (_value, record) => <Button
        type="text"
        onClick={(event) => {
          triggerRef.current = event.currentTarget as HTMLButtonElement;
          setSelected(record as T);
        }}
      >详情</Button>,
    },
  ];

  return <div className="stage05-basic-root">
    <PageContainer title={title} description={description}>
      <Space direction="vertical" size="small" className="basic-page-content">
        <Typography.Text type="secondary" className="basic-readonly-note">当前资料只读。{readOnlyReason}</Typography.Text>
        <div role="search">
          <Space wrap className="basic-query-row">
          <Input
            aria-label={title + "搜索"}
            value={state.draft.q}
            onChange={(value) => controller.setDraft({ ...state.draft, q: value })}
            onPressEnter={() => void controller.apply()}
            placeholder="按名称或来源编码搜索"
            style={{ width: 300, maxWidth: "min(300px, 68vw)" }}
          />
          <Button type="primary" onClick={() => void controller.apply()}>查询</Button>
          <Button onClick={() => void controller.reset()}>重置</Button>
          </Space>
        </div>
        {JSON.stringify(state.draft) !== JSON.stringify(state.applied) &&
          <Alert type="warning" showIcon content="查询条件已修改，尚未执行查询。" />}
        {state.hasExecuted && state.loading === "idle" && state.total === 0 && !state.error
          ? <EmptyState description={emptyDescription} onReset={() => void controller.reset()} />
          : <QueryFeedback
            loading={state.loading}
            hasExecuted={state.hasExecuted}
            total={state.total}
            error={state.error}
            stale={state.stale}
            onRetry={() => void controller.reload()}
            onReset={() => void controller.reset()}
          >
            <div className="basic-result-count">
              <Typography.Text type="secondary">{countLabel}：{state.total} 条</Typography.Text>
            </div>
            <div className="basic-table-scroll">
              <Table
                rowKey="id"
                columns={allColumns}
                data={state.items}
                size="small"
                loading={state.loading === "refresh"}
                pagination={false}
                scroll={{ x: tableMinWidth }}
                noDataElement={null}
              />
            </div>
            {state.total > state.pageSize && <div className="basic-pagination">
              <Pagination
                current={state.page}
                pageSize={state.pageSize}
                total={state.total}
                showTotal
                showJumper
                sizeCanChange
                hideOnSinglePage
                sizeOptions={pageSizeOptions}
                pageSizeChangeResetCurrent
                onChange={(page) => void controller.setPage(page)}
                onPageSizeChange={(pageSize) => void controller.setPageSize(pageSize)}
              />
            </div>}
          </QueryFeedback>}
      </Space>
    </PageContainer>
    <Drawer
      visible={selected !== null}
      title={selected ? detailTitle(selected) : "资料详情"}
      width="min(560px, calc(100vw - 48px))"
      autoFocus={false}
      focusLock
      footer={<Button onClick={closeDrawer}>关闭</Button>}
      onCancel={closeDrawer}
      afterClose={() => requestAnimationFrame(() => {
        if (triggerRef.current?.isConnected) triggerRef.current.focus();
      })}
    >
      {selected && renderDetails(selected, closeDrawer)}
    </Drawer>
  </div>;
}

export type BasicController<T extends { id: string }> = PagedQueryController<SearchFilter, T>;
export type BasicQueryState<T extends { id: string }> = PagedQueryState<SearchFilter, T>;
