import type { CapabilitySnapshot } from "@stage05";
import type { ComponentType } from "react";
import { PartyListPage } from "./parties";
import { FundAccountsPage, PaymentMethodsPage } from "./payments";
import { StaffListPage } from "./staff";
import { StoreListPage, WarehouseListPage } from "./locations";

export type BasicDataRouteId =
  | "stores"
  | "warehouses"
  | "parties"
  | "staff"
  | "payments"
  | "fund-accounts";

type BasicPageProps = { readOnlyReason: string };

export const basicDataRoutePages: Readonly<Record<BasicDataRouteId, ComponentType<BasicPageProps>>> = {
  stores: StoreListPage,
  warehouses: WarehouseListPage,
  parties: PartyListPage,
  staff: StaffListPage,
  payments: PaymentMethodsPage,
  "fund-accounts": FundAccountsPage,
};

export function BasicDataRoute({
  routeId,
  capabilities,
}: {
  routeId: BasicDataRouteId;
  capabilities: CapabilitySnapshot;
}) {
  const Page = basicDataRoutePages[routeId];
  const capability = capabilities["settings.write"];
  const reason = capability.allowed
    ? "此页面当前展示真实只读资料。"
    : capability.reason ?? "当前服务未开放此资料写入。";
  return <Page readOnlyReason={reason} />;
}
