import { Alert, Button, Descriptions, Popover, Space, Tag, Typography } from "@arco-design/web-react";
import { BasicDataPage, DetailSection, LongText, StatusTag, type BasicColumn } from "./BasicDataPage";
import { storesFetcher, warehousesFetcher } from "./data";
import {
  asText,
  defaultCustomerSummary,
  displaySourceValue,
  sourceIdentity,
  type BusinessStore,
  type BusinessWarehouse,
} from "./model";

const storeColumns: BasicColumn[] = [
  {
    title: "营业厅",
    dataIndex: "displayName",
    width: 220,
    render: (_value, row) => {
      const store = row as BusinessStore;
      return <Space size="small">
        <LongText width={190}>{store.displayName}</LongText>
        {store.displayName === "舟山银泰外场特卖" && <Tag color="arcoblue">独立</Tag>}
      </Space>;
    },
  },
  {
    title: "默认客户",
    dataIndex: "defaultCustomers",
    width: 240,
    render: (_value, row) => <LongText width={220}>{defaultCustomerSummary(row as BusinessStore)}</LongText>,
  },
  {
    title: "默认出库仓",
    dataIndex: "defaultWarehouse",
    width: 220,
    render: (_value, row) => {
      const store = row as BusinessStore;
      const value = displaySourceValue(store.defaultWarehouse, store.defaultWarehouseId, "仓库未设置");
      return <Space size="small">
        <LongText width={180}>{value}</LongText>
        {!store.defaultWarehouseInRelated && store.defaultWarehouseId && <Tag color="orange">未包含在关联仓</Tag>}
      </Space>;
    },
  },
  {
    title: "关联仓库",
    dataIndex: "warehouseIds",
    width: 120,
    render: (_value, row) => <Tag>{(row as BusinessStore).warehouseIds.length} 个</Tag>,
  },
];

function customerFactLabel(fact: BusinessStore["defaultCustomers"][number] | undefined): string {
  if (!fact) return "来源未设置";
  if (fact.customerName) return fact.customerName + (fact.customerCode ? " · " + fact.customerCode : "");
  return "客户资料未映射";
}

function StoreDetails({ store }: { store: BusinessStore }) {
  return <Space direction="vertical" size="large" style={{ width: "100%" }}>
    {store.defaultCustomers.length > 1 && <Alert
      type="warning"
      showIcon
      title="合并来源的默认客户不一致"
      content="这里逐个保留来源厅配置，没有选取某一个客户充当合并后的统一默认值。"
    />}
    {store.missingSourceIds.length > 0 && <Alert
      type="warning"
      showIcon
      title="有来源厅未映射"
      content={`${store.missingSourceIds.length} 个来源厅关系暂无法显示名称；原记录仍保留。`}
    />}
    {store.missingWarehouseIds.length > 0 && <Alert
      type="warning"
      showIcon
      title="有仓库未映射"
      content={`${store.missingWarehouseIds.length} 个仓库关系暂无法显示名称；原记录仍保留。`}
    />}
    <DetailSection title="营业厅配置">
      <Descriptions column={1} data={[
        { label: "营业厅名称", value: store.displayName },
        { label: "来源厅数量", value: store.sourceRecords.length + " 个" },
        { label: "关联仓库数量", value: store.warehouseIds.length + " 个" },
        { label: "默认出库仓", value: displaySourceValue(store.defaultWarehouse, store.defaultWarehouseId, "未设置") },
        { label: "默认仓在关联范围内", value: store.defaultWarehouseId ? (store.defaultWarehouseInRelated ? "是" : "否") : "未设置" },
      ]} />
    </DetailSection>
    <DetailSection title={"实际营业厅（" + store.sourceRecords.length + "）"}>
      <div className="basic-source-list">
        {store.sourceRecords.map((hall) => {
          const identity = sourceIdentity(hall);
          const customer = store.sourceDefaultCustomers.find((fact) => fact.sourceHallId === hall.id);
          return <article className="basic-source-item" key={hall.id}>
            <Typography.Text><strong>{asText(hall.name) ?? "营业厅名称未提供"}</strong></Typography.Text>
            <Typography.Text type="secondary">来源编码：{identity.code ?? "未提供"}</Typography.Text>
            <Typography.Text type="secondary">原默认客户：{customerFactLabel(customer)}</Typography.Text>
          </article>;
        })}
        {store.missingSourceIds.map((id) => <article className="basic-source-item" key={id}>
          <Typography.Text>来源厅未映射</Typography.Text>
          <Typography.Text type="secondary">名称暂不可用</Typography.Text>
        </article>)}
      </div>
    </DetailSection>
    <DetailSection title={"关联仓库（" + store.warehouseIds.length + "）"}>
      <div className="basic-source-list">
        {store.warehouseRecords.map((warehouse) => <article className="basic-source-item" key={warehouse.id}>
          <Typography.Text><strong>{asText(warehouse.name) ?? "仓库名称未提供"}</strong></Typography.Text>
          <Typography.Text type="secondary">来源编码：{asText(warehouse.code) ?? "未提供"}</Typography.Text>
          {warehouse.id === store.defaultWarehouseId && <Tag color="arcoblue">默认出库仓</Tag>}
        </article>)}
        {store.missingWarehouseIds.map((id) => <article className="basic-source-item" key={id}>
          <Typography.Text>仓库名称暂不可用</Typography.Text>
          {id === store.defaultWarehouseId && <Tag color="orange">默认出库仓</Tag>}
        </article>)}
        {store.warehouseIds.length === 0 && <Typography.Text type="secondary">当前没有关联仓库。</Typography.Text>}
      </div>
    </DetailSection>
  </Space>;
}

export function StoreListPage({ readOnlyReason }: { readOnlyReason: string }) {
  return <BasicDataPage
    title="营业厅配置"
    description="查看营业厅、默认客户与关联仓库"
    countLabel="业务配置营业厅"
    emptyDescription="没有符合条件的营业厅；可清空搜索条件。"
    tableMinWidth={900}
    readOnlyReason={readOnlyReason}
    fetcher={storesFetcher}
    columns={storeColumns}
    detailTitle={(store) => "营业厅 · " + (store as BusinessStore).displayName}
    renderDetails={(store) => <StoreDetails store={store as BusinessStore} />}
  />;
}

function storePreview(stores: BusinessWarehouse["associatedStores"]) {
  if (stores.length === 0) return "未关联营业厅";
  return <Popover
    title={"关联营业厅 · " + stores.length + " 个"}
    content={<Space direction="vertical" size="small">
      {stores.slice(0, 3).map((store) => <Typography.Text key={store.id}>{store.displayName}</Typography.Text>)}
      {stores.length > 3 && <Typography.Text type="secondary">另有 {stores.length - 3} 个，详情中查看完整范围</Typography.Text>}
    </Space>}
  >
    <Button type="text" size="small" aria-label={"查看 " + stores.length + " 个关联营业厅的预览"}>
      {stores.length} 个营业厅
    </Button>
  </Popover>;
}

const warehouseColumns: BasicColumn[] = [
  {
    title: "仓库",
    dataIndex: "displayName",
    width: 260,
    render: (_value, row) => <LongText width={235}>{(row as BusinessWarehouse).displayName}</LongText>,
  },
  {
    title: "来源编码",
    dataIndex: "code",
    width: 140,
    render: (_value, row) => (row as BusinessWarehouse).code ?? "未提供",
  },
  {
    title: "关联营业厅",
    dataIndex: "associatedStores",
    width: 180,
    render: (_value, row) => storePreview((row as BusinessWarehouse).associatedStores),
  },
  {
    title: "状态",
    dataIndex: "enabled",
    width: 120,
    render: (_value, row) => <StatusTag value={(row as BusinessWarehouse).enabled} />,
  },
];

function WarehouseDetails({ warehouse }: { warehouse: BusinessWarehouse }) {
  return <Space direction="vertical" size="large" style={{ width: "100%" }}>
    <DetailSection title="仓库资料">
      <Descriptions column={1} data={[
        { label: "仓库名称", value: warehouse.displayName },
        { label: "来源编码", value: warehouse.code ?? "未提供" },
        { label: "仓库类型", value: warehouse.type ?? "来源未提供" },
        { label: "状态", value: <StatusTag value={warehouse.enabled} /> },
        { label: "关联营业厅数", value: warehouse.associatedStores.length + " 个" },
      ]} />
    </DetailSection>
    <DetailSection title={"完整关联营业厅（" + warehouse.associatedStores.length + "）"}>
      {warehouse.associatedStores.length > 0
        ? <div className="basic-source-list">
          {warehouse.associatedStores.map((store) => <article className="basic-source-item" key={store.id}>
            <Typography.Text><strong>{store.displayName}</strong></Typography.Text>
            <Typography.Text type="secondary">
              来源厅：{store.sourceRecords.map((hall) => asText(hall.name) ?? "营业厅名称未提供").join("、") || "来源未映射"}
            </Typography.Text>
          </article>)}
        </div>
        : <Typography.Text type="secondary">当前没有关联营业厅。</Typography.Text>}
    </DetailSection>
    {warehouse.associatedStores.length > 1 && <Alert
      type="info"
      showIcon
      title="多营业厅共享此仓库"
      content="所有关联营业厅均保留；仓库身份和库存归属未合并。"
    />}
  </Space>;
}

export function WarehouseListPage({ readOnlyReason }: { readOnlyReason: string }) {
  return <BasicDataPage
    title="仓库"
    description="查看仓库及关联营业厅"
    countLabel="仓库"
    emptyDescription="没有符合条件的仓库；可清空搜索条件。"
    tableMinWidth={850}
    readOnlyReason={readOnlyReason}
    fetcher={warehousesFetcher}
    columns={warehouseColumns}
    detailTitle={(warehouse) => "仓库 · " + (warehouse as BusinessWarehouse).displayName}
    renderDetails={(warehouse) => <WarehouseDetails warehouse={warehouse as BusinessWarehouse} />}
  />;
}
