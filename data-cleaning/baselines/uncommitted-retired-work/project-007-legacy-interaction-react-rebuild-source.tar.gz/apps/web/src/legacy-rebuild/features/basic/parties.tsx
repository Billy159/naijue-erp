import { Descriptions, Space, Tag } from "@arco-design/web-react";
import { BasicDataPage, DetailSection, LongText, StatusTag, type BasicColumn } from "./BasicDataPage";
import { customersFetcher } from "./data";
import {
  asRecord,
  asText,
  sourcePayload,
  type BasicReferenceEntity,
} from "./model";

function customerRole(record: BasicReferenceEntity): { label: string; sourceValue: string | null } {
  const sourceValue = asText(sourcePayload(record.raw).role);
  return { label: sourceValue === "customer" ? "客户" : sourceValue ? "未知角色" : "未设置", sourceValue };
}

function sourceNature(record: BasicReferenceEntity): string {
  const source = asRecord(sourcePayload(record.raw).source);
  return asText(source["性质"]) ?? "来源未提供";
}

const partyColumns: BasicColumn[] = [
  {
    title: "客户名称",
    dataIndex: "displayName",
    width: 300,
    render: (_value, row) => <LongText width={275}>{(row as BasicReferenceEntity).displayName}</LongText>,
  },
  {
    title: "来源编码",
    dataIndex: "code",
    width: 170,
    render: (_value, row) => (row as BasicReferenceEntity).code ?? "未提供",
  },
  {
    title: "角色",
    dataIndex: "role",
    width: 120,
    render: (_value, row) => {
      const role = customerRole(row as BasicReferenceEntity);
      return role.label === "客户"
        ? <Tag color="arcoblue">客户</Tag>
        : <Tag color="orange">{role.label}{role.sourceValue ? " · " + role.sourceValue : ""}</Tag>;
    },
  },
  {
    title: "关联信息",
    dataIndex: "enabled",
    width: 170,
    render: (_value, row) => <Space size="small">
      <StatusTag value={typeof (row as BasicReferenceEntity).raw.enabled === "boolean" ? (row as BasicReferenceEntity).raw.enabled as boolean : null} />
      <span>来源性质：{sourceNature(row as BasicReferenceEntity)}</span>
    </Space>,
  },
];

function PartyDetails({ party }: { party: BasicReferenceEntity }) {
  const role = customerRole(party);
  return <Space direction="vertical" size="large" style={{ width: "100%" }}>
    <DetailSection title="客户资料">
      <Descriptions column={1} data={[
        { label: "名称", value: party.displayName },
        { label: "客户编码", value: party.code ?? "来源未提供" },
        { label: "角色标签", value: role.label === "客户" ? "客户" : role.label + (role.sourceValue ? " · " + role.sourceValue : "") },
        { label: "状态", value: <StatusTag value={typeof party.raw.enabled === "boolean" ? party.raw.enabled as boolean : null} /> },
      ]} />
    </DetailSection>
    <DetailSection title="业务属性"><Descriptions column={1} data={[{label:"客户性质",value:sourceNature(party)}]} /></DetailSection>
  </Space>;
}

export function PartyListPage({ readOnlyReason }: { readOnlyReason: string }) {
  return <BasicDataPage
    title="往来单位"
    description="查看客户资料与业务资格"
    countLabel="客户资料"
    emptyDescription="没有符合条件的客户；可清空搜索条件。"
    tableMinWidth={900}
    readOnlyReason={readOnlyReason}
    fetcher={customersFetcher}
    columns={partyColumns}
    detailTitle={(party) => "客户 · " + (party as BasicReferenceEntity).displayName}
    renderDetails={(party) => <PartyDetails party={party as BasicReferenceEntity} />}
  />;
}
