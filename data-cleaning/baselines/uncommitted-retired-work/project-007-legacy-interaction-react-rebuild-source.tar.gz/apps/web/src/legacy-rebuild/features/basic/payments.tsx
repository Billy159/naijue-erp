import { Alert, Button, Descriptions, Popover, Space, Table, Tag, Typography } from "@arco-design/web-react";
import { BasicDataPage, DetailSection, LongText, StatusTag, type BasicColumn } from "./BasicDataPage";
import { accountsFetcher, paymentMethodsFetcher } from "./data";
import {
  type FundAccountView,
  type HallScopeReference,
  type PaymentMethodView,
} from "./model";

const paymentMethodColumns: BasicColumn[] = [
  {
    title: "收款方式",
    dataIndex: "displayName",
    width: 280,
    render: (_value, row) => <LongText width={260}>{(row as PaymentMethodView).displayName}</LongText>,
  },
  {
    title: "来源编码",
    dataIndex: "code",
    width: 150,
    render: (_value, row) => (row as PaymentMethodView).code ?? "未提供",
  },
  {
    title: "默认账户提示",
    dataIndex: "defaultAccountName",
    width: 230,
    render: (_value, row) => <LongText width={210}>{(row as PaymentMethodView).defaultAccountName ?? "未设置"}</LongText>,
  },
  {
    title: "状态",
    dataIndex: "enabled",
    width: 130,
    render: (_value, row) => <StatusTag value={(row as PaymentMethodView).enabled} />,
  },
];

function PaymentMethodDetails({ method }: { method: PaymentMethodView }) {
  return <Space direction="vertical" size="large" style={{ width: "100%" }}>
    <DetailSection title="收款方式资料">
      <Descriptions column={1} data={[
        { label: "名称", value: method.displayName },
        { label: "来源编码", value: method.code ?? "未提供" },
        { label: "状态", value: <StatusTag value={method.enabled} /> },
        { label: "来源类型", value: method.origin ?? "来源未提供" },
        { label: "来源默认账户提示", value: method.defaultAccountName ?? "未设置" },
      ]} />
    </DetailSection>
    <Alert
      type="info"
      showIcon
      title="方式定义不代表资金已到账"
      content="此页只读取收款方式资料，不展示到账状态、收款事实或账户余额。当前服务未开放方式新增、编辑或排序。"
    />
  </Space>;
}

export function PaymentMethodsPage({ readOnlyReason }: { readOnlyReason: string }) {
  return <BasicDataPage
    title="收款方式"
    description="查看收款方式及默认账户提示"
    countLabel="收款方式"
    emptyDescription="没有符合条件的收款方式；可清空搜索条件。"
    tableMinWidth={850}
    readOnlyReason={readOnlyReason + " 页面不提供拖动排序、编辑或保存入口。"}
    fetcher={paymentMethodsFetcher}
    columns={paymentMethodColumns}
    detailTitle={(method) => "收款方式 · " + (method as PaymentMethodView).displayName}
    renderDetails={(method) => <PaymentMethodDetails method={method as PaymentMethodView} />}
  />;
}

function paymentMethodLabel(account: FundAccountView): string {
  if (account.primaryPaymentMethod.kind === "known") return account.primaryPaymentMethod.value;
  if (!account.primaryPaymentMethodId) return "主要方式未设置";
  const sourceCode = account.primaryPaymentMethodCode ? " · 来源编码 " + account.primaryPaymentMethodCode : "";
  return "方式未映射" + sourceCode;
}

function hallPreview(scopes: readonly HallScopeReference[]) {
  if (scopes.length === 0) return <Typography.Text type="secondary">未设置关联范围</Typography.Text>;
  return <Popover
    title={"关联营业厅 · " + scopes.length + " 个来源身份"}
    content={<Space direction="vertical" size="small">
      {scopes.slice(0, 3).map((scope) => <Typography.Text key={scope.id}>
        {scope.label}{scope.sourceCode ? " · " + scope.sourceCode : ""}
      </Typography.Text>)}
      {scopes.length > 3 && <Typography.Text type="secondary">另有 {scopes.length - 3} 个；详情中保留完整范围</Typography.Text>}
    </Space>}
  >
    <Button type="text" size="small" aria-label={"预览 " + scopes.length + " 个关联营业厅"}>
      {scopes.length} 个营业厅
    </Button>
  </Popover>;
}

const accountColumns: BasicColumn[] = [
  {
    title: "资金账户",
    dataIndex: "displayName",
    width: 260,
    render: (_value, row) => <LongText width={240}>{(row as FundAccountView).displayName}</LongText>,
  },
  {
    title: "账户编码",
    dataIndex: "code",
    width: 140,
    render: (_value, row) => (row as FundAccountView).code ?? "未提供",
  },
  {
    title: "主要方式",
    dataIndex: "primaryPaymentMethod",
    width: 220,
    render: (_value, row) => <LongText width={200}>{paymentMethodLabel(row as FundAccountView)}</LongText>,
  },
  {
    title: "关联范围",
    dataIndex: "hallScopes",
    width: 190,
    render: (_value, row) => hallPreview((row as FundAccountView).hallScopes),
  },
  {
    title: "状态",
    dataIndex: "enabled",
    width: 120,
    render: (_value, row) => <StatusTag value={(row as FundAccountView).enabled} />,
  },
];

const scopeColumns: BasicColumn[] = [
  {
    title: "营业厅",
    dataIndex: "label",
    width: 220,
    render: (_value, row) => <LongText width={200}>{(row as HallScopeReference).label}</LongText>,
  },
  {
    title: "来源编码",
    dataIndex: "sourceCode",
    width: 140,
    render: (_value, row) => (row as HallScopeReference).sourceCode ?? "未映射",
  },
];

function AccountDetails({ account }: { account: FundAccountView }) {
  const unknownScopes = account.hallScopes.filter((scope) => !scope.mapped);
  return <Space direction="vertical" size="large" style={{ width: "100%" }}>
    <DetailSection title="资金账户资料">
      <Descriptions column={1} data={[
        { label: "账户名称", value: account.displayName },
        { label: "来源编码", value: account.code ?? "来源未提供" },
        { label: "账号名称", value: account.accountNumber ?? "来源未提供" },
        { label: "账户类型", value: account.accountType ?? "来源未提供" },
        { label: "开户银行", value: account.bank ?? "来源未提供" },
        { label: "主要收款方式", value: paymentMethodLabel(account) },
        { label: "状态", value: <StatusTag value={account.enabled} /> },
      ]} />
    </DetailSection>
    <DetailSection title={"完整营业厅关联范围（" + account.hallScopes.length + "）"}>
      {account.hallScopes.length > 0
        ? <div className="basic-relation-scroll">
          <Table
            rowKey="id"
            columns={scopeColumns}
            data={account.hallScopes}
            size="small"
            pagination={false}
            scroll={{ x: 400, y: 340 }}
          />
        </div>
        : <Typography.Text type="secondary">来源没有配置关联营业厅。</Typography.Text>}
      {unknownScopes.length > 0 && <Alert
        className="basic-detail-note"
        type="warning"
        showIcon
        title="存在未映射的来源范围"
        content={`${unknownScopes.length} 个营业厅名称暂不可用；原关系仍保留。`}
      />}
      {account.sourceHallCodes.length > 0 && <Typography.Text type="secondary">
        来源营业厅编码记录：{account.sourceHallCodes.join("、")}
      </Typography.Text>}
    </DetailSection>
    <DetailSection title="账户业务边界">
      <Descriptions column={1} data={[
        { label: "关联范围口径", value: "按服务端返回的来源营业厅身份逐条展示，共 " + account.hallScopes.length + " 个" },
        { label: "服务端支付范围", value: "此页面不修改账户可选营业厅范围" },
      ]} />
      <Alert
        className="basic-detail-note"
        type="info"
        showIcon
        content="这里展示账户资料和关系，不表示已收款，也不读取或推算账户余额。"
      />
    </DetailSection>
  </Space>;
}

export function FundAccountsPage({ readOnlyReason }: { readOnlyReason: string }) {
  return <BasicDataPage
    title="资金账户"
    description="查看账户与营业厅使用范围"
    countLabel="资金账户"
    emptyDescription="没有符合条件的资金账户；可清空搜索条件。"
    tableMinWidth={1040}
    readOnlyReason={readOnlyReason}
    fetcher={accountsFetcher}
    columns={accountColumns}
    detailTitle={(account) => "资金账户 · " + (account as FundAccountView).displayName}
    renderDetails={(account) => <AccountDetails account={account as FundAccountView} />}
  />;
}
