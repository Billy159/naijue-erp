import { Alert, Descriptions, Space, Tag, Typography } from "@arco-design/web-react";
import { BasicDataPage, DetailSection, LongText, type BasicColumn } from "./BasicDataPage";
import { staffFetcher } from "./data";
import { type StaffView } from "./model";

const staffColumns: BasicColumn[] = [
  {
    title: "员工",
    dataIndex: "displayName",
    width: 220,
    render: (_value, row) => <LongText width={200}>{(row as StaffView).displayName}</LongText>,
  },
  {
    title: "来源编码",
    dataIndex: "code",
    width: 140,
    render: (_value, row) => (row as StaffView).code ?? "未提供",
  },
  {
    title: "业务角色",
    dataIndex: "role",
    width: 150,
    render: (_value, row) => {
      const role = (row as StaffView).role;
      return role.sourceValue && role.label === "未设置"
        ? <Tag color="orange">未设置 · {role.sourceValue}</Tag>
        : role.label === "未设置" ? <Tag color="gray">未设置</Tag> : <Tag color="arcoblue">{role.label}</Tag>;
    },
  },
  {
    title: "营业厅归属",
    dataIndex: "hallScope",
    width: 230,
    render: (_value, row) => {
      const scope = (row as StaffView).hallScope;
      return scope
        ? <LongText width={210}>{scope.label + (scope.sourceCode ? " · " + scope.sourceCode : "")}</LongText>
        : "来源未提供";
    },
  },
  {
    title: "账号状态",
    dataIndex: "accountStatus",
    width: 140,
    render: (_value, row) => {
      const status = (row as StaffView).accountStatus;
      return <Tag color={status.created ? (status.enabled ? "green" : "orange") : "gray"}>{status.label}</Tag>;
    },
  },
];

function StaffDetails({ staff }: { staff: StaffView }) {
  return <Space direction="vertical" size="large" style={{ width: "100%" }}>
    <DetailSection title="基本资料">
      <Descriptions column={1} data={[
        { label: "员工姓名", value: staff.displayName },
        { label: "来源编码", value: staff.code ?? "未提供" },
      ]} />
    </DetailSection>
    <DetailSection title="业务角色">
      <Descriptions column={1} data={[
        { label: "角色", value: staff.role.label === "未设置" && staff.role.sourceValue
          ? "未设置（来源值：" + staff.role.sourceValue + "）"
          : staff.role.label },
        { label: "来源业务员标记", value: staff.isSourceSalesperson === null ? "未提供" : staff.isSourceSalesperson ? "是" : "否" },
      ]} />
    </DetailSection>
    <DetailSection title="营业厅 / 仓库范围">
      <Descriptions column={1} data={[
        { label: "营业厅归属", value: staff.hallScope
          ? staff.hallScope.label + (staff.hallScope.sourceCode ? " · " + staff.hallScope.sourceCode : "")
          : staff.hallId ? "营业厅名称暂不可用" : "来源未提供" },
        { label: "仓库授权范围", value: "员工资料来源未提供仓库授权范围" },
      ]} />
    </DetailSection>
    <DetailSection title="账号状态">
      <Descriptions column={1} data={[
        { label: "账号", value: <Tag color={staff.accountStatus.created ? "arcoblue" : "gray"}>{staff.accountStatus.label}</Tag> },
        { label: "登录已启用", value: staff.accountStatus.created ? (staff.accountStatus.enabled ? "是" : "否") : "未开通" },
      ]} />
      {!staff.accountStatus.created && <Alert
        className="basic-detail-note"
        type="info"
        showIcon
        content="员工资料存在不代表系统账号已开通；此页不会自动创建账号或测试账号。"
      />}
    </DetailSection>
  </Space>;
}

export function StaffListPage({ readOnlyReason }: { readOnlyReason: string }) {
  return <BasicDataPage
    title="员工与账号"
    description="员工、业务角色与账号状态"
    countLabel="员工"
    emptyDescription="没有符合条件的员工；可清空搜索条件。"
    tableMinWidth={850}
    readOnlyReason={readOnlyReason}
    fetcher={staffFetcher}
    columns={staffColumns}
    detailTitle={(staff) => "员工 · " + (staff as StaffView).displayName}
    renderDetails={(staff) => <StaffDetails staff={staff as StaffView} />}
  />;
}
