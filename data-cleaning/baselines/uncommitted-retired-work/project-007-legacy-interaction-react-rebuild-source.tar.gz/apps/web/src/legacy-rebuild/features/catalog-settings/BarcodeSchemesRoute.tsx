import { useState } from "react";
import { Button, Descriptions, Modal, Table } from "@arco-design/web-react";
import type { TableProps } from "@arco-design/web-react";
import "../products/products.css";

interface Scheme {
  id: string; name: string; prefix: string; length: number; parts: readonly (readonly [string, number])[];
  current: boolean;
}
const schemes: readonly Scheme[] = [
  {id: "2026", name: "2026 条码方案", prefix: "5", length: 15, parts: [["版型", 1], ["系统货号", 7], ["颜色", 3], ["尺码", 3]], current: true},
  {id: "2023", name: "2023年条码方案", prefix: "9", length: 14, parts: [["系统货号", 7], ["颜色", 3], ["尺码", 3]], current: false},
  {id: "2021fit", name: "2021年版型条码方案", prefix: "2", length: 14, parts: [["系统货号", 7], ["版型", 1], ["颜色", 3], ["尺码", 2]], current: false},
  {id: "2021", name: "2021年条码方案", prefix: "6", length: 13, parts: [["系统货号", 7], ["颜色", 3], ["尺码", 2]], current: false},
  {id: "2020", name: "2020年新方案", prefix: "0", length: 14, parts: [["系统货号", 7], ["颜色", 3], ["尺码", 3]], current: false},
  {id: "2018", name: "2018年货品", prefix: "8", length: 9, parts: [["自由编码", 5], ["颜色", 1], ["尺码", 2]], current: false},
];
const summary = (scheme: Scheme) => `识别码${scheme.prefix.length}＋${scheme.parts.map(([name, length]) => `${name}${length}`).join("＋")}`;

export function BarcodeSchemesRoute() {
  const [selected, setSelected] = useState<Scheme | null>(null);
  const columns: NonNullable<TableProps["columns"]> = [
    {title: "方案名称", dataIndex: "name", key: "name", width: 220},
    {title: "条码类型", key: "type", width: 100, render: () => "Code128"},
    {title: "编码规则", key: "rule", width: 360, render: (_value, raw) => summary(raw as Scheme)},
    {title: "总长度", key: "length", width: 100, render: (_value, raw) => `${(raw as Scheme).length} 位`},
    {title: "状态", key: "status", width: 110, render: (_value, raw) => (raw as Scheme).current ? "启用" : "旧商品使用"},
    {title: "默认方案", key: "default", width: 130, render: (_value, raw) => (raw as Scheme).current ? "新建商品默认" : "—"},
    {title: "操作", key: "action", width: 78, fixed: "right", render: (_value, raw) => <Button type="text" onClick={() => setSelected(raw as Scheme)}>查看</Button>},
  ];
  return <section className="lr-product-editor">
    <div className="lr-product-head"><h1>条码方案</h1></div>
    <div className="lr-product-list-panel"><div className="lr-product-table-wrap"><Table rowKey="id" columns={columns} data={[...schemes]} pagination={false} scroll={{x: 1098}} /></div></div>
    <p className="lr-product-help">2026 方案用于正常新增商品：识别码 5＋版型 Y/A/B/C/D/E＋系统货号7位＋颜色3位＋尺码3位。旧五套方案及历史条码保留原值；代码缺失或位数不符时不生成新条码。</p>
    <Modal visible={selected !== null} title="查看条码方案" style={{width: "min(620px, 94vw)"}} onCancel={() => setSelected(null)} footer={<Button onClick={() => setSelected(null)}>关闭</Button>}>
      {selected && <Descriptions column={1} data={[
        {label: "方案名称", value: selected.name}, {label: "条码类型", value: "Code128"},
        {label: "编码规则", value: <>识别码 {selected.prefix.length} 位（{selected.prefix}）{selected.parts.map(([name, length]) => <div key={name}>{name} {length} 位</div>)}</>},
        {label: "总长度", value: `${selected.length} 位`},
      ]} />}
    </Modal>
  </section>;
}
