import { useEffect, useMemo, useState } from "react";
import { Alert, Button, Empty, Input, Message, Space, Tree } from "@arco-design/web-react";
import { ErrorState, LoadingState } from "@stage05";
import { readAllReferences, type ReferenceRecord } from "../products/data";
import "../products/products.css";

type CategoryState = { kind: "loading" } | { kind: "error"; message: string } | { kind: "ready"; rows: ReferenceRecord[] };
interface CategoryTreeNode {
  key: string;
  title: string;
  children?: CategoryTreeNode[];
}

export function treeForCategories(rows: readonly ReferenceRecord[]): CategoryTreeNode[] {
  const nodes = new Map<string, CategoryTreeNode>();
  const rowById = new Map<string, ReferenceRecord>();
  for (const row of rows) {
    if (nodes.has(row.id)) throw new Error(`分类ID重复：${row.id}`);
    nodes.set(row.id, { key: row.id, title: row.name || row.code || row.id, children: [] });
    rowById.set(row.id, row);
  }
  const roots: CategoryTreeNode[] = [];
  for (const row of rows) {
    const node = nodes.get(row.id)!;
    const parent = row.parent_id ? nodes.get(row.parent_id) : null;
    if (parent && parent.key !== node.key) parent.children!.push(node);
    else roots.push(node);
  }
  // Keep malformed or orphaned source records visible rather than dropping them.
  const attached = new Set<string>();
  const mark = (node: CategoryTreeNode) => {
    if (attached.has(node.key)) return;
    attached.add(node.key);
    node.children?.forEach(mark);
  };
  roots.forEach(mark);
  for (const node of nodes.values()) if (!attached.has(node.key)) roots.push(node);
  for (const node of nodes.values()) {
    if (!rowById.has(node.key)) throw new Error("分类树来源身份校验失败");
    node.children?.sort((a, b) => a.title.localeCompare(b.title, "zh-CN"));
    if (!node.children?.length) delete node.children;
  }
  roots.sort((a, b) => a.title.localeCompare(b.title, "zh-CN"));
  return roots;
}

export function CatalogCategoriesRoute() {
  const [state, setState] = useState<CategoryState>({ kind: "loading" });
  const [retryVersion, setRetryVersion] = useState(0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const rows = state.kind === "ready" ? state.rows : [];
  const treeData = useMemo(() => state.kind === "ready" ? treeForCategories(state.rows) : [], [state]);
  const visibleTree = useMemo(() => {
    if (!search.trim()) return treeData;
    const q = search.trim().toLocaleLowerCase();
    const filter = (node: CategoryTreeNode): CategoryTreeNode | null => {
      const children = node.children?.map(filter).filter((value): value is CategoryTreeNode => value !== null) || [];
      return node.title.toLocaleLowerCase().includes(q) || children.length ? children.length ? {...node, children} : {key: node.key, title: node.title} : null;
    };
    return treeData.map(filter).filter((value): value is CategoryTreeNode => value !== null);
  }, [search, treeData]);
  const selected = rows.find(row => row.id === selectedId) || null;

  useEffect(() => {
    const abort = new AbortController();
    setState({ kind: "loading" });
    void readAllReferences("categories", abort.signal).then(next => {
      if (!abort.signal.aborted) setState({ kind: "ready", rows: next });
    }).catch(error => {
      if (!abort.signal.aborted) setState({ kind: "error", message: error instanceof Error ? error.message : "分类资料读取失败" });
    });
    return () => abort.abort();
  }, [retryVersion]);

  if (state.kind === "loading") return <LoadingState text="正在读取真实分类资料" />;
  if (state.kind === "error") return <ErrorState message={state.message} onRetry={() => setRetryVersion(value => value + 1)} />;

  const noWrite = () => Message.warning("当前真实服务未开放商品分类写入；来源分类未改变。");
  return <section className="lr-product-editor">
    <div className="lr-product-head"><h1>商品分类</h1><Space wrap><Button onClick={noWrite}>新增一级分类</Button><Button onClick={noWrite}>新增子分类</Button>{selected && <><Button onClick={() => setSelectedId(null)}>取消</Button><Button type="primary" onClick={noWrite}>保存</Button></>}</Space></div>
    <Alert type="info" showIcon content="当前分类资料来自真实服务；新增、排序、删除和保存尚未开放。" />
    <div className="lr-product-category-layout">
      <aside className="lr-product-category-tree">
        <Input.Search aria-label="搜索分类" value={search} onChange={setSearch} placeholder="搜索分类" />
        <Tree
          treeData={visibleTree}
          selectedKeys={selectedId ? [selectedId] : []}
          showLine
          blockNode
          defaultExpandedKeys={rows.map(row => row.id)}
          onSelect={keys => setSelectedId(keys.length ? String(keys[0]) : null)}
        />
        <p className="lr-product-help">选择分类查看资料。来源顺序保留；当前不能拖动排序。</p>
      </aside>
      <section className="lr-product-category-detail">
        {!selected ? <Empty description="选择分类查看资料，或新增一级分类" /> : <><h2>分类资料</h2><div className="lr-product-editor-grid"><label className="lr-product-editor-field"><span>父分类</span><Input readOnly value={selected.parent_code ? rows.find(row => row.code === selected.parent_code)?.name || "来源未提供" : "无（一级分类）"} /></label><label className="lr-product-editor-field"><span>分类名称</span><Input readOnly value={selected.name || ""} /></label></div><div className="lr-product-delete-zone"><Button status="danger" type="text" onClick={noWrite}>删除分类</Button></div></>}
      </section>
    </div>
  </section>;
}
