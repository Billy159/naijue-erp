import { useEffect, useMemo, useState } from "react";
import { Alert, Button, Input, Message, Modal, Pagination, Select, Space, Table, Tabs } from "@arco-design/web-react";
import type { TableProps } from "@arco-design/web-react";
import { ErrorState, LoadingState, readSpecReferenceDictionary, type SpecReferenceRecord, type SkuLookup } from "@stage05";
import { makeReadModel } from "@stage05/features/catalog-settings/ProductSettingsRoute";
import { loadSkuProjection } from "../products/skuRepository";
import "../products/products.css";

export { makeReadModel } from "@stage05/features/catalog-settings/ProductSettingsRoute";

type Dictionaries = {colors: SpecReferenceRecord[]; sizes: SpecReferenceRecord[]};
type Ready = {kind: "ready"; lookup: SkuLookup; dictionaries: Dictionaries};
type State = {kind: "loading"} | {kind: "error"; message: string} | Ready;
const fitCodes: Record<string, string> = {Y: "3", A: "5", B: "6", C: "7", D: "8", E: "9"};
const attributeGroups = [
  {title: "厚薄", rows: ["薄款", "常规", "厚款"]},
  {title: "领型", rows: ["圆领", "中领", "高领", "西装领", "翻领", "立领", "立翻领", "棒球领", "带帽", "交叉领"]},
  {title: "裤型", rows: ["正常裤脚", "裤脚偏小", "裤脚偏大", "大版裤", "小脚裤"]},
] as const;

export function ProductSettingsRoute() {
  const [state, setState] = useState<State>({kind: "loading"});
  const [retry, setRetry] = useState(0);
  const [activeTab, setActiveTab] = useState("colors");
  const [historyOpen, setHistoryOpen] = useState(false);
  const [historySearch, setHistorySearch] = useState("");
  const [historyPage, setHistoryPage] = useState(1);
  const [colorOpen, setColorOpen] = useState<SpecReferenceRecord | null>(null);
  const [groupOpen, setGroupOpen] = useState<{name: string; columns: string[]} | null>(null);
  useEffect(() => {
    const abort = new AbortController(); setState({kind: "loading"});
    void Promise.all([
      loadSkuProjection(), readSpecReferenceDictionary("colors", abort.signal), readSpecReferenceDictionary("sizes", abort.signal),
    ]).then(([lookup, colors, sizes]) => {if (!abort.signal.aborted) setState({kind: "ready", lookup, dictionaries: {colors, sizes}});})
      .catch(issue => {if (!abort.signal.aborted) setState({kind: "error", message: issue instanceof Error ? issue.message : "商品设置读取失败"});});
    return () => abort.abort();
  }, [retry]);
  const ready = state.kind === "ready" ? state : null;
  const model = useMemo(() => ready ? makeReadModel(ready.lookup) : null, [ready]);
  const historicalRows = useMemo(() => ready ? ready.dictionaries.sizes.filter(row => `${row.code || ""} ${row.name}`.toLocaleLowerCase().includes(historySearch.toLocaleLowerCase())) : [], [ready, historySearch]);
  if (state.kind === "loading") return <LoadingState text="正在读取商品颜色、尺码与版型" />;
  if (state.kind === "error") return <ErrorState message={state.message} onRetry={() => setRetry(value => value + 1)} />;
  if (!model) return null;

  const noWrite = () => Message.warning("当前真实服务未开放商品设置写入；来源资料未改变。");
  const colorColumns: NonNullable<TableProps["columns"]> = [
    {title: "颜色名称", dataIndex: "name", key: "name"},
    {title: "颜色代码", dataIndex: "code", key: "code", render: (_value, raw) => (raw as SpecReferenceRecord).code || "未设置"},
    {title: "操作", key: "action", width: 78, render: (_value, raw) => <Button type="text" onClick={() => setColorOpen(raw as SpecReferenceRecord)}>编辑</Button>},
  ];
  const groupColumns: NonNullable<TableProps["columns"]> = [
    {title: "组名称", dataIndex: "name", key: "name", width: 180},
    {title: "包含尺码", key: "columns", render: (_value, raw) => (raw as typeof model.groups[number]).columns.join("、")},
    {title: "操作", key: "action", width: 78, render: (_value, raw) => <Button type="text" onClick={() => setGroupOpen(raw as typeof model.groups[number])}>编辑</Button>},
  ];
  const fitColumns: NonNullable<TableProps["columns"]> = [
    {title: "版型码", dataIndex: "code", key: "code"},
    {title: "版型", dataIndex: "name", key: "name"},
    {title: "条码代码", key: "barcode", render: (_value, raw) => fitCodes[(raw as typeof model.fits[number]).code] || "—"},
  ];
  const historicalColumns: NonNullable<TableProps["columns"]> = [
    {title: "原始编码", key: "code", dataIndex: "code", render: (_value, raw) => (raw as SpecReferenceRecord).code || "—"},
    {title: "历史尺码", key: "name", dataIndex: "name"},
    {title: "关联规格", key: "spec", render: () => "—"},
    {title: "关联条码", key: "barcode", render: () => "—"},
  ];
  return <section className="lr-product-editor">
    <div className="lr-product-head"><h1>商品设置</h1></div>
    <div className="lr-product-editor-panel"><Tabs activeTab={activeTab} destroyOnHide={false} onChange={setActiveTab}>
      <Tabs.TabPane key="colors" title="颜色"><div className="lr-product-editor-section"><Space wrap><Input.Search aria-label="搜索颜色" placeholder="搜索名称或编码" style={{width: 240}} /><Button onClick={noWrite}>新增颜色</Button></Space><Table rowKey="id" columns={colorColumns} data={state.dictionaries.colors} size="small" pagination={{pageSize: 50}} scroll={{x: 500}} /></div></Tabs.TabPane>
      <Tabs.TabPane key="groups" title="尺码组"><div className="lr-product-editor-section"><Space><h3>新商品尺码组</h3><Button onClick={() => {setHistoryOpen(true); setHistoryPage(1);}}>历史尺码资料</Button></Space><Table rowKey="name" columns={groupColumns} data={model.groups} size="small" pagination={false} scroll={{x: 700}} /><p className="lr-product-help">新商品使用标准尺码组。历史商品保留原尺码与原编码，不自动转换。</p></div></Tabs.TabPane>
      <Tabs.TabPane key="fits" title="版型"><div className="lr-product-editor-section"><p className="lr-product-help">商品级固定版型，所有分类均可选择；历史版型统一兼容为六种。</p><Table rowKey="code" columns={fitColumns} data={model.fits} size="small" pagination={false} /></div></Tabs.TabPane>
      <Tabs.TabPane key="seasons" title="季节"><div className="lr-product-editor-section"><p className="lr-product-help">季节可多选：春、夏、秋、冬。历史春夏对应春、夏，秋冬对应秋、冬。</p><Table rowKey="name" columns={[{title: "季节", dataIndex: "name", key: "name"}]} data={["春季", "夏季", "秋季", "冬季"].map(name => ({name}))} pagination={false} /></div></Tabs.TabPane>
      <Tabs.TabPane key="attributes" title="商品属性"><div className="lr-product-attribute-grid">{attributeGroups.map(group => <section key={group.title}><div className="lr-product-attribute-head"><h3>{group.title}</h3><Button onClick={noWrite}>新增{group.title}</Button></div><Table rowKey="name" columns={[{title: "名称", dataIndex: "name", key: "name"}, {title: "操作", key: "action", width: 70, render: () => <Button type="text" onClick={noWrite}>编辑</Button>}]} data={group.rows.map(name => ({name}))} pagination={false} size="small" /></section>)}</div></Tabs.TabPane>
    </Tabs></div>
    <Alert type="info" showIcon content="商品设置当前仅查询。新增、编辑和排序需要真实服务写入能力，点击相关操作会提示当前限制。" />
    <Modal visible={colorOpen !== null} title="查看颜色" onCancel={() => setColorOpen(null)} footer={<Button onClick={() => setColorOpen(null)}>关闭</Button>}>
      {colorOpen && <div className="lr-product-editor-grid"><label className="lr-product-editor-field"><span>颜色名称</span><Input value={colorOpen.name} readOnly /></label><label className="lr-product-editor-field"><span>颜色代码</span><Input value={colorOpen.code || ""} readOnly /></label></div>}
    </Modal>
    <Modal visible={groupOpen !== null} title="编辑尺码组" style={{width: "min(940px, 94vw)"}} onCancel={() => setGroupOpen(null)} footer={<Button onClick={() => setGroupOpen(null)}>关闭</Button>}>
      {groupOpen && <><label className="lr-product-editor-field"><span>名称</span><Input readOnly value={groupOpen.name} /></label><Table rowKey="name" columns={[{title: "尺码名称", dataIndex: "name", key: "name"}]} data={groupOpen.columns.map(name => ({name}))} pagination={false} /></>}
    </Modal>
    <Modal visible={historyOpen} title="历史尺码资料" style={{width: "min(940px, 94vw)"}} onCancel={() => setHistoryOpen(false)} footer={<Button onClick={() => setHistoryOpen(false)}>关闭</Button>}>
      <p className="lr-product-help">历史尺码仅用于兼容旧商品、颜色尺码和条码，不用于新商品。</p>
      <div className="lr-product-attribute-head"><Input.Search aria-label="搜索历史尺码" placeholder="搜索历史名称或编码" value={historySearch} onChange={value => {setHistorySearch(value); setHistoryPage(1);}} style={{width: 260}} /><span>来源：尺码.xlsx · {state.dictionaries.sizes.length} 条</span></div>
      <p className="lr-product-help">原始文件未提供商品规格和条码关联关系，关联数量显示 —。</p>
      <Table rowKey="id" columns={historicalColumns} data={historicalRows.slice((historyPage-1)*30, historyPage*30)} pagination={false} size="small" scroll={{y: 320}} />
      <div className="lr-product-pagination"><span>共 {historicalRows.length} 条 · {historyPage} / {Math.max(1,Math.ceil(historicalRows.length/30))} 页</span><Pagination size="small" simple current={historyPage} total={historicalRows.length} pageSize={30} onChange={setHistoryPage} /></div>
      <p className="lr-product-help">新尺码名称与历史名称相同，也不会自动共享编码；已有规格和条码身份按原关系保留。</p>
    </Modal>
  </section>;
}
