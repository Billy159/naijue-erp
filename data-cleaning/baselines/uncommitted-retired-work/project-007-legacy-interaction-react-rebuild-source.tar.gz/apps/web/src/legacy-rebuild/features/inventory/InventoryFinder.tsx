import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { Button, Input } from "@arco-design/web-react";
import type { CatalogProduct, InventoryReferences } from "./data";
import { legacySkuOrder } from "./legacySkuOrder";
import { historicalYearSeason } from "../../shared/historicalAttributes";
import "./inventory.css";

interface Match { product:CatalogProduct; rank:number }
interface Props {
  value:string;
  refs:InventoryReferences|null;
  onChange:(value:string)=>void;
  onSelect:(code:string,skuId:string|null)=>void;
  onSubmit:(keyword?:string)=>void;
  onPaste?:(event:React.ClipboardEvent<HTMLDivElement>)=>void;
  onUnresolved?:(query:string,count:number)=>void;
  showHistory?:boolean;
  allowBarcodeFragments?:boolean;
  allowBarcodeMatch?:boolean;
  continuous?:boolean;
  placeholder?:string;
  enterQueries?:boolean;
}
const historyKey="erp-inventory-search-history-v2";
function history():string[]{try{const raw=JSON.parse(localStorage.getItem(historyKey)||"[]");return Array.isArray(raw)?raw.filter((item):item is string=>typeof item==="string").slice(0,15):[];}catch{return [];}}
export function rememberInventorySearch(value:string){const q=value.trim();if(q)localStorage.setItem(historyKey,JSON.stringify([q,...history().filter(item=>item!==q)].slice(0,15)));}
function rankProducts(refs:InventoryReferences|null,raw:string,allowBarcodeFragments:boolean,allowBarcodeMatch:boolean):Match[]{
  const q=raw.trim().toLocaleLowerCase();if(!refs)return [];
  const mapped=allowBarcodeMatch?refs.lookup.barcode(raw.trim()):null;
  const mappedIds=new Set(mapped?.kind==="sku"?[mapped.sku.product.productId]:mapped?.kind==="product-only"?mapped.productIds:[]);
  const result:Match[]=[];
  for(const product of refs.catalog.products){
    const identity=refs.lookup.productByCode(product.code);
    if(!identity||!refs.lookup.skusForProduct(identity.productId).length)continue;
    const code=product.code.toLocaleLowerCase(),name=product.name.toLocaleLowerCase();
    const item=String(product.attributes?.defaultBarcode||product.attributes?.source&&((product.attributes.source as Record<string,unknown>)["默认条码"])||"").toLocaleLowerCase();
    let rank=!q?6:code===q?0:code.endsWith(q)?1:code.startsWith(q)?2:code.includes(q)?3:name.includes(q)?4:allowBarcodeFragments&&item.includes(q)&&item?5:Infinity;
    if(mappedIds.has(identity.productId))rank=0;
    if(Number.isFinite(rank))result.push({product,rank});
  }
  result.sort((a,b)=>a.rank-b.rank||a.product.code.localeCompare(b.product.code));
  return result;
}
function Highlight({value,query}:{value:string;query:string}){
  const i=value.toLocaleLowerCase().indexOf(query.toLocaleLowerCase());
  return i<0||!query?value:<>{value.slice(0,i)}<mark>{value.slice(i,i+query.length)}</mark>{value.slice(i+query.length)}</>;
}
function ProductPreview({product,refs}:{product:CatalogProduct;refs:InventoryReferences}){
  const attributes=product.attributes||{};
  const identity=refs.lookup.productByCode(product.code);
  const skus=identity?legacySkuOrder(refs.lookup.skusForProduct(identity.productId)):[];
  const colors=[...new Set(skus.map(sku=>sku.color.name))];
  const supplier=refs.suppliers.find(item=>item.id===product.counterparty_id)?.name;
  const price=attributes.price??(attributes.source&&((attributes.source as Record<string,unknown>)["零售价"]));
  const {year,season}=historicalYearSeason(attributes);
  const values:[string,unknown][]=[
    ["款号",product.code],["商品名称",product.name],["颜色",colors.join(" / ")],
    ["商品分类",product.category_name||refs.categories.find(item=>(item.code||item.id)===product.category_code)?.name],
    ["年份",year],["季节",season],["版型",skus[0]?.fit.name||product.fit_name],
    ["供应商",supplier],["零售价",price===null||price===undefined||price===""?null:Number(price).toFixed(2)],
    ["厚薄",attributes.thickness],["领型 / 裤型",attributes.sourceShapeName],
  ];
  const images=Array.isArray(attributes.images)?attributes.images.flatMap(item=>typeof item==="string"?[item]:item&&typeof item==="object"&&typeof (item as Record<string,unknown>).url==="string"?[(item as Record<string,string>).url]:[]):[];
  return <aside className="lr-finder-preview"><div className="lr-finder-images">{images.length?images.map((url,i)=><img key={`${url}:${i}`} src={url} alt="商品图片" onError={event=>{event.currentTarget.style.display="none"}} />):<small>该商品尚未提供图片</small>}</div>{values.filter(([,value])=>value!==null&&value!==undefined&&value!=="").map(([label,value])=><span key={label}><small>{label}</small> {String(value)}</span>)}</aside>;
}

export function InventoryFinder({value,refs,onChange,onSelect,onSubmit,onPaste,onUnresolved,showHistory=true,allowBarcodeFragments=false,allowBarcodeMatch=true,continuous=false,placeholder="输入货号后几位／商品名称",enterQueries=false}:Props){
  const wrapperRef=useRef<HTMLDivElement|null>(null),popupRef=useRef<HTMLDivElement|null>(null),composing=useRef(false);
  const [open,setOpen]=useState(false),[mode,setMode]=useState<"matches"|"history">("matches"),[active,setActive]=useState(-1),[limit,setLimit]=useState(8),[recent,setRecent]=useState<string[]>([]),[position,setPosition]=useState({left:8,top:0,width:660,maxHeight:350});
  const matches=useMemo(()=>rankProducts(refs,value,allowBarcodeFragments,allowBarcodeMatch),[refs,value,allowBarcodeFragments,allowBarcodeMatch]);
  const shown=matches.slice(0,limit);
  const close=useCallback(()=>setOpen(false),[]);
  const positionPopup=useCallback(()=>{
    const anchor=wrapperRef.current?.querySelector("input"),popup=popupRef.current;if(!anchor||!popup)return;
    const rect=anchor.getBoundingClientRect(),width=mode==="history"?rect.width:Math.min(660,innerWidth-16);
    const below=innerHeight-rect.bottom-12,above=rect.top-12;
    const maxHeight=Math.max(100,Math.min(350,Math.max(below,above)));
    const height=Math.min(popup.scrollHeight,maxHeight);
    setPosition({left:Math.max(8,Math.min(rect.left,innerWidth-width-8)),top:mode==="history"||below>=height+8?rect.bottom+4:Math.max(8,rect.top-height-4),width,maxHeight:mode==="history"?innerHeight:maxHeight});
  },[mode]);
  useLayoutEffect(()=>{if(open)positionPopup();},[open,mode,value,limit,active,positionPopup]);
  useEffect(()=>{if(!open)return;const outside=(event:PointerEvent)=>{const target=event.target as Node;if(!popupRef.current?.contains(target)&&!wrapperRef.current?.contains(target))close();};document.addEventListener("pointerdown",outside,true);document.addEventListener("scroll",positionPopup,true);window.addEventListener("resize",positionPopup);return()=>{document.removeEventListener("pointerdown",outside,true);document.removeEventListener("scroll",positionPopup);window.removeEventListener("resize",positionPopup);};},[open,close,positionPopup]);
  useEffect(()=>{setActive(-1);setLimit(8);},[value]);
  const select=(code:string)=>{
    rememberInventorySearch(code);close();
    const mapped=allowBarcodeMatch?refs?.lookup.barcode(value.trim()):null;
    const skuId=mapped?.kind==="sku"&&mapped.sku.product.sourceCode===code?mapped.sku.identity.skuId:null;
    onSelect(code,skuId);
    if(continuous)requestAnimationFrame(()=>wrapperRef.current?.querySelector("input")?.focus());
  };
  const submit=()=>{rememberInventorySearch(value);close();onSubmit();};
  const handleChange=(next:string)=>{onChange(next);setMode("matches");setOpen(showHistory||Boolean(next.trim()));};
  const handleFocus=()=>{if(value){setMode("matches");setOpen(true);}else if(showHistory){setRecent(history());setMode("history");setOpen(true);}};
  const keyDown=(event:React.KeyboardEvent<HTMLInputElement>)=>{
    if(composing.current||event.nativeEvent.isComposing||event.keyCode===229)return;
    if(event.key==="Escape"&&open){event.preventDefault();close();return;}
    if(event.key==="Tab"){close();return;}
    if(event.key==="ArrowDown"||event.key==="ArrowUp"){
      if(!open)return;event.preventDefault();const length=mode==="history"?recent.length:matches.length;if(length){const next=(active+(event.key==="ArrowDown"?1:-1)+length)%length;setActive(next);if(mode==="matches")setLimit(current=>Math.max(current,next+1));}return;
    }
    if(event.key==="Enter"){
      event.preventDefault();
      if(!continuous&&enterQueries){if(open&&mode==="history"&&active>=0&&recent[active]){rememberInventorySearch(recent[active]);close();onSubmit(recent[active]);return;}submit();return;}
      if(open&&active>=0){if(mode==="history"&&recent[active]){if(continuous){onChange(recent[active]);setMode("matches");setOpen(true);}else{rememberInventorySearch(recent[active]);close();onSubmit(recent[active]);}return;}if(mode==="matches"&&matches[active]){select(matches[active].product.code);return;}}
      if(continuous&&value.trim()){
        const exact=matches.filter(match=>match.product.code.toLocaleLowerCase()===value.trim().toLocaleLowerCase());
        if(exact.length===1)select(exact[0]!.product.code);
        else if(matches.length===1)select(matches[0]!.product.code);
        else onUnresolved?.(value.trim(),matches.length);
        return;
      }
      submit();
    }
  };
  return <div ref={wrapperRef} className="lr-inventory-finder" onPaste={onPaste}>
    <Input aria-label="商品搜索" aria-expanded={open} aria-controls="lr-inventory-finder-popup" value={value} onChange={handleChange} onFocus={handleFocus} onKeyDown={keyDown} onCompositionStart={()=>{composing.current=true;}} onCompositionEnd={event=>{composing.current=false;handleChange(event.currentTarget.value);}} autoComplete="off" placeholder={placeholder} />
    {open&&createPortal(<div ref={popupRef} id="lr-inventory-finder-popup" className="lr-inventory-finder-popup" role="dialog" aria-label={mode==="history"?"最近搜索":"商品候选"} style={{left:position.left,top:position.top,width:position.width,maxHeight:position.maxHeight}} onMouseDown={event=>event.preventDefault()}>
      {mode==="history"?<div className="lr-finder-history"><strong>最近搜索</strong>{recent.map((item,i)=><div key={`${item}:${i}`}><Button type="text" aria-selected={active===i} onMouseEnter={()=>setActive(i)} onClick={()=>{if(continuous){onChange(item);setMode("matches");setOpen(true);wrapperRef.current?.querySelector("input")?.focus();}else{rememberInventorySearch(item);close();onSubmit(item);}}}>{item}</Button><Button type="text" aria-label="删除这条搜索记录" onClick={()=>{const next=recent.filter((_,index)=>index!==i);localStorage.setItem(historyKey,JSON.stringify(next));setRecent(next);}}>×</Button></div>)}<Button type="text" onClick={()=>{localStorage.removeItem(historyKey);setRecent([]);}}>清空搜索历史</Button></div>:
      <div className="lr-finder-layout"><div className="lr-finder-list" role="listbox">{shown.length?shown.map((match,i)=><Button type="text" key={match.product.code} role="option" aria-selected={active===i} onMouseEnter={()=>setActive(i)} onClick={()=>select(match.product.code)}><strong><Highlight value={match.product.code} query={value.trim()} /></strong><span>{match.product.name}</span></Button>):<p>没有匹配结果，请继续输入</p>}{matches.length>limit?<Button type="text" className="lr-finder-more" onClick={()=>setLimit(limit+20)}>已显示 {shown.length} / {matches.length} 项 · 查看更多匹配</Button>:matches.length?<small>共 {matches.length} 项 · 回车或点击确认</small>:null}</div>{shown.length&&refs?<ProductPreview product={shown[Math.max(0,Math.min(active,shown.length-1))]!.product} refs={refs} />:null}</div>}
    </div>,document.body)}
  </div>;
}
