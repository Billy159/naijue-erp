import { useEffect, useState } from "react";
import { Button, DatePicker, Drawer, Input, Modal, Pagination, Select, Spin, Table } from "@arco-design/web-react";
import type { TableProps } from "@arco-design/web-react";
import { api, type RuntimeLedgerEntry, type RuntimeLedgerPage, type SkuLookup } from "@stage05";
import { readAllReferences } from "../products/data";
import { loadSkuProjection } from "../products/skuRepository";

export interface LedgerTarget {skuId:string;warehouseId:string;range:"recent"|"all"}
interface Identity {lookup:SkuLookup;productName:string;warehouseName:string}
interface Filters {start:string;end:string;type:string;source:string}
interface Result {loading:boolean;error:string;page:RuntimeLedgerPage|null}

export function recentLedgerDates(now=new Date()):{start:string;end:string}{
  const day=(offset:number)=>{const date=new Date(now.getFullYear(),now.getMonth(),now.getDate()+offset);return `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,"0")}-${String(date.getDate()).padStart(2,"0")}`;};
  return {start:day(-29),end:day(0)};
}
export function InventoryLedgerDrawer({target,onClose,onOpenSource}:{target:LedgerTarget|null;onClose:()=>void;onOpenSource:(entry:RuntimeLedgerEntry)=>void}){
  const [identity,setIdentity]=useState<Identity|null>(null),[identityError,setIdentityError]=useState("");
  const [draft,setDraft]=useState<Filters>({start:"",end:"",type:"",source:""}),[applied,setApplied]=useState<Filters>({start:"",end:"",type:"",source:""});
  const [page,setPage]=useState(1),[retry,setRetry]=useState(0),[error,setError]=useState("");
  const [result,setResult]=useState<Result>({loading:false,error:"",page:null}),[purchase,setPurchase]=useState<RuntimeLedgerEntry|null>(null);
  useEffect(()=>{if(!target){setIdentity(null);return;}const dates=target.range==="recent"?recentLedgerDates():{start:"",end:""};const initial={...dates,type:"",source:""};setDraft(initial);setApplied(initial);setPage(1);setResult({loading:true,error:"",page:null});setError("");
    const abort=new AbortController();void Promise.all([loadSkuProjection(),readAllReferences("warehouses",abort.signal)]).then(async([lookup,warehouses])=>{const sku=lookup.skuById(target.skuId),warehouse=warehouses.find(row=>row.id===target.warehouseId);if(!sku||!warehouse)throw Error("流水规格或仓库未匹配");const product=await api.getProduct(sku.product.sourceCode,abort.signal);if(!abort.signal.aborted)setIdentity({lookup,productName:product.name||"名称未提供",warehouseName:warehouse.name||"未设置"});}).catch(issue=>{if(!abort.signal.aborted)setIdentityError(issue instanceof Error?issue.message:"流水身份读取失败");});return()=>abort.abort();
  },[target?.skuId,target?.warehouseId,target?.range]);
  useEffect(()=>{if(!target)return;const abort=new AbortController();setResult(previous=>({...previous,loading:true,error:""}));void api.listLedger({skuId:target.skuId,warehouseId:target.warehouseId,page,...applied},abort.signal).then(value=>{if(!abort.signal.aborted)setResult({loading:false,error:"",page:value});}).catch(issue=>{if(!abort.signal.aborted)setResult(previous=>({loading:false,error:issue instanceof Error?issue.message:"流水读取失败",page:previous.page}));});return()=>abort.abort();},[target?.skuId,target?.warehouseId,page,applied,retry]);
  const sku=target&&identity?.lookup.skuById(target.skuId),total=result.page?.total||0;
  const query=()=>{if(draft.start&&draft.end&&draft.start>draft.end){setError("开始日期不能晚于结束日期");return;}setError("");setPage(1);setApplied({...draft});};
  const columns:NonNullable<TableProps["columns"]>=[
    {title:"时间",dataIndex:"time",width:152,render:(_v,raw)=>(raw as RuntimeLedgerEntry).time.replace("T"," ").slice(0,19)},
    {title:"业务类型",dataIndex:"type",width:92},
    {title:"变化",width:80,align:"right",render:(_v,raw)=>{const value=(raw as RuntimeLedgerEntry).delta;return value.startsWith("-")?value:`+${value}`;}},
    {title:"变化前 → 后",width:135,render:(_v,raw)=>{const row=raw as RuntimeLedgerEntry;return `${row.before} → ${row.after}`;}},
    {title:"来源单据",width:200,render:(_v,raw)=>{const row=raw as RuntimeLedgerEntry;return row.documentType==="PURCHASE"?<Button type="text" size="mini" onClick={()=>setPurchase(row)}>{row.source}</Button>:row.documentId&&(row.documentType==="SALE"||row.documentType==="TRANSFER")?<Button type="text" size="mini" onClick={()=>onOpenSource(row)}>{row.source}</Button>:row.source||"—";}},
    {title:"操作人",width:100,render:(_v,raw)=>(raw as RuntimeLedgerEntry).user||"历史未提供"},
  ];
  return <Drawer className="lr-inventory-ledger" visible={target!==null} title="库存流水" width="min(880px, 96vw)" footer={null} onCancel={onClose} escToExit>
    {target&&<div className="lr-inventory-ledger-body">
      {identityError&&<div role="alert" className="lr-inventory-feedback">{identityError}</div>}
      {sku&&<div className="lr-inventory-ledger-identity"><strong>{sku.product.sourceCode} {identity?.productName}</strong><p>{sku.color.name} / {sku.column.name} · {identity?.warehouseName} · 当前 {result.page?.quantity||"读取中"}</p></div>}
      <div className="lr-inventory-ledger-filter"><DatePicker aria-label="开始日期" {...(draft.start?{value:draft.start}:{})} onChange={start=>setDraft({...draft,start})} /><DatePicker aria-label="结束日期" {...(draft.end?{value:draft.end}:{})} onChange={end=>setDraft({...draft,end})} /><Select aria-label="业务类型" allowClear {...(draft.type?{value:draft.type}:{})} placeholder="全部类型" options={result.page?.types.map(type=>({label:type,value:type}))||[]} onChange={type=>setDraft({...draft,type:String(type||"")})} /><Input aria-label="来源单号" value={draft.source} onChange={source=>setDraft({...draft,source})} onPressEnter={query} placeholder="来源单号" /><Button type="primary" onClick={query}>查询</Button></div>
      {error&&<div role="alert" className="lr-inventory-feedback">{error}</div>}
      <div className="lr-inventory-ledger-hint">当前筛选 {total} 条 · 每页 20 条 · 按零期初重建的历史业务及后续变化</div>
      {result.error&&<div role="alert" className="lr-inventory-feedback">{result.error} <Button type="text" size="mini" onClick={()=>setRetry(value=>value+1)}>重试</Button></div>}
      <div className="lr-inventory-ledger-table">{result.loading&&!result.page?<div className="lr-inventory-loading"><Spin /> 正在读取流水…</div>:<Table rowKey="id" columns={columns} data={result.page?.items||[]} pagination={false} size="small" scroll={{x:759}} noDataElement="当前范围无流水" />}</div>
      <div className="lr-inventory-ledger-pages"><Pagination simple current={page} pageSize={20} total={total} onChange={setPage} /></div>
    </div>}
    <Modal title="来源单据" visible={purchase!==null} footer={<Button onClick={()=>setPurchase(null)}>返回库存流水</Button>} onCancel={()=>setPurchase(null)}>{purchase&&<div><h3>{purchase.source}</h3><p>进货 · {purchase.time.slice(0,10)}</p><p>{identity?.productName} / {sku?.column.name}</p><p>库存数量变化：{purchase.delta}</p></div>}</Modal>
  </Drawer>;
}
