import { useMemo, useState } from "react";
import { Button, Checkbox, Input, Popover } from "@arco-design/web-react";

interface Item {id:string;name:string}
interface Props {
  label:string;items:readonly Item[];value:readonly string[];onConfirm:(ids:string[])=>void;
  className?:string;allMeansUnfiltered?:boolean;searchPlaceholder?:string;
}
export function InventoryMultiPicker({label,items,value,onConfirm,className="",allMeansUnfiltered=false,searchPlaceholder="搜索名称"}:Props){
  const [open,setOpen]=useState(false),[q,setQ]=useState(""),[temporary,setTemporary]=useState<string[]>([]);
  const found=useMemo(()=>items.filter(item=>(item.name+" "+item.id).toLowerCase().includes(q.trim().toLowerCase())),[items,q]);
  const setVisible=(visible:boolean)=>{if(visible){setQ("");setTemporary(value.length?[...value]:allMeansUnfiltered?items.map(item=>item.id):[]);}setOpen(visible);};
  const checked=found.length>0&&found.every(item=>temporary.includes(item.id));
  const toggle=(id:string,on:boolean)=>setTemporary(previous=>on?[...new Set([...previous,id])]:previous.filter(value=>value!==id));
  const save=()=>{onConfirm(allMeansUnfiltered&&temporary.length===items.length?[]:temporary);setOpen(false);};
  const content=<div className="lr-inventory-picker" onKeyDown={event=>{if(event.key==="Escape")setOpen(false);}}>
    <div className="lr-inventory-picker-search"><Input value={q} onChange={setQ} placeholder={searchPlaceholder} aria-label={searchPlaceholder} /></div>
    <div className="lr-inventory-picker-tools"><Checkbox checked={checked} indeterminate={!checked&&found.some(item=>temporary.includes(item.id))} onChange={next=>setTemporary(previous=>next?[...new Set([...previous,...found.map(item=>item.id)])]:previous.filter(id=>!found.some(item=>item.id===id)))}>全选{label==="商品"?"":"搜索结果"}</Checkbox><span>匹配 {found.length} 项</span><Button type="text" size="mini" onClick={()=>setTemporary([])}>清空</Button></div>
    <div className="lr-inventory-picker-list">{found.map(item=><label key={item.id}><Checkbox checked={temporary.includes(item.id)} onChange={next=>toggle(item.id,next)} /><span>{item.name}</span></label>)}{!found.length&&<p>没有找到匹配项</p>}</div>
    <footer><span>已选 {temporary.length} 项</span><div><Button size="mini" onClick={()=>setOpen(false)}>取消</Button><Button size="mini" type="primary" onClick={save}>确定</Button></div></footer>
  </div>;
  return <Popover trigger="click" popupVisible={open} onVisibleChange={setVisible} content={content} position="bl"><Button className={`lr-inventory-picker-trigger ${className}`} aria-label={label} aria-expanded={open}><span>{label}</span><span aria-hidden="true">⌄</span></Button></Popover>;
}
