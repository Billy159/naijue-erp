import { useEffect, useMemo, useRef, useState } from "react";
import { Button, Checkbox, Input, Modal, Popover, Radio, Select, Space, Spin, Table, Tag, TreeSelect } from "@arco-design/web-react";
import type { TableProps } from "@arco-design/web-react";
import { IconFile } from "@arco-design/web-react/icon";
import { api, navigate, parseSignedQuantity, formatSignedQuantity, usePagedQuery, type RuntimeLedgerEntry, type SkuCell } from "@stage05";
import type { InventoryViewRow } from "@stage05/features/inventory/model";
import { EMPTY_FILTER, INVENTORY_PAGE_SIZES, fetchInventory, inventoryReferences, matchingProducts, type InventoryFilter, type InventoryMeta, type InventoryReferences } from "./data";
import { InventoryLedgerDrawer, type LedgerTarget } from "./InventoryLedgerDrawer";
import { InventoryFinder, rememberInventorySearch } from "./InventoryFinder";
import { resolveBulkProducts, splitProductCodes } from "./bulkSelection";
import { buildDefaultCsv, buildPrintHtml, buildYintaiCsv, loadAllInventoryRows } from "./report";
import { historicalYearSeason } from "../../shared/historicalAttributes";
import "./inventory.css";

interface MatrixValue { text:string; entries?:readonly SkuCell[]; warehouseId?:string }
interface MatrixRecord {key:string;kind:"warehouse"|"subtotal"|"total";code:string;productName:string;color:string;colorId:string;warehouse:string;total:string;values:Record<string,MatrixValue>;showProduct:boolean;showColor:boolean;folded?:boolean}
type Settings = {category:boolean;supplier:boolean;fit:boolean;sizeGroup:boolean;season:boolean;subtotal:boolean;total:boolean;sizeDescription:boolean};
const defaultSettings:Settings={category:true,supplier:false,fit:false,sizeGroup:false,season:false,subtotal:true,total:true,sizeDescription:false};

function sum(values:Iterable<string>):string{let n=0n;for(const value of values)n+=parseSignedQuantity(value);return formatSignedQuantity(n);}
function scope(filter:InventoryFilter,refs:InventoryReferences|null):string{
  const pieces=[filter.productCodes.length?`已选${filter.productCodes.length}款商品`:filter.keyword?`关键词：${filter.keyword}`:"全部库存"];
  if(filter.categoryCode)pieces.push(refs?.categories.find(row=>(row.code||row.id)===filter.categoryCode)?.name||"商品分类");
  if(filter.warehouseIds.length)pieces.push(`${filter.warehouseIds.length}个仓库`);
  for(const [label,values] of [["供应商",filter.supplierIds],["版型",filter.fitCodes],["季节",filter.seasons]] as const)if(values.length)pieces.push(`${label}：${values.length}项`);
  return pieces.join(" · ");
}
function categoryTree(refs:InventoryReferences|null){
  if(!refs)return [];
  const byParent=new Map<string,typeof refs.categories>();
  for(const item of refs.categories){const parent=item.parent_code||"";byParent.set(parent,[...(byParent.get(parent)||[]),item]);}
  type TreeNode={key:string;title:string;children?:TreeNode[]};
  const node=(item:typeof refs.categories[number],visited:Set<string>):TreeNode=>{
    const key=item.code||item.id;if(visited.has(key))return {key,title:item.name||key};
    const children=(byParent.get(key)||[]).map(child=>node(child,new Set([...visited,key])));
    return {key,title:item.name||key,...(children.length?{children}:{})};
  };
  return (byParent.get("")||[]).map(item=>node(item,new Set()));
}
function categoryPaths(refs:InventoryReferences|null):Map<string,string>{
  const paths=new Map<string,string>();if(!refs)return paths;
  const byCode=new Map(refs.categories.map(item=>[item.code||item.id,item]));
  for(const item of refs.categories){
    const parts:string[]=[];const seen=new Set<string>();let current:typeof item|undefined=item;
    while(current){const code=current.code||current.id;if(seen.has(code))break;seen.add(code);parts.unshift(current.name||code);current=current.parent_code?byCode.get(current.parent_code):undefined;}
    paths.set(item.code||item.id,parts.join(" / "));
  }
  return paths;
}
function subtotalValues(code:string,colorId:string|undefined,group:string,meta:InventoryMeta|undefined,refs:InventoryReferences|null):Record<string,MatrixValue>{
  if(!meta||!refs)return {};
  const row=colorId?meta.source.colors.find(x=>x.code===code&&x.color_id===colorId):meta.source.products.find(x=>x.code===code);
  const product=refs.lookup.productByCode(code);if(!row||!product)return {};
  const skus=refs.lookup.skusForProduct(product.productId).filter(sku=>!colorId||sku.identity.colorId===colorId);
  const values=new Map<string,bigint>();
  for(const sku of skus)if(sku.groupName===group)values.set(sku.column.key,0n);
  for(const [sizeId,value] of Object.entries(row.cols)){
    const sku=skus.find(candidate=>candidate.identity.sizeId===sizeId&&candidate.groupName===group);
    if(!sku)continue;
    values.set(sku.column.key,(values.get(sku.column.key)||0n)+parseSignedQuantity(value));
  }
  return Object.fromEntries([...values].map(([key,value])=>[key,{text:formatSignedQuantity(value)}]));
}
function matrixGroups(rows:readonly InventoryViewRow[],meta:InventoryMeta|undefined,refs:InventoryReferences|null,foldedProducts:Set<string>,foldedColors:Set<string>,settings:Settings){
  const groups=new Map<string,{columns:InventoryViewRow["sections"][number]["group"]["columns"];rows:InventoryViewRow[]}>();
  for(const row of rows)for(const section of row.sections){const group=groups.get(section.group.name)||{columns:section.group.columns,rows:[]};group.rows.push(row);groups.set(section.group.name,group);}
  return [...groups].map(([name,group])=>{
    const products=new Map<string,InventoryViewRow[]>();
    for(const row of group.rows)products.set(row.code,[...(products.get(row.code)||[]),row]);
    const records:MatrixRecord[]=[];
    for(const [code,productRows] of products){
      const first=productRows[0]!;
      if(foldedProducts.has(code)){
        records.push({key:`${name}:p:${code}`,kind:"total",code,productName:first.productName,color:"",colorId:"",warehouse:"汇总",total:first.productTotal,values:subtotalValues(code,undefined,name,meta,refs),showProduct:true,showColor:false,folded:true});
        continue;
      }
      const colors=new Map<string,InventoryViewRow[]>();for(const row of productRows)colors.set(row.colorId,[...(colors.get(row.colorId)||[]),row]);
      let firstProduct=true;
      for(const [colorId,colorRows] of colors){const color=colorRows[0]!;
        if(foldedColors.has(`${code}:${colorId}`)){
          records.push({key:`${name}:c:${code}:${colorId}`,kind:"subtotal",code,productName:first.productName,color:color.colorName,colorId,warehouse:"汇总",total:color.colorTotal,values:subtotalValues(code,colorId,name,meta,refs),showProduct:firstProduct,showColor:true,folded:true});
          firstProduct=false;
          continue;
        }
        let firstColor=true;
        for(const row of colorRows){const section=row.sections.find(item=>item.group.name===name);if(!section)continue;
          const values=Object.fromEntries(section.row.cells.map(cell=>{
            const known=cell.entries.filter(entry=>entry.exists&&entry.displayValue!==null);
            return [cell.column.key,{text:known.length?sum(known.map(entry=>entry.displayValue!)):cell.missing?"0":"未读取",entries:cell.entries,warehouseId:row.warehouseId} as MatrixValue];
          }));
          records.push({key:`${name}:w:${row.key}`,kind:"warehouse",code,productName:first.productName,color:row.colorName,colorId,warehouse:row.warehouseName,total:row.total,values,showProduct:firstProduct,showColor:firstColor});
          firstProduct=false;firstColor=false;
        }
        const colorLast=meta?.source.colors.find(item=>item.code===code&&item.color_id===colorId)?.last;
        if(settings.subtotal&&colorLast===colorRows.at(-1)?.index)records.push({key:`${name}:c:${code}:${colorId}`,kind:"subtotal",code,productName:"",color:"",colorId,warehouse:"",total:color.colorTotal,values:subtotalValues(code,colorId,name,meta,refs),showProduct:false,showColor:false});
      }
      const productLast=meta?.source.products.find(item=>item.code===code)?.last;
      if(settings.total&&productLast===productRows.at(-1)?.index)records.push({key:`${name}:p:${code}`,kind:"total",code,productName:"",color:"",colorId:"",warehouse:"",total:first.productTotal,values:subtotalValues(code,undefined,name,meta,refs),showProduct:false,showColor:false});
    }
    return {name,columns:group.columns,records};
  });
}

export function InventoryRoute(){
  const {state,controller}=usePagedQuery<InventoryFilter,InventoryViewRow,InventoryMeta>(EMPTY_FILTER,200,fetchInventory);
  const [refs,setRefs]=useState<InventoryReferences|null>(null),[refError,setRefError]=useState<string|null>(null);
  const [more,setMore]=useState(false),[batchMode,setBatchMode]=useState(false),[bulkIssues,setBulkIssues]=useState<string[]>([]),[filterResetKey,setFilterResetKey]=useState(0);
  const [ledger,setLedger]=useState<LedgerTarget|null>(null),[foldedProducts,setFoldedProducts]=useState<Set<string>>(new Set()),[foldedColors,setFoldedColors]=useState<Set<string>>(new Set());
  const [settings,setSettings]=useState<Settings>(()=>{try{return {...defaultSettings,...JSON.parse(localStorage.getItem("erp-inventory-display-v2")||"{}")};}catch{return defaultSettings;}});
  const [settingsOpen,setSettingsOpen]=useState(false),[exportOpen,setExportOpen]=useState(false),[exportKind,setExportKind]=useState<"default"|"yintai">("default"),[exporting,setExporting]=useState(false);
  const [printOpen,setPrintOpen]=useState(false),[printHtml,setPrintHtml]=useState(""),[printing,setPrinting]=useState(false),[progress,setProgress]=useState("");
  const [jumpDraft,setJumpDraft]=useState("1"),[jumpError,setJumpError]=useState(""),[pageSizeOpen,setPageSizeOpen]=useState(false);
  const printRef=useRef<HTMLIFrameElement>(null),reportAbort=useRef<AbortController|null>(null);
  const tree=useMemo(()=>categoryTree(refs),[refs]);
  const paths=useMemo(()=>categoryPaths(refs),[refs]);
  const fitItems=useMemo(()=>["Y","A","B","C","D","E"].map(id=>({id,name:`${id}版`})),[]);
  const seasonItems=useMemo(()=>["春","夏","秋","冬"].map(id=>({id,name:id})),[]);
  const dirty=JSON.stringify(state.draft)!==JSON.stringify(state.applied);
  const groups=useMemo(()=>matrixGroups(state.items,state.meta??undefined,refs,foldedProducts,foldedColors,settings),[state.items,state.meta,refs,foldedProducts,foldedColors,settings]);
  useEffect(()=>{const abort=new AbortController();void inventoryReferences(abort.signal).then(value=>{if(abort.signal.aborted)return;setRefs(value);void controller.apply();}).catch(error=>{if(!abort.signal.aborted)setRefError(error instanceof Error?error.message:"基础资料读取失败");});return()=>abort.abort();},[controller]);
  useEffect(()=>{try{localStorage.setItem("erp-inventory-display-v2",JSON.stringify(settings));}catch{}},[settings]);
  useEffect(()=>()=>reportAbort.current?.abort(),[]);
  useEffect(()=>setJumpDraft(String(state.page)),[state.page]);
  const setFilter=(change:Partial<InventoryFilter>)=>controller.setDraft({...state.draft,...change});
  const query=()=>{
    const next={...state.draft,keyword:state.draft.productCodes.length?"":state.draft.keyword.trim()};
    rememberInventorySearch(next.keyword||next.productCodes[0]||"");
    setFoldedProducts(new Set());setFoldedColors(new Set());
    void controller.restore(next,1);
  };
  const reset=()=>{setFoldedProducts(new Set());setFoldedColors(new Set());setBulkIssues([]);setBatchMode(false);setFilterResetKey(value=>value+1);void controller.reset();};
  const addProduct=(code:string)=>{
    const selected=batchMode?[...new Set([...state.draft.productCodes,code])]:[code];
    setFilter({productCodes:selected,keyword:""});setBulkIssues([]);
  };
  const pasteProducts=(event:React.ClipboardEvent<HTMLDivElement>)=>{
    const raw=event.clipboardData.getData("text");
    const tokens=splitProductCodes(raw);
    if(tokens.length<2||!tokens.every(token=>/^[a-zA-Z0-9_-]+$/.test(token)))return;
    event.preventDefault();
    if(!refs){setBulkIssues(["商品资料尚未加载，请稍后重新粘贴"]);return;}
    const outcome=resolveBulkProducts(raw,refs.catalog.products);
    setBatchMode(true);
    setFilter({productCodes:[...new Set([...state.draft.productCodes,...outcome.codes])],keyword:""});
    setBulkIssues([...outcome.missing.map(token=>`${token}：未找到商品`),...outcome.ambiguous.map(item=>`${item.token}：匹配 ${item.count} 款，请手动选择`)]);
    requestAnimationFrame(()=>document.querySelector<HTMLInputElement>(".lr-inventory-keyword input")?.focus());
  };
  const toggleProduct=(code:string)=>setFoldedProducts(previous=>{const next=new Set(previous);next.has(code)?next.delete(code):next.add(code);return next;});
  const toggleColor=(code:string,color:string)=>setFoldedColors(previous=>{const next=new Set(previous),key=`${code}:${color}`;next.has(key)?next.delete(key):next.add(key);return next;});
  function showCell(value:MatrixValue|undefined){if(!value)return "0";const known=value.entries?.filter(entry=>entry.exists&&entry.displayValue!==null&&entry.skuId)||[];
    if(known.length===1)return <Button className="lr-matrix-number" data-sku-id={known[0]!.skuId!} type="text" size="mini" onClick={()=>setLedger({skuId:known[0]!.skuId!,warehouseId:value.warehouseId!,range:"recent"})}>{value.text}</Button>;
    return value.text;
  }
  function metaText(code:string){if(!refs)return "";const product=refs.catalog.products.find(item=>item.code===code),identity=refs.lookup.productByCode(code);if(!product)return "";
    const pieces:string[]=[];
    if(settings.category)pieces.push(refs.categories.find(item=>(item.code||item.id)===product.category_code)?.name||"未设置分类");
    if(settings.supplier)pieces.push(refs.suppliers.find(item=>item.id===product.counterparty_id)?.name||"未设置供应商");
    const first=identity?refs.lookup.skusForProduct(identity.productId)[0]:null;
    if(settings.fit)pieces.push(first?.fit.name||"未设置版型");
    if(settings.sizeGroup)pieces.push(first?.groupName||"未设置尺码组");
    if(settings.season)pieces.push(historicalYearSeason(product.attributes).season||"未设置季节");
    return pieces.join(" · ");
  }
  function columns(group:typeof groups[number]):NonNullable<TableProps["columns"]>{
    return [
      {title:"商品名称／款号",key:"product",width:240,fixed:"left",render:(_v,raw)=>{const row=raw as MatrixRecord;if(!row.productName)return row.kind==="subtotal"?"颜色小计":row.kind==="total"?"商品合计":"";return <div className="lr-inventory-product"><div>{row.showProduct?<Button type="text" size="mini" onClick={()=>toggleProduct(row.code)} aria-label={foldedProducts.has(row.code)?"展开商品":"折叠商品"}>{foldedProducts.has(row.code)?"▸":"▾"}</Button>:<span className="lr-inventory-fold-space" />}<strong>{row.code}</strong> <span title={row.productName}>{row.productName}</span></div>{row.showProduct&&metaText(row.code)&&<small>{metaText(row.code)}</small>}</div>;}},
      {title:"颜色",key:"color",width:92,fixed:"left",render:(_v,raw)=>{const row=raw as MatrixRecord;return row.showColor?<><Button type="text" size="mini" onClick={()=>toggleColor(row.code,row.colorId)} aria-label={foldedColors.has(`${row.code}:${row.colorId}`)?"展开颜色":"折叠颜色"}>{foldedColors.has(`${row.code}:${row.colorId}`)?"▸":"▾"}</Button>{row.color}</>:row.color;}},
      {title:"仓库",key:"warehouse",width:110,fixed:"left",render:(_v,raw)=>(raw as MatrixRecord).warehouse},
      ...group.columns.map(column=>({title:column.name,key:column.key,width:76,align:"right" as const,render:(_v:unknown,raw:unknown)=>showCell((raw as MatrixRecord).values[column.key])})),
      {title:"合计",key:"total",width:76,fixed:"right" as const,align:"right" as const,render:(_v,raw)=>(raw as MatrixRecord).total},
      {title:"操作",key:"action",width:110,fixed:"right" as const,render:(_v,raw)=>{const row=raw as MatrixRecord;return row.kind==="warehouse"?<Button type="text" size="mini" title="查看商品详情" aria-label="查看商品详情" onClick={()=>window.open(`/products/${encodeURIComponent(row.code)}`,"_blank","noopener")}><IconFile /></Button>:null;}},
    ];
  }
  async function download(content:string,name:string){const XLSX=await import("xlsx");const book=XLSX.read(content.replace(/^\ufeff/,""),{type:"string",raw:true});XLSX.writeFile(book,name,{compression:true});}
  async function exportAll(){if(!refs||!state.hasExecuted||state.error)return;const abort=new AbortController();reportAbort.current=abort;setExporting(true);setProgress(`正在读取 ${matchingProducts(state.applied,refs).length} 款商品的全部结果…`);try{
    const report=await loadAllInventoryRows(state.applied,refs,abort.signal,(done,total)=>setProgress(`已读取 ${done} / ${total} 条`));
    if(abort.signal.aborted)return;
    await download(exportKind==="yintai"?buildYintaiCsv(report,refs):buildDefaultCsv(report,refs),exportKind==="yintai"?"银泰库存状况.xlsx":"库存状况.xlsx");setExportOpen(false);
  }catch(error){if(!abort.signal.aborted)setProgress(error instanceof Error?`导出失败：${error.message}`:"导出失败，请重试");}finally{setExporting(false);if(reportAbort.current===abort)reportAbort.current=null;}}
  async function openPrint(){if(!refs||!state.hasExecuted||state.error)return;const abort=new AbortController();reportAbort.current=abort;setPrinting(true);setProgress("正在读取当前查询的全部结果…");try{
    const report=await loadAllInventoryRows(state.applied,refs,abort.signal,(done,total)=>setProgress(`已读取 ${done} / ${total} 条`));
    if(abort.signal.aborted)return;setPrintHtml(buildPrintHtml(report,refs,settings));setPrintOpen(true);
  }catch(error){if(!abort.signal.aborted)Modal.error({title:"打印预览失败",content:error instanceof Error?error.message:"请重试"});}finally{setPrinting(false);if(reportAbort.current===abort)reportAbort.current=null;}}
  const moreContent=<div className="lr-inventory-menu"><Button type="text" disabled={!state.hasExecuted||!!state.error||printing} loading={printing} onClick={()=>void openPrint()}>打印</Button></div>;
  const settingsContent=<div className="lr-inventory-settings"><strong>商品辅助字段</strong>{([["category","商品分类"],["supplier","供应商"],["fit","版型"],["sizeGroup","尺码组"],["season","季节"]] as const).map(([key,label])=><Checkbox key={key} checked={settings[key]} onChange={checked=>setSettings(previous=>({...previous,[key]:checked}))}>{label}</Checkbox>)}<strong>汇总显示</strong><Checkbox checked={settings.subtotal} onChange={checked=>setSettings({...settings,subtotal:checked})}>颜色小计</Checkbox><Checkbox checked={settings.total} onChange={checked=>setSettings({...settings,total:checked})}>商品合计</Checkbox><Checkbox checked={settings.sizeDescription} onChange={checked=>setSettings({...settings,sizeDescription:checked})}>显示尺码组说明</Checkbox><footer><Button type="text" size="mini" onClick={()=>setSettings(defaultSettings)}>恢复默认</Button><Button size="mini" onClick={()=>setSettingsOpen(false)}>关闭</Button></footer></div>;
  const warehouseLabel=state.draft.warehouseIds.length===1?refs?.warehouses.find(item=>item.id===state.draft.warehouseIds[0])?.name||"已选 1 个":`已选 ${state.draft.warehouseIds.length} 个`;
  const warehouseOptions=refs?.warehouses.map(item=>({value:item.id,label:item.name||item.code||"未命名"}))||[];
  const supplierOptions=refs?.suppliers.map(item=>({value:item.id,label:item.name||item.code||"未命名"}))||[];
  const pageCount=Math.max(1,Math.ceil(state.total/state.pageSize));
  const jump=()=>{const target=Number(jumpDraft);if(!/^\d+$/.test(jumpDraft)||target<1||target>pageCount){setJumpError(`请输入1至${pageCount}之间的页码`);return;}setJumpError("");void controller.setPage(target);};
  const pageSizeContent=<div className="lr-inventory-page-size-options">{INVENTORY_PAGE_SIZES.map(value=><Button key={value} type="text" aria-selected={state.pageSize===value} onClick={()=>{setPageSizeOpen(false);void controller.setPageSize(value);}}>{value}条/页 {state.pageSize===value?"✓":""}</Button>)}</div>;
  return <section className="lr-inventory">
    <header className="lr-inventory-head"><h1>库存状况表</h1><div className="lr-inventory-actions"><Button disabled={!state.hasExecuted||!!state.error||exporting} onClick={()=>{setExportKind("default");setProgress("");setExportOpen(true);}}>导出</Button><Button disabled={!state.hasExecuted} onClick={()=>void controller.reload()}>刷新</Button><Popover trigger="click" content={moreContent}><Button>更多操作</Button></Popover></div></header>
    <div className="lr-inventory-query"><div className="lr-inventory-query-row">
      <div className="lr-inventory-keyword"><InventoryFinder value={state.draft.keyword} refs={refs} continuous={batchMode} enterQueries allowBarcodeMatch={false} placeholder="输入款号或商品名称" onPaste={pasteProducts} onChange={keyword=>setFilter({keyword,productCodes:batchMode?state.draft.productCodes:[]})} onSelect={code=>addProduct(code)} onUnresolved={(term,count)=>setBulkIssues([count?`${term}：匹配 ${count} 款，请手动选择`:`${term}：未找到商品`])} onSubmit={keyword=>{if(keyword===undefined){query();return;}setFoldedProducts(new Set());setFoldedColors(new Set());void controller.restore({...state.draft,keyword,productCodes:[]},1);}} /><Button type={batchMode?"primary":"text"} aria-pressed={batchMode} onClick={()=>{setBatchMode(!batchMode);setBulkIssues([]);requestAnimationFrame(()=>document.querySelector<HTMLInputElement>(".lr-inventory-keyword input")?.focus());}}>批量选择</Button></div>
      <TreeSelect key={`category:${filterResetKey}`} aria-label="商品分类" treeData={tree} treeProps={{defaultExpandedKeys:tree.map(node=>node.key)}} showSearch allowClear value={state.draft.categoryCode} placeholder="分类：全部分类" renderFormat={(_node,value)=>`分类：${paths.get(String(value))||value}`} onChange={value=>setFilter({categoryCode:String(value||"")})} />
      <Select key={`warehouse:${refs?.warehouses.length||0}:${filterResetKey}`} className="lr-inventory-warehouse" aria-label="仓库" mode="multiple" showSearch allowClear value={state.draft.warehouseIds} options={warehouseOptions} placeholder={`全部仓库（${refs?.warehouses.length||0}）`} prefix="仓库：" maxTagCount={{count:0,render:()=>warehouseLabel}} onChange={value=>setFilter({warehouseIds:Array.isArray(value)?value.map(String):[]})} />
      <div className="lr-inventory-query-actions"><Button onClick={()=>setMore(!more)} aria-expanded={more}>更多筛选 {more?"▴":"▾"}</Button><Button type="primary" loading={state.loading!=="idle"} onClick={query}>查询</Button><Button onClick={reset}>重置</Button></div>
    </div>{state.draft.productCodes.length>0&&<div className="lr-inventory-selection" aria-label="已选商品"><span>已选 {state.draft.productCodes.length} 款</span>{state.draft.productCodes.map(code=><Tag key={code} size="small" closable onClose={()=>setFilter({productCodes:state.draft.productCodes.filter(value=>value!==code)})}>{code}</Tag>)}<Button type="text" size="mini" onClick={()=>setFilter({productCodes:[]})}>清空全部</Button></div>}
    {more&&<div className="lr-inventory-extra"><label>供应商<Select key={`supplier:${filterResetKey}`} aria-label="供应商" mode="multiple" showSearch allowClear value={state.draft.supplierIds} options={supplierOptions} placeholder="不限" maxTagCount={{count:0,render:()=>`已选 ${state.draft.supplierIds.length} 项`}} onChange={value=>setFilter({supplierIds:Array.isArray(value)?value.map(String):[]})} /></label><label>版型<Select key={`fit:${filterResetKey}`} aria-label="版型" mode="multiple" showSearch allowClear value={state.draft.fitCodes} options={fitItems.map(item=>({value:item.id,label:item.name}))} placeholder="不限" maxTagCount={{count:0,render:()=>`已选 ${state.draft.fitCodes.length} 项`}} onChange={value=>setFilter({fitCodes:Array.isArray(value)?value.map(String):[]})} /></label><label>季节<Select key={`season:${filterResetKey}`} aria-label="季节" mode="multiple" showSearch allowClear value={state.draft.seasons} options={seasonItems.map(item=>({value:item.id,label:item.name}))} placeholder="不限" maxTagCount={{count:0,render:()=>`已选 ${state.draft.seasons.length} 项`}} onChange={value=>setFilter({seasons:Array.isArray(value)?value.map(String):[]})} /></label></div>}
      {(dirty||bulkIssues.length>0)&&<div className="lr-inventory-query-note">{dirty&&<span>条件已修改 · 尚未查询</span>}{bulkIssues.map(issue=><span key={issue} className="lr-inventory-bulk-issue" role="status">{issue}</span>)}{bulkIssues.length>0&&<Button type="text" size="mini" onClick={()=>setBulkIssues([])}>关闭提示</Button>}</div>}
    </div>
    <div className="lr-inventory-toolbar"><div className="lr-inventory-stats"><Button type="text" size="mini" title={scope(state.meta?.applied??state.applied,refs)}>当前结果：{scope(state.meta?.applied??state.applied,refs)}</Button><span>共 <strong>{state.meta?.productCount??0}</strong> 款 · {(state.meta?.applied.warehouseIds??state.applied.warehouseIds).length||refs?.warehouses.length||0} 个仓库 · 库存合计 <strong>{state.meta?.queryTotal??"—"}</strong></span></div><Space size="small"><Button type="text" size="mini" onClick={()=>{setFoldedProducts(new Set());setFoldedColors(new Set());}}>展开全部</Button><Button type="text" size="mini" onClick={()=>{setFoldedProducts(new Set(state.items.map(row=>row.code)));setFoldedColors(new Set());}}>折叠全部</Button><Popover trigger="click" popupVisible={settingsOpen} onVisibleChange={setSettingsOpen} content={settingsContent}><Button type="text" size="mini">显示设置</Button></Popover></Space></div>
    {refError&&<div className="lr-inventory-feedback" role="alert">{refError}</div>}{state.error&&<div className="lr-inventory-feedback" role="alert">{state.error.message} <Button type="text" onClick={()=>void controller.reload()}>重试</Button></div>}
    <div className="lr-inventory-results" aria-busy={state.loading!=="idle"||(!refs&&!refError)}>{(state.loading==="initial"||(!refs&&!refError&&!state.hasExecuted))&&<div className="lr-inventory-loading"><Spin /> 正在查询库存…</div>}{state.hasExecuted&&!state.error&&state.total===0&&<div className="lr-inventory-empty">没有符合已执行条件的库存明细，请调整条件后查询。</div>}{groups.map(group=><section className="lr-inventory-group" key={group.name}><h2 hidden={!settings.sizeDescription}>{group.name}{settings.sizeDescription&&<small> · 按该商品正式业务尺码组显示</small>}</h2><Table className="lr-inventory-table" rowKey="key" columns={columns(group)} data={group.records} pagination={false} size="small" border={{wrapper:true,cell:false}} rowClassName={record=>`lr-matrix-${(record as MatrixRecord).kind}`} scroll={{x:240+92+110+group.columns.length*76+76+110}} /></section>)}</div>
    <footer className="lr-inventory-pagination"><Popover trigger="click" position="tl" popupVisible={pageSizeOpen} onVisibleChange={setPageSizeOpen} content={pageSizeContent}><Button className="lr-inventory-page-size" aria-label="每页库存明细条数">{state.pageSize}条/页 <span aria-hidden="true">⌄</span></Button></Popover><span>第{state.total?(state.page-1)*state.pageSize+1:0}–{Math.min(state.page*state.pageSize,state.total)}条，共{state.total}条库存明细</span>{pageCount>1&&<div className="lr-inventory-page-actions"><Button disabled={state.page<=1} onClick={()=>void controller.setPage(state.page-1)}>上一页</Button><span>第 {state.page} 页，共 {pageCount} 页</span><label>跳至 <Input aria-label="目标页码" inputMode="numeric" value={jumpDraft} onChange={setJumpDraft} onPressEnter={jump} /> 页</label><Button onClick={jump}>跳转</Button><Button disabled={state.page>=pageCount} onClick={()=>void controller.setPage(state.page+1)}>下一页</Button></div>}{jumpError&&<span role="alert" className="lr-inventory-page-error">{jumpError}</span>}</footer>
    <Modal title="导出库存" visible={exportOpen} style={{width:560}} onCancel={()=>{if(!exporting)setExportOpen(false);}} footer={<><Button disabled={exporting} onClick={()=>setExportOpen(false)}>取消</Button><Button type="primary" loading={exporting} onClick={()=>void exportAll()}>{exporting?"导出中…":"导出"}</Button></>}><div className="lr-inventory-export"><strong>选择导出模板</strong><Radio.Group value={exportKind} onChange={value=>setExportKind(value as "default"|"yintai")}><Radio value="default"><span><strong>默认库存明细</strong><small>按仓库分别展示，尺码横向排列。</small></span></Radio><Radio value="yintai"><span><strong>银泰库存模板</strong><small>按颜色、尺码合并所选仓库，保留各版型条码。</small></span></Radio></Radio.Group><p>导出当前查询的全部结果，不受分页影响。不包含小计、合计。</p>{progress&&<div role={progress.startsWith("导出失败")?"alert":"status"}>{progress}</div>}</div></Modal>
    <Modal className="lr-inventory-print" title={<div className="lr-inventory-print-head"><strong>库存打印预览</strong><span>已执行查询的全部结果</span><Button type="primary" onClick={()=>{printRef.current?.contentWindow?.focus();printRef.current?.contentWindow?.print();}}>打印</Button></div>} visible={printOpen} style={{width:"94vw"}} footer={null} onCancel={()=>setPrintOpen(false)}><iframe ref={printRef} title="库存分区全量打印预览" srcDoc={printHtml} /></Modal>
    <InventoryLedgerDrawer target={ledger} onClose={()=>setLedger(null)} onOpenSource={(entry:RuntimeLedgerEntry)=>{if(entry.documentId&&(entry.documentType==="SALE"||entry.documentType==="TRANSFER")){navigate(`/${entry.documentType==="SALE"?"sales":"transfers"}/${encodeURIComponent(entry.documentId)}`);}}} />
  </section>;
}
