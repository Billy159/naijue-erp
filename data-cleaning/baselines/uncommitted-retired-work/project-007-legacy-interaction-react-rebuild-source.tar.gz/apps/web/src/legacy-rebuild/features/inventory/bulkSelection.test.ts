import { strict as assert } from "node:assert";
import { test } from "node:test";
import { resolveBulkProducts } from "./bulkSelection";
import type { CatalogProduct } from "./data";

const products: CatalogProduct[] = [
  { id: "1", code: "026MS5133001", name: "针织衫" },
  { id: "2", code: "121MS5373276", name: "针织衫" },
  { id: "3", code: "709JK5386183", name: "夹克" },
];

test("bulk paste splits separators and deduplicates exact product codes", () => {
  assert.deepEqual(resolveBulkProducts("026MS5133001\n121MS5373276, 709JK5386183 026ms5133001", products), {
    codes: ["026MS5133001", "121MS5373276", "709JK5386183"], missing: [], ambiguous: [],
  });
});

test("bulk paste reports missing and ambiguous items without selecting a guess", () => {
  assert.deepEqual(resolveBulkProducts("针织衫 999MS", products), {
    codes: [], missing: ["999MS"], ambiguous: [{ token: "针织衫", count: 2 }],
  });
});
