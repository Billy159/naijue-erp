import type { CatalogProduct } from "./data";

export interface BulkSelectionResult {
  codes: string[];
  missing: string[];
  ambiguous: { token: string; count: number }[];
}

export function splitProductCodes(text: string): string[] {
  const seen = new Set<string>();
  return text.split(/[\s,，;；]+/).map(value => value.trim()).filter(value => {
    const key = value.toLocaleLowerCase();
    if (!key || seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function resolveBulkProducts(text: string, products: readonly CatalogProduct[]): BulkSelectionResult {
  const result: BulkSelectionResult = { codes: [], missing: [], ambiguous: [] };
  const added = new Set<string>();
  for (const token of splitProductCodes(text)) {
    const needle = token.toLocaleLowerCase();
    const exact = products.filter(product => product.code.toLocaleLowerCase() === needle);
    const candidates = exact.length ? exact : products.filter(product =>
      product.code.toLocaleLowerCase().includes(needle) || product.name.toLocaleLowerCase().includes(needle)
    );
    if (candidates.length === 1) {
      const code = candidates[0]!.code;
      if (!added.has(code)) { added.add(code); result.codes.push(code); }
    } else if (candidates.length === 0) result.missing.push(token);
    else result.ambiguous.push({ token, count: candidates.length });
  }
  return result;
}
