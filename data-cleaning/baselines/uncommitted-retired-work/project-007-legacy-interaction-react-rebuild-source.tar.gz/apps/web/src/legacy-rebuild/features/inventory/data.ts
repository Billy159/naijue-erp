import { api, type PageFetcher, type ProductRecord, type RuntimeInventoryPage, type SkuLookup } from "@stage05";
import { readAllReferences, type ReferenceRecord } from "@stage05/features/products/data";
import { loadSkuProjection } from "../products/skuRepository";
import { projectInventoryPage, type InventoryViewRow } from "@stage05/features/inventory/model";
import { historicalYearSeason } from "../../shared/historicalAttributes";

export interface InventoryFilter {
  keyword: string;
  productCodes: string[];
  categoryCode: string;
  warehouseIds: string[];
  supplierIds: string[];
  fitCodes: string[];
  seasons: string[];
}
export const EMPTY_FILTER: InventoryFilter = {keyword:"",productCodes:[],categoryCode:"",warehouseIds:[],supplierIds:[],fitCodes:[],seasons:[]};
export const INVENTORY_PAGE_SIZES = [100,200,500] as const;
export type InventoryPageSize = typeof INVENTORY_PAGE_SIZES[number];
export interface CatalogProduct {
  id:string; code:string; name:string; category_code?:string|null; counterparty_id?:string|null;
  category_name?:string|null; fit_name?:string|null; attributes?:Record<string,unknown>|null;
}
export interface Catalog {products:CatalogProduct[]}
export interface InventoryReferences {
  warehouses:ReferenceRecord[];
  categories:ReferenceRecord[];
  suppliers:ReferenceRecord[];
  catalog:Catalog;
  lookup:SkuLookup;
}
export interface InventoryMeta {productCount:number;queryTotal:string;pageTotal:string;source:RuntimeInventoryPage;applied:InventoryFilter}

let catalogPromise:Promise<Catalog>|null=null;
const productCache=new Map<string,ProductRecord>();
function catalog():Promise<Catalog>{
  if(!catalogPromise){const next=api.getRuntimeCatalog<Catalog>();catalogPromise=next;void next.catch(()=>{if(catalogPromise===next)catalogPromise=null;});}
  return catalogPromise;
}
if(typeof window!=="undefined")window.addEventListener("stage05:route",()=>{if(window.location.pathname==="/login"){catalogPromise=null;productCache.clear();}});

export async function inventoryReferences(signal:AbortSignal):Promise<InventoryReferences>{
  const [warehouses,categories,suppliers,raw,lookup]=await Promise.all([
    readAllReferences("warehouses",signal),readAllReferences("categories",signal),readAllReferences("suppliers",signal),catalog(),loadSkuProjection(),
  ]);
  if(signal.aborted)throw new DOMException("Aborted","AbortError");
  if(raw.products.length!==lookup.products.length)throw Error("商品目录与SKU投影数量不一致");
  return {warehouses,categories,suppliers,catalog:raw,lookup};
}

function categorySet(code:string,categories:readonly ReferenceRecord[]):Set<string>{
  const allowed=new Set([code]);
  let changed=true;
  while(changed){changed=false;for(const row of categories){const key=row.code||row.id;if(row.parent_code&&allowed.has(row.parent_code)&&!allowed.has(key)){allowed.add(key);changed=true;}}}
  return allowed;
}
export function matchingProducts(filter:InventoryFilter,refs:InventoryReferences):string[]{
  const tokens=filter.keyword.trim().split(/[\s,，;；]+/).filter(Boolean);
  const many=tokens.length>1;
  const wanted=new Set(tokens.map(value=>value.toLowerCase()));
  const allowed=filter.categoryCode?categorySet(filter.categoryCode,refs.categories):null;
  let barcodeProduct:string|null=null;
  if(tokens.length===1){const code=refs.lookup.barcode(tokens[0]!);if(code.kind==="sku")barcodeProduct=code.sku.product.sourceCode;else if(code.kind==="product-only"&&code.productIds.length===1)barcodeProduct=refs.lookup.productById(code.productIds[0]!)?.sourceCode||null;}
  const picked=new Set(filter.productCodes);
  return refs.catalog.products.filter(product=>{
    if(picked.size&&!picked.has(product.code))return false;
    if(tokens.length){const code=product.code.toLowerCase(),name=product.name.toLowerCase();if(many){if(!wanted.has(code))return false;}else if(!code.includes(tokens[0]!.toLowerCase())&&!name.includes(tokens[0]!.toLowerCase())&&product.code!==barcodeProduct)return false;}
    if(allowed&&!allowed.has(product.category_code||String(product.attributes?.categoryId||"")))return false;
    if(filter.supplierIds.length&&!filter.supplierIds.includes(product.counterparty_id||""))return false;
    if(filter.fitCodes.length){const identity=refs.lookup.productByCode(product.code),fit=identity?refs.lookup.skusForProduct(identity.productId)[0]?.fit.code:null;if(!fit||!filter.fitCodes.includes(fit))return false;}
    if(filter.seasons.length&&!filter.seasons.some(season=>String(historicalYearSeason(product.attributes).season||"").includes(season)))return false;
    return true;
  }).map(product=>product.code);
}

async function currentProducts(codes:readonly string[],lookup:SkuLookup,signal:AbortSignal):Promise<Map<string,ProductRecord>>{
  const result=new Map<string,ProductRecord>();let cursor=0;
  const worker=async()=>{while(cursor<codes.length){if(signal.aborted)throw new DOMException("Aborted","AbortError");const code=codes[cursor++]!;let product=productCache.get(code);if(!product){product=await api.getProduct(code,signal);if(!signal.aborted)productCache.set(code,product);}if(product.code!==code||lookup.productByCode(code)?.productId!==product.id)throw Error("库存商品身份不一致");result.set(code,product);}};
  await Promise.all(Array.from({length:Math.min(8,codes.length)},worker));return result;
}

export const fetchInventory:PageFetcher<InventoryFilter,InventoryViewRow,InventoryMeta>=async({applied,page,pageSize,signal})=>{
  if(!INVENTORY_PAGE_SIZES.includes(pageSize as InventoryPageSize))throw Error("库存每页数量不受支持");
  const refs=await inventoryReferences(signal);
  if(applied.seasons.length&&!refs.catalog.products.some(product=>Boolean(historicalYearSeason(product.attributes).season)))throw Error("真实商品档案未提供季节，当前无法按季节筛选库存");
  const productCodes=matchingProducts(applied,refs);
  const warehouseIds=applied.warehouseIds.length?applied.warehouseIds:refs.warehouses.map(row=>row.id);
  if(warehouseIds.some(id=>!refs.warehouses.some(row=>row.id===id)))throw Error("仓库筛选身份不存在");
  if(!productCodes.length){
    const source:RuntimeInventoryPage={rows:[],rowCount:0,productCount:0,total:"0",products:[],colors:[]};
    return {items:[],total:0,meta:{productCount:0,queryTotal:"0",pageTotal:"0",source,applied}};
  }
  const source=await api.listInventory({page,pageSize:pageSize as InventoryPageSize,productCodes,warehouseIds},signal);
  const records=await currentProducts([...new Set(source.rows.map(row=>row.code))],refs.lookup,signal);
  if(signal.aborted)throw new DOMException("Aborted","AbortError");
  const names=new Map(refs.warehouses.map(row=>[row.id,row.name||row.code||row.id] as const));
  const view=projectInventoryPage(source,refs.lookup,records,names);
  return {items:view.rows,total:view.rowCount,meta:{productCount:view.productCount,queryTotal:view.queryTotal,pageTotal:view.pageTotal,source,applied}};
};
