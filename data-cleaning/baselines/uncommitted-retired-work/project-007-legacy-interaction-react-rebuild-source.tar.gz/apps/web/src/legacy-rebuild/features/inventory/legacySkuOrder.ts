import type { DisplaySku } from "@stage05";

// The 8877 runtime bridge sorts source SKU rows before deriving product colors.
export function legacySkuOrder(skus: readonly DisplaySku[]): DisplaySku[] {
  return [...skus].sort((a, b) =>
    a.identity.sourceSizeName.localeCompare(b.identity.sourceSizeName, "zh-CN", {numeric: true}) ||
    a.color.name.localeCompare(b.color.name, "zh-CN"),
  );
}
