import { api, formatSignedQuantity, parseSignedQuantity, type RuntimeInventoryRow } from "@stage05";
import { matchingProducts, type InventoryFilter, type InventoryReferences } from "./data";

export interface InventoryReport {rows:RuntimeInventoryRow[];rowCount:number;total:string;applied:InventoryFilter}
const clean=(value:unknown)=>String(value??"").replaceAll('"','""');
const csv=(values:readonly unknown[])=>values.map(value=>`"${clean(value)}"`).join(",");
const escape=(value:unknown)=>String(value??"").replace(/[&<>"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"})[char]!);
function reportScope(filter:InventoryFilter,refs:InventoryReferences):string{
  const products=filter.productCodes.length?filter.productCodes.join("、"):filter.keyword?`关键词：${filter.keyword}`:"全部匹配商品";
  const category=filter.categoryCode?refs.categories.find(item=>(item.code||item.id)===filter.categoryCode)?.name||"未设置分类":"全部分类";
  const warehouse=filter.warehouseIds.length?filter.warehouseIds.map(id=>refs.warehouses.find(item=>item.id===id)?.name||id).join("、"):`全部仓库（${refs.warehouses.length}）`;
  const optional:[string,readonly string[],readonly {id:string;name:string}[]][]=[
    ["供应商",filter.supplierIds,refs.suppliers.map(item=>({id:item.id,name:item.name||item.code||item.id}))],
    ["版型",filter.fitCodes,["Y","A","B","C","D","E"].map(id=>({id,name:`${id}版`}))],
    ["季节",filter.seasons,filter.seasons.map(id=>({id,name:id}))],
  ];
  return [products,category,warehouse,...optional.filter(([,ids])=>ids.length).map(([label,ids,items])=>`${label}：${ids.map(id=>items.find(item=>item.id===id)?.name||id).join("、")}`)].join(" · ");
}

export async function loadAllInventoryRows(applied:InventoryFilter,refs:InventoryReferences,signal:AbortSignal,onProgress:(done:number,total:number)=>void):Promise<InventoryReport>{
  const products=matchingProducts(applied,refs),warehouses=applied.warehouseIds.length?applied.warehouseIds:refs.warehouses.map(item=>item.id);
  if(!products.length)return {rows:[],rowCount:0,total:"0",applied};
  const rows:RuntimeInventoryRow[]=[];let total=Infinity,quantity="0";
  for(let page=1;rows.length<total;page++){
    if(signal.aborted)throw new DOMException("Aborted","AbortError");
    let result;
    try{result=await api.listInventory({page,pageSize:500,productCodes:products,warehouseIds:warehouses},signal);}
    catch(error){throw Error(`读取第 ${page} 页失败：${error instanceof Error?error.message:"库存服务异常"}`);}
    if(page===1){total=result.rowCount;quantity=result.total;}
    if(!result.rows.length&&rows.length<total)throw Error("全量库存读取提前结束");
    rows.push(...result.rows);onProgress(rows.length,total);
  }
  if(rows.length!==total)throw Error("全量库存明细数量不一致");
  return {rows,rowCount:total,total:quantity,applied};
}

function groups(report:InventoryReport,refs:InventoryReferences){
  type Group={name:string;columns:{key:string;name:string}[];rows:{code:string;name:string;color:string;warehouse:string;values:Map<string,bigint>;valid:Set<string>}[]};
  const output=new Map<string,Group>();
  for(const row of report.rows){
    const product=refs.catalog.products.find(item=>item.code===row.code),identity=refs.lookup.productByCode(row.code);
    if(!product||!identity)throw Error("库存商品身份不一致");
    const skus=refs.lookup.skusForProduct(identity.productId).filter(sku=>sku.identity.colorId===row.color_id);
    const byGroup=new Map<string,typeof skus>();for(const sku of skus)byGroup.set(sku.groupName,[...(byGroup.get(sku.groupName)||[]),sku]);
    for(const [name,members] of byGroup){
      const section=refs.lookup.matrixForProduct(identity.productId).sections.find(item=>item.group.name===name);
      if(!section)throw Error("正式尺码组不存在");
      const group=output.get(name)||{name,columns:section.group.columns.map(column=>({key:column.key,name:column.name})),rows:[]};
      const values=new Map<string,bigint>(),valid=new Set<string>();
      for(const sku of members){valid.add(sku.column.key);const raw=row.values[sku.identity.sizeId];if(raw!==undefined)values.set(sku.column.key,(values.get(sku.column.key)||0n)+parseSignedQuantity(raw));}
      group.rows.push({code:row.code,name:product.name,color:members[0]?.color.name||"未设置",warehouse:refs.warehouses.find(item=>item.id===row.warehouse_id)?.name||"未设置",values,valid});
      output.set(name,group);
    }
  }
  return [...output.values()];
}
function printable(value:bigint|undefined,valid:boolean){return !valid?"0":value===undefined?"未读取":formatSignedQuantity(value);}
export function buildDefaultCsv(report:InventoryReport,refs:InventoryReferences):string{
  const lines=[csv(["奈爵服饰 库存状况"]),csv(["查询范围",reportScope(report.applied,refs)]),csv(["库存明细",report.rowCount,"库存合计",report.total])];
  for(const group of groups(report,refs)){
    lines.push(csv([group.name]));lines.push(csv(["款号","商品名称","颜色","仓库",...group.columns.map(column=>column.name)]));
    for(const row of group.rows)lines.push(csv([row.code,row.name,row.color,row.warehouse,...group.columns.map(column=>printable(row.values.get(column.key),row.valid.has(column.key)))]));
  }
  return "\ufeff"+lines.join("\r\n");
}
export function buildYintaiCsv(report:InventoryReport,refs:InventoryReferences):string{
  const lines=[csv(["默认条形码","款号","商品名称","系统货号","存货分类","零售价(主)","颜色","尺码","现存量(主)","主计量"])];
  const rowsByProduct=new Map<string,RuntimeInventoryRow[]>();for(const row of report.rows)rowsByProduct.set(row.code,[...(rowsByProduct.get(row.code)||[]),row]);
  for(const [code,rows] of rowsByProduct){const product=refs.catalog.products.find(item=>item.code===code),identity=refs.lookup.productByCode(code);if(!product||!identity)throw Error("银泰模板商品身份不一致");
    const attributes=product.attributes||{},category=refs.categories.find(item=>(item.code||item.id)===product.category_code)?.name||"未设置";
    for(const sku of refs.lookup.skusForProduct(identity.productId)){
      if(!sku.sourceEnabled)continue;
      const records=refs.lookup.barcodeRecordsForSku(sku.identity.skuId),barcode=records.find(item=>item.generated)?.barcode||records[0]?.barcode||"";
      let quantity=0n,known=false;
      for(const row of rows)if(row.color_id===sku.identity.colorId&&row.values[sku.identity.sizeId]!==undefined){quantity+=parseSignedQuantity(row.values[sku.identity.sizeId]!);known=true;}
      const price=attributes.price??attributes.referencePrice??"",unit=attributes.unit??"";
      lines.push(csv([barcode,code,product.name,attributes.systemCode??"",category,price,sku.color.name,sku.column.name,known?formatSignedQuantity(quantity):"未知",unit]));
    }
  }
  return "\ufeff"+lines.join("\r\n");
}
export function buildPrintHtml(report:InventoryReport,refs:InventoryReferences,settings:{subtotal:boolean;total:boolean;sizeDescription:boolean}):string{
  const content=groups(report,refs).map(group=>{
    const lastProduct=new Map<string,number>(),lastColor=new Map<string,number>();
    const products=new Map<string,Map<string,bigint>>(),colors=new Map<string,Map<string,bigint>>();
    const add=(target:Map<string,Map<string,bigint>>,key:string,values:Map<string,bigint>)=>{const sums=target.get(key)||new Map<string,bigint>();for(const [column,value] of values)sums.set(column,(sums.get(column)||0n)+value);target.set(key,sums);};
    group.rows.forEach((row,index)=>{lastProduct.set(row.code,index);lastColor.set(`${row.code}\u001f${row.color}`,index);add(products,row.code,row.values);add(colors,`${row.code}\u001f${row.color}`,row.values);});
    const values=(sums:Map<string,bigint>)=>{let total=0n;const cells=group.columns.map(column=>{const amount=sums.get(column.key)||0n;total+=amount;return `<td>${escape(formatSignedQuantity(amount))}</td>`;});return cells.join("")+`<td>${escape(formatSignedQuantity(total))}</td>`;};
    const body=group.rows.map((row,index)=>{
      const sum=[...row.values.values()].reduce<bigint>((n,value)=>n+value,0n),colorKey=`${row.code}\u001f${row.color}`;
      let html=`<tr><td>${escape(row.code)} ${escape(row.name)}</td><td>${escape(row.color)}</td><td>${escape(row.warehouse)}</td>${group.columns.map(column=>`<td>${escape(printable(row.values.get(column.key),row.valid.has(column.key)))}</td>`).join("")}<td>${escape(formatSignedQuantity(sum))}</td></tr>`;
      if(settings.subtotal&&lastColor.get(colorKey)===index)html+=`<tr class="subtotal"><td>颜色小计</td><td></td><td></td>${values(colors.get(colorKey)!)}</tr>`;
      if(settings.total&&lastProduct.get(row.code)===index)html+=`<tr class="total"><td>商品合计</td><td></td><td></td>${values(products.get(row.code)!)}</tr>`;
      return html;
    }).join("");
    return `<section>${settings.sizeDescription?`<h2>${escape(group.name)} <small>${group.columns.map(column=>escape(column.name)).join(" / ")}</small></h2>`:""}<table><thead><tr>${["商品名称／款号","颜色","仓库",...group.columns.map(column=>column.name),"合计"].map(name=>`<th>${escape(name)}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table></section>`;
  }).join("");
  return `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>库存状况打印</title><style>@page{size:A4 landscape;margin:9mm}body{font:11px Arial,"PingFang SC",sans-serif;color:#1d2129}h1{font-size:18px}h2{font-size:12px;margin:12px 0 4px}table{width:100%;border-collapse:collapse;table-layout:fixed}th,td{padding:4px;border:1px solid #c9cdd4;overflow-wrap:break-word;text-align:right}th{background:#f2f3f5}th:first-child,td:first-child{text-align:left}thead{display:table-header-group}tr{break-inside:avoid}.subtotal,.total{background:#f2f3f5;font-weight:600}</style><h1>库存状况</h1><p>${escape(reportScope(report.applied,refs))} · ${report.rowCount} 条数据行 · 库存合计 ${escape(report.total)}</p>${content}</html>`;
}
