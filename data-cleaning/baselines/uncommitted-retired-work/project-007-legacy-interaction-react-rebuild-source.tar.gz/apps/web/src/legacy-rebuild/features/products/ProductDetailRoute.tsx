import { useEffect, useMemo, useRef, useState } from "react";
import {
  Alert,
  Button,
  Collapse,
  Descriptions,
  Drawer,
  Empty,
  Image,
  Input,
  Message,
  Select,
  Space,
  Table,
  Tabs,
  Tag,
  Tooltip,
  Typography,
} from "@arco-design/web-react";
import type { TableProps } from "@arco-design/web-react";
import {
  ErrorState,
  LoadingState,
  PageContainer,
  type ProductIdentity,
  type SkuCell,
  type SkuLookup,
} from "@stage05";
import { api } from "@stage05";
import { navigate, returnToList } from "../../app/router";
import { NotFoundState } from "../../shared/feedback";
import { buildReferenceMaps, imageSources, readAllReferences, valueOrUnset, type ProductRecord, type ReferenceRecord } from "./data";
import { readProductInventory, type ProductInventorySnapshot, type WarehouseBalance, type WarehouseSkuBalance } from "./inventory";
import { barcodeKindColor, barcodeKindLabel, barcodeRowsForProduct, summarizeSkuBarcodes } from "./logic";
import { loadSkuProjection } from "./skuRepository";
import "./products.css";

interface ProductDetailData {
  product: ProductRecord;
  identity: ProductIdentity;
  lookup: SkuLookup;
  categories: ReferenceRecord[];
  suppliers: ReferenceRecord[];
}

type DetailState = { kind: "loading" } | { kind: "not-found" } | { kind: "error"; message: string } | { kind: "ready"; data: ProductDetailData };
type InventoryState = { kind: "idle" | "loading" } | { kind: "error"; message: string } | { kind: "ready"; snapshot: ProductInventorySnapshot };

function display(value: unknown): string {
  return valueOrUnset(value);
}

function barcodeSchemeName(code: string | null): string {
  if (!code) return "来源未提供";
  return code === "5" ? "2026 当前方案" : `历史方案 ${code}`;
}

function BasicTab({ data }: { data: ProductDetailData }) {
  const { product, categories, suppliers } = data;
  const maps = buildReferenceMaps(categories, suppliers);
  const categoryCode = typeof product.attributes.categoryId === "string" ? product.attributes.categoryId : null;
  const category = categories.find(row => row.code === categoryCode);
  const parent = categories.find(row => row.code === category?.parent_code);
  const supplier = product.counterparty_id ? maps.supplierById.get(product.counterparty_id) : null;
  const field = (label: string, value: unknown, type: "text" | "select" = "text") => <label className="lr-product-editor-field" key={label}><span>{label}</span>{type === "select"
    ? <Select value={display(value)} disabled options={[{label: display(value), value: display(value)}]} />
    : <Input value={value === null || value === undefined ? "" : String(value)} readOnly placeholder="未设置" />}</label>;
  return <div className="lr-product-editor-grid">
    {field("款号 *", product.code)}
    {field("商品名称 *", product.name)}
    {field("一级分类", parent?.name || category?.name || "待确认", "select")}
    {field("二级分类", parent ? category?.name : "不适用", "select")}
    {field("年份", product.attributes.year, "select")}
    {field("季节", product.attributes.season, "select")}
    {field("供应商 *", supplier?.name || "未选择", "select")}
    {field("版型", product.attributes.fitCode, "select")}
    {field("厚薄（可选）", product.attributes.thickness, "select")}
    {field("领型 / 裤型（可选）", product.attributes.shapeCode, "select")}
    {field("系统货号", product.attributes.systemItemCode || product.attributes.barcodeItemCode || "历史未记录")}
  </div>;
}

function MatrixCell({ entries, onInspect }: { entries: readonly SkuCell[]; onInspect: (skuId: string) => void }) {
  if (!entries.length || entries.every(entry => entry.missingCell)) return <Tag color="gray">无SKU</Tag>;
  return <div className="product-matrix-cell">
    {entries.map(entry => {
      if (entry.missingCell || !entry.skuId) return <Tag key="missing" color="gray">无SKU</Tag>;
      const fit = entry.fit;
      const sourceSize = entry.originalIdentity.sourceSizeName || "来源未提供";
      const sourceCode = entry.originalIdentity.sourceSizeCode;
      return <div className="product-matrix-entry" key={entry.skuId}>
        <Tag color={fit?.code === "A" ? "arcoblue" : fit?.code === "B" ? "purple" : "gray"}>{fit ? `${fit.code}版` : "版型未提供"}</Tag>
        <span>{entry.displayColumn}</span>
        <Tooltip content={<span>原SKU：{entry.skuId}<br />原尺码：{sourceSize}{sourceCode ? ` · ${sourceCode}` : ""}<br />原尺码ID：{entry.originalIdentity.sizeId || "未提供"}</span>}>
          <Button type="text" size="mini" onClick={() => onInspect(entry.skuId!)}>来源</Button>
        </Tooltip>
      </div>;
    })}
  </div>;
}

function SpecificationTab({ data, onInspect }: { data: ProductDetailData; onInspect: (skuId: string) => void }) {
  const projection = data.lookup.matrixForProduct(data.identity.productId);
  return <div className="product-section-stack">
    <Typography.Text type="secondary">同格 A/B 规格分别列示；空格表示来源没有该规格。</Typography.Text>
    {projection.sections.length === 0 ? <Empty description="当前商品没有可展示的来源规格" /> : projection.sections.map(section => {
      const columns: NonNullable<TableProps["columns"]> = [
        { title: "颜色", key: "color", width: 132, fixed: "left", render: (_value, raw) => {
          const row = raw as typeof section.rows[number];
          return <span>{row.color.name}{row.color.code ? ` · ${row.color.code}` : ""}</span>;
        } },
        ...section.group.columns.map(column => ({
          title: column.name,
          key: column.key,
          width: 150,
          render: (_value: unknown, raw: unknown) => {
            const row = raw as typeof section.rows[number];
            const cell = row.cells.find(item => item.column.key === column.key);
            return cell ? <MatrixCell entries={cell.entries} onInspect={onInspect} /> : <Tag color="gray">无SKU</Tag>;
          },
        })),
      ];
      return <section className="product-matrix-section" key={section.group.name}>
        <Typography.Title className="product-section-title" heading={6}>{section.group.name}</Typography.Title>
        <div className="product-matrix-table-wrap">
          <Table
            rowKey={row => `${row.product.productId}:${row.color.colorId}`}
            columns={columns}
            data={[...section.rows]}
            pagination={false}
            scroll={{ x: 132 + section.group.columns.length * 150 }}
            noDataElement={null}
          />
        </div>
      </section>;
    })}
    <Typography.Text type="secondary">共 {data.lookup.skusForProduct(data.identity.productId).length} 个规格。</Typography.Text>
  </div>;
}

function BarcodeTab({ data }: { data: ProductDetailData }) {
  const summary = summarizeSkuBarcodes(data.lookup);
  const rows = barcodeRowsForProduct(data.product, data.identity, data.lookup);
  const scheme = typeof data.product.attributes.sourceBarcodeSchemeCode === "string" ? data.product.attributes.sourceBarcodeSchemeCode : null;
  const columns: NonNullable<TableProps["columns"]> = [
    { title: "状态", key: "kind", width: 150, render: (_value, raw) => {
      const row = raw as (typeof rows)[number];
      return <Tag color={barcodeKindColor(row.kind)}>{row.bindingLabel}</Tag>;
    } },
    { title: "条码", dataIndex: "barcode", key: "barcode", width: 220, render: (_value, raw) => <span className="product-source-identity">{(raw as (typeof rows)[number]).barcode}</span> },
    { title: "来源", dataIndex: "source", key: "source", width: 190 },
    { title: "生成状态", dataIndex: "generated", key: "generated", width: 180 },
    { title: "原尺码", dataIndex: "sourceSize", key: "sourceSize", width: 170, render: (_value, raw) => (raw as (typeof rows)[number]).sourceSize || "—" },
    { title: "来源方案", dataIndex: "scheme", key: "scheme", width: 140, render: (_value, raw) => barcodeSchemeName((raw as (typeof rows)[number]).scheme) },
  ];
  return <div className="product-section-stack">
    <Typography.Text type="secondary">全库已生成条码 {summary.generatedSkuCount.toLocaleString("zh-CN")} 个规格，未生成记录 {summary.ungeneratedSkuCount.toLocaleString("zh-CN")} 个。</Typography.Text>
    <Collapse><Collapse.Item name="barcode-source" header="条码来源与异常口径">
      <Typography.Paragraph>S1 按原 SKU ID 和正式 generated/schemeId 元数据区分生成码、历史兼容码、商品级来源码与歧义码；{summary.noSkuBarcodeCount} 个 SKU 没有唯一绑定，不等同于未生成。</Typography.Paragraph>
      {summary.skuCount === 14864 && summary.generatedSkuCount === 14170 && summary.ungeneratedSkuCount === 694 && <Typography.Paragraph>冻结基线异常分组：531 个冲突、163 个字段或长度问题。694 个 SKU 没有真实生成记录，原样保留；当前合同未提供逐 SKU 失败原因，不按码形或缺少绑定推断。</Typography.Paragraph>}
    </Collapse.Item></Collapse>
    <Descriptions
      border
      column={{ xs: 1, sm: 2, md: 3 }}
      data={[
        { label: "商品级来源码", value: valueOrUnset(data.product.attributes.defaultBarcode) },
        { label: "商品级来源码识别", value: typeof data.product.attributes.defaultBarcode === "string" ? barcodeKindLabel(data.lookup.barcode(data.product.attributes.defaultBarcode)) : "来源未提供" },
        { label: "方案", value: barcodeSchemeName(scheme) },
        { label: "生成标记", value: data.product.attributes.newBarcodeGenerated === true ? "来源商品档案标记已生成" : data.product.attributes.newBarcodeGenerated === false ? "来源商品档案标记未生成" : "来源未提供" },
      ]}
    />
    <div className="product-source-table">
      <Table rowKey="key" columns={columns} data={rows} size="small" pagination={false} scroll={{ x: 950 }} noDataElement={null} />
    </div>
  </div>;
}

function PricesTab({ product }: { product: ProductRecord }) {
  const fields = [
    ["purchasePrice", "采购价 *"], ["price", "零售价 *"],
    ["wholesale5", "五级批发价（工厂店供货价）"], ["wholesale6", "六级批发价（贴牌价）"],
    ["wholesale7", "七级批发价（批发价）"], ["wholesale8", "八级批发价（代理商供货价）"],
    ["wholesale9", "九级批发价（工厂店零售价）"], ["wholesale10", "十级批发价（葛玉珠）"],
    ["minimumPrice", "最低售价 *"],
  ] as const;
  return <div className="product-section-stack"><div className="lr-product-editor-grid">
    {fields.map(([key, label]) => <label className="lr-product-editor-field" key={key}><span>{label}</span><Input value={product.attributes[key] === null || product.attributes[key] === undefined ? "" : String(product.attributes[key])} readOnly placeholder="未设置" /></label>)}
  </div><Typography.Text type="secondary">留空表示未设置，0 表示实际为零。原价格数据保持不变。</Typography.Text></div>;
}

export function ImagesTab({ product }: { product: ProductRecord }) {
  const images = imageSources(product.attributes);
  return images.length ? <div className="product-image-grid">
    {images.map(image => <div className="product-image-item" key={image.key}>
      <Image src={image.url} alt={`${product.name} ${image.label}`} width={220} height={220} lazyload error={<Empty description="来源图片无法显示" />} />
      <Typography.Text type="secondary">{image.label}</Typography.Text>
    </div>)}
  </div> : <Empty description="暂无商品图片" />;
}

function InventoryTab({
  snapshot,
  loading,
  error,
  onRetry,
  onOpenWarehouse,
  onOpenInventory,
}: {
  snapshot: ProductInventorySnapshot | null;
  loading: boolean;
  error: string | null;
  onRetry: () => void;
  onOpenWarehouse: (warehouse: WarehouseBalance) => void;
  onOpenInventory: () => void;
}) {
  const [showAll, setShowAll] = useState(false);
  if (loading && !snapshot) return <LoadingState text="正在按商品和仓库读取现存量" />;
  if (error && !snapshot) return <ErrorState message={error} onRetry={onRetry} />;
  if (!snapshot) return <Empty description="尚未读取库存摘要" />;
  const rows = showAll ? [...snapshot.warehouses] : snapshot.warehouses.filter(row => row.nonzeroSkuCount > 0);
  const columns: NonNullable<TableProps["columns"]> = [
    { title: "仓库", dataIndex: "warehouseName", key: "warehouseName", width: 220 },
    { title: "库存合计", dataIndex: "total", key: "total", align: "right", width: 130, render: (_value, raw) => <span className={`products-stock ${String((raw as WarehouseBalance).total).startsWith("-") ? "products-stock-negative" : ""}`}>{(raw as WarehouseBalance).total}</span> },
    { title: "正库存 SKU", dataIndex: "positiveSkuCount", key: "positiveSkuCount", align: "right", width: 120 },
    { title: "正数合计", dataIndex: "positiveQuantity", key: "positiveQuantity", align: "right", width: 120 },
    { title: "负库存 SKU", dataIndex: "negativeSkuCount", key: "negativeSkuCount", align: "right", width: 120 },
    { title: "负数合计", dataIndex: "negativeQuantity", key: "negativeQuantity", align: "right", width: 120, render: (_value, raw) => <span className="products-stock products-stock-negative">{(raw as WarehouseBalance).negativeQuantity}</span> },
    { title: "非零 SKU", dataIndex: "nonzeroSkuCount", key: "nonzeroSkuCount", align: "right", width: 110 },
    { title: "操作", key: "action", width: 100, fixed: "right", render: (_value, raw) => <Button type="text" onClick={() => onOpenWarehouse(raw as WarehouseBalance)}>SKU 明细</Button> },
  ];
  return <div className="product-section-stack">
    <Typography.Text>商品现存量合计 <strong>{snapshot.total}</strong></Typography.Text>
    {error && <Alert type="warning" showIcon title="刷新未完成" content={error} />}
    <Space wrap>
      <Button onClick={() => setShowAll(value => !value)}>{showAll ? "仅显示有非零 SKU 的仓库" : `查看全部 ${snapshot.allWarehouses.length} 个仓库`}</Button>
      <Button type="primary" onClick={onOpenInventory}>打开库存状况表</Button>
    </Space>
    <div className="product-source-table">
      <Table rowKey="warehouseId" columns={columns} data={rows} pagination={false} scroll={{ x: 1040 }} noDataElement={<Empty description="该商品在所有仓库均没有非零现存量" />} />
    </div>
    <Typography.Text type="secondary">已读取 {snapshot.allWarehouses.length} 个仓库；默认隐藏无非零 SKU 的仓库，切换“查看全部”可核对零库存项。</Typography.Text>
  </div>;
}

function sourceSkuRows(data: ProductDetailData) {
  return data.lookup.skusForProduct(data.identity.productId).map(sku => ({
    skuId: sku.identity.skuId,
    color: `${sku.color.name}${sku.color.code ? ` · ${sku.color.code}` : ""}`,
    displayGroup: sku.groupName,
    displaySize: sku.column.name,
    fit: `${sku.fit.code} · ${sku.fit.name}`,
    sourceSize: `${sku.identity.sourceSizeName}${sku.identity.sourceSizeCode ? ` · ${sku.identity.sourceSizeCode}` : ""}`,
    sourceSizeId: sku.identity.sizeId,
    sourceColorId: sku.identity.colorId,
    mappingRows: sku.mappingRows.join(", ") || "未提供",
  }));
}

export function ProductDetailRoute({ code }: { code: string }) {
  const [detail, setDetail] = useState<DetailState>({ kind: "loading" });
  const [retryVersion, setRetryVersion] = useState(0);
  const [activeTab, setActiveTab] = useState("basic");
  const [inventory, setInventory] = useState<InventoryState>({ kind: "idle" });
  const [selectedWarehouse, setSelectedWarehouse] = useState<WarehouseBalance | null>(null);
  const [selectedSourceSkuId, setSelectedSourceSkuId] = useState<string | null>(null);
  const inventoryAbort = useRef<AbortController | null>(null);

  useEffect(() => {
    const abort = new AbortController();
    setDetail({ kind: "loading" });
    setActiveTab("basic");
    setInventory({ kind: "idle" });
    setSelectedWarehouse(null);
    setSelectedSourceSkuId(null);
    void Promise.all([
      api.getProduct(code, abort.signal),
      loadSkuProjection(),
      readAllReferences("categories", abort.signal),
      readAllReferences("suppliers", abort.signal),
    ]).then(([product, lookup, categories, suppliers]) => {
      if (abort.signal.aborted) return;
      if (product.code !== code) throw new Error("商品来源编码与详情响应不一致");
      const identity = lookup.productByCode(code);
      if (!identity || identity.productId !== product.id) throw new Error(`商品详情没有匹配的 S1 来源身份：${code}`);
      setDetail({ kind: "ready", data: { product, identity, lookup, categories, suppliers } });
    }).catch(error => {
      if (abort.signal.aborted) return;
      const kind = error && typeof error === "object" && "kind" in error ? error.kind : null;
      if (kind === "not-found") setDetail({ kind: "not-found" });
      else setDetail({ kind: "error", message: error instanceof Error ? error.message : "商品资料读取失败" });
    });
    return () => {
      abort.abort();
      inventoryAbort.current?.abort();
      inventoryAbort.current = null;
    };
  }, [code, retryVersion]);

  const data = detail.kind === "ready" ? detail.data : null;
  const matrixRows = useMemo(() => data ? sourceSkuRows(data) : [], [data]);

  function requestInventory(): void {
    if (!data || inventory.kind === "loading" || inventory.kind === "ready") return;
    inventoryAbort.current?.abort();
    const abort = new AbortController();
    inventoryAbort.current = abort;
    setInventory({ kind: "loading" });
    void readProductInventory(data.product, data.lookup, abort.signal).then(snapshot => {
      if (!abort.signal.aborted) setInventory({ kind: "ready", snapshot });
    }).catch(error => {
      if (!abort.signal.aborted) setInventory({ kind: "error", message: error instanceof Error ? error.message : "商品库存摘要读取失败" });
    });
  }

  function openInventory(): void {
    const query = new URLSearchParams({ product: code, returnTo: window.location.pathname + window.location.search });
    navigate(`/inventory?${query.toString()}`);
  }

  if (detail.kind === "loading") return <PageContainer title="商品详情"><LoadingState text="正在读取商品、规格和来源身份" /></PageContainer>;
  if (detail.kind === "not-found") return <PageContainer title="商品详情"><NotFoundState title="未找到该商品" onBack={() => returnToList("products")} /></PageContainer>;
  if (detail.kind === "error") return <PageContainer title="商品详情"><ErrorState message={detail.message} onRetry={() => setRetryVersion(value => value + 1)} /></PageContainer>;
  if (!data) return null;

  const selectedSku = selectedWarehouse?.skuBalances || [];
  const warehouseSkuColumns: NonNullable<TableProps["columns"]> = [
    { title: "颜色", dataIndex: "colorName", key: "colorName", width: 130 },
    { title: "展示尺码组", dataIndex: "sizeGroup", key: "sizeGroup", width: 160 },
    { title: "展示尺码", dataIndex: "displaySize", key: "displaySize", width: 120 },
    { title: "版型", dataIndex: "fitCode", key: "fitCode", width: 90 },
    { title: "原尺码", dataIndex: "sourceSizeName", key: "sourceSizeName", width: 140 },
    { title: "原编码", dataIndex: "sourceSizeCode", key: "sourceSizeCode", width: 110, render: (_value, raw) => (raw as WarehouseSkuBalance).sourceSizeCode || "来源未提供" },
    { title: "现存量", dataIndex: "quantity", key: "quantity", align: "right", width: 110, render: (_value, raw) => <span className={`products-stock ${String((raw as WarehouseSkuBalance).quantity).startsWith("-") ? "products-stock-negative" : ""}`}>{(raw as WarehouseSkuBalance).quantity}</span> },
  ];

  return <section className="lr-product-editor">
    <div className="lr-product-head"><div><h1>{data.product.code} · {data.product.name || "未命名"}</h1><p>切换标签不会丢失填写内容；当前真实服务仅开放商品资料查询。</p></div><Space><Button onClick={() => returnToList("products")}>取消</Button><Button type="primary" onClick={() => Message.warning("当前真实服务未开放商品主数据写入；资料没有被修改。")}>保存</Button></Space></div>
    <Alert type="info" showIcon content="当前商品档案只读。页面按 8877 的字段与标签展示真实资料，保存不会改写商品、SKU 或条码。" />
    <div className="product-detail-page">
      <div className="lr-product-editor-panel">
        <Tabs activeTab={activeTab} destroyOnHide={false} onChange={key => {
          setActiveTab(key);
          if (key !== "specifications") setSelectedSourceSkuId(null);
          if (key === "inventory") requestInventory();
        }}>
          <Tabs.TabPane key="basic" title="基础资料"><BasicTab data={data} /></Tabs.TabPane>
          <Tabs.TabPane key="specifications" title="颜色尺码"><SpecificationTab data={data} onInspect={skuId => setSelectedSourceSkuId(skuId)} /></Tabs.TabPane>
          <Tabs.TabPane key="barcodes" title="条码"><BarcodeTab data={data} /></Tabs.TabPane>
          <Tabs.TabPane key="prices" title="价格"><PricesTab product={data.product} /></Tabs.TabPane>
          <Tabs.TabPane key="images" title="图片"><ImagesTab product={data.product} /></Tabs.TabPane>
          <Tabs.TabPane key="inventory" title="库存"><InventoryTab
            snapshot={inventory.kind === "ready" ? inventory.snapshot : null}
            loading={inventory.kind === "loading"}
            error={inventory.kind === "error" ? inventory.message : null}
            onRetry={requestInventory}
            onOpenWarehouse={setSelectedWarehouse}
            onOpenInventory={openInventory}
          /></Tabs.TabPane>
        </Tabs>
      </div>
      <Drawer
        visible={selectedWarehouse !== null || selectedSourceSkuId !== null}
        title={selectedSourceSkuId ? "原SKU身份与来源尺码" : selectedWarehouse ? `${selectedWarehouse.warehouseName} · SKU 明细` : "SKU 明细"}
        width="min(880px, calc(100vw - 32px))"
        autoFocus={false}
        onCancel={() => { setSelectedWarehouse(null); setSelectedSourceSkuId(null); }}
        footer={<Button onClick={() => { setSelectedWarehouse(null); setSelectedSourceSkuId(null); }}>关闭</Button>}
      >
        {selectedSourceSkuId ? <div className="product-source-table">
          <Table rowKey="skuId" columns={[
            { title: "颜色", dataIndex: "color", key: "color", width: 130 },
            { title: "展示尺码组", dataIndex: "displayGroup", key: "displayGroup", width: 150 },
            { title: "展示尺码", dataIndex: "displaySize", key: "displaySize", width: 110 },
            { title: "版型", dataIndex: "fit", key: "fit", width: 130 },
            { title: "原尺码", dataIndex: "sourceSize", key: "sourceSize", width: 170 },
            { title: "原尺码 ID", dataIndex: "sourceSizeId", key: "sourceSizeId", width: 220, render: (_value, raw) => <span className="product-source-identity">{(raw as (typeof matrixRows)[number]).sourceSizeId}</span> },
            { title: "SKU ID", dataIndex: "skuId", key: "skuId", width: 250, render: (_value, raw) => <span className="product-source-identity">{(raw as (typeof matrixRows)[number]).skuId}</span> },
          ]} data={matrixRows.filter(row => row.skuId === selectedSourceSkuId)} pagination={false} scroll={{ x: 1160 }} />
        </div> : <>
          {selectedWarehouse && <Typography.Text type="secondary">仓库合计 {selectedWarehouse.total}；逐规格列示当前现存量。</Typography.Text>}
          <div className="product-source-table">
            <Table rowKey="skuId" columns={warehouseSkuColumns} data={[...selectedSku]} size="small" pagination={false} scroll={{ x: 850 }} />
          </div>
        </>}
      </Drawer>
    </div>
  </section>;
}
