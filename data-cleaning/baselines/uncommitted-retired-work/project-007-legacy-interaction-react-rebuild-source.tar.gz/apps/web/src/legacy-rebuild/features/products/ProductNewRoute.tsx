import { useEffect, useMemo, useState } from "react";
import { Alert, Button, Empty, Input, InputNumber, Message, Select, Space, Tabs } from "@arco-design/web-react";
import { ErrorState, LoadingState, type SkuLookup } from "@stage05";
import { returnToList } from "../../app/router";
import { readAllReferences, type ReferenceRecord } from "./data";
import { loadSkuProjection } from "./skuRepository";
import "./products.css";

type Ready = {kind: "ready"; categories: ReferenceRecord[]; suppliers: ReferenceRecord[]; lookup: SkuLookup};
type State = {kind: "loading"} | {kind: "error"; message: string} | Ready;
const seasons = ["春季", "夏季", "秋季", "冬季", "春夏", "秋冬"];
const fits = [["Y", "Y版（修身）"], ["A", "A版（标准）"], ["B", "B版（宽松）"], ["C", "C版（加肥）"], ["D", "D版（加肥加大）"], ["E", "E版（特体）"]] as const;
const priceFields = [
  ["采购价 *", "purchasePrice"], ["零售价 *", "price"],
  ["五级批发价（工厂店供货价）", "wholesale5"], ["六级批发价（贴牌价）", "wholesale6"],
  ["七级批发价（批发价）", "wholesale7"], ["八级批发价（代理商供货价）", "wholesale8"],
  ["九级批发价（工厂店零售价）", "wholesale9"], ["十级批发价（葛玉珠）", "wholesale10"],
  ["最低售价 *", "minimumPrice"],
] as const;

export function ProductNewRoute() {
  const [state, setState] = useState<State>({kind: "loading"});
  const [retry, setRetry] = useState(0);
  const [parentCode, setParentCode] = useState("");
  const [groupName, setGroupName] = useState("");
  const [colors, setColors] = useState<string[]>([]);
  const [tab, setTab] = useState("basic");
  useEffect(() => {
    const abort = new AbortController(); setState({kind: "loading"});
    void Promise.all([readAllReferences("categories", abort.signal), readAllReferences("suppliers", abort.signal), loadSkuProjection()])
      .then(([categories, suppliers, lookup]) => {if (!abort.signal.aborted) setState({kind: "ready", categories, suppliers, lookup});})
      .catch(issue => {if (!abort.signal.aborted) setState({kind: "error", message: issue instanceof Error ? issue.message : "新增商品资料读取失败"});});
    return () => abort.abort();
  }, [retry]);

  const reference = state.kind === "ready" ? state : null;
  const primaryCategories = useMemo(() => reference?.categories.filter(row => row.code && (!row.parent_code || !reference.categories.some(item => item.code === row.parent_code))) || [], [reference]);
  const secondaryCategories = useMemo(() => reference?.categories.filter(row => row.code && row.parent_code === parentCode) || [], [reference, parentCode]);
  const sizeGroups = useMemo(() => reference ? [...new Set(reference.lookup.skus.map(sku => sku.groupName))].sort((a, b) => a.localeCompare(b, "zh-CN")) : [], [reference]);
  const publicColors = useMemo(() => reference ? [...new Map(reference.lookup.skus.map(sku => [sku.identity.colorId, {label: sku.identity.sourceColorName || "未命名颜色", value: sku.identity.colorId}])).values()] : [], [reference]);
  const selectedGroup = groupName || sizeGroups[0] || "";
  const groupSizes = reference ? [...new Set(reference.lookup.skus.filter(sku => sku.groupName === selectedGroup).map(sku => sku.column.name))] : [];
  if (state.kind === "loading") return <LoadingState text="正在读取商品基础资料与规格" />;
  if (state.kind === "error") return <ErrorState message={state.message} onRetry={() => setRetry(value => value + 1)} />;

  return <section className="lr-product-editor">
    <div className="lr-product-head"><div><h1>新增商品 · 未命名</h1><p>切换标签不会丢失填写内容；带 * 的项目为必填</p></div><Space><Button onClick={() => returnToList("products")}>取消</Button><Button type="primary" onClick={() => Message.warning("当前真实服务未开放商品主数据写入；不会创建商品、SKU 或条码。")}>保存</Button></Space></div>
    <Alert type="info" showIcon content="可检查新增商品字段及选择资料。当前真实服务尚未开放商品主数据写入，本页的试填不会保存。" />
    <div className="lr-product-editor-panel"><Tabs activeTab={tab} destroyOnHide={false} onChange={setTab}>
      <Tabs.TabPane key="basic" title="基础资料"><div className="lr-product-editor-grid">
        <label className="lr-product-editor-field"><span>款号 *</span><Input maxLength={40} placeholder="输入款号" /></label>
        <label className="lr-product-editor-field"><span>商品名称 *</span><Input maxLength={80} placeholder="输入商品名称" /></label>
        <label className="lr-product-editor-field"><span>一级分类 *</span><Select showSearch allowClear placeholder="请选择" value={parentCode} options={primaryCategories.map(row => ({label: row.name || row.code || "", value: row.code!}))} onChange={value => setParentCode(String(value || ""))} /></label>
        <label className="lr-product-editor-field"><span>二级分类{secondaryCategories.length ? " *" : "（不适用）"}</span><Select showSearch allowClear placeholder={secondaryCategories.length ? "请选择" : "不适用"} disabled={!secondaryCategories.length} options={secondaryCategories.map(row => ({label: row.name || row.code || "", value: row.code!}))} /></label>
        <label className="lr-product-editor-field"><span>年份 *</span><Select defaultValue={String(new Date().getFullYear())} options={Array.from({length: new Date().getFullYear() - 2015 + 1}, (_, i) => ({label: `${2015 + i}年`, value: String(2015 + i)}))} /></label>
        <label className="lr-product-editor-field"><span>季节 *</span><Select mode="multiple" showSearch allowClear placeholder="请选择季节（可多选）" options={seasons.map(value => ({label: value, value}))} /></label>
        <label className="lr-product-editor-field"><span>供应商 *</span><Select showSearch allowClear placeholder="搜索选择供应商" virtualListProps={{height: 280}} options={state.suppliers.map(row => ({label: row.name || row.code || "未命名", value: row.id}))} /></label>
        <label className="lr-product-editor-field"><span>版型 *</span><Select defaultValue="A" options={fits.map(([value,label]) => ({label,value}))} /></label>
        <label className="lr-product-editor-field"><span>厚薄（可选）</span><Select allowClear placeholder="请选择" options={["薄款", "常规", "厚款"].map(value => ({label: value, value}))} /></label>
        <label className="lr-product-editor-field"><span>领型 / 裤型（可选）</span><Select allowClear placeholder="请先选分类" disabled={!parentCode} options={["圆领", "中领", "高领", "西装领", "翻领", "立领", "立翻领", "棒球领", "带帽", "交叉领", "正常裤脚", "裤脚偏小", "裤脚偏大", "大版裤", "小脚裤"].map(value => ({label: value, value}))} /></label>
        <label className="lr-product-editor-field"><span>系统货号 *</span><Input readOnly placeholder="保存后自动分配7位系统货号" /></label>
      </div></Tabs.TabPane>
      <Tabs.TabPane key="specifications" title="颜色尺码"><div className="lr-product-editor-grid">
        <label className="lr-product-editor-field"><span>尺码组 *</span><Select value={selectedGroup} options={sizeGroups.map(value => ({label: value, value}))} onChange={value => setGroupName(String(value))} /></label>
        <div className="lr-product-editor-field"><span>组内全部尺码</span><div className="lr-product-static-box">{groupSizes.join("、") || "未提供"}</div></div>
      </div><div className="lr-product-editor-section"><h3>商品颜色</h3><Select mode="multiple" showSearch allowClear placeholder="选择颜色" options={publicColors} value={colors} onChange={value => setColors(Array.isArray(value) ? value.map(String) : [])} /></div><p className="lr-product-spec-summary">{colors.length} 个颜色 × {selectedGroup || "未选尺码组"} {groupSizes.length} 个尺码 = <strong>{colors.length * groupSizes.length} 个规格</strong></p><p className="lr-product-help">每个颜色拥有整组尺码，不逐格配置。</p></Tabs.TabPane>
      <Tabs.TabPane key="barcodes" title="条码"><div className="lr-product-editor-grid"><label className="lr-product-editor-field"><span>主条码默认方案 *</span><Select value="2026" disabled options={[{label: "2026 条码方案", value: "2026"}]} /></label></div><p className="lr-product-help">只影响以后生成的条码，已有主条码及历史条码保持原值。新增商品保存前不会生成条码。</p><Empty description="先保存商品并选择颜色尺码，才能查看条码矩阵" /></Tabs.TabPane>
      <Tabs.TabPane key="prices" title="价格"><div className="lr-product-editor-grid">{priceFields.map(([label, key]) => <label className="lr-product-editor-field" key={key}><span>{label}</span><InputNumber min={0} precision={2} placeholder="未设置" style={{width: "100%"}} /></label>)}</div><p className="lr-product-help">留空表示未设置，0 表示实际为零。</p></Tabs.TabPane>
      <Tabs.TabPane key="images" title="图片"><Empty description="当前服务尚未开放商品图片写入" /></Tabs.TabPane>
    </Tabs></div>
  </section>;
}
