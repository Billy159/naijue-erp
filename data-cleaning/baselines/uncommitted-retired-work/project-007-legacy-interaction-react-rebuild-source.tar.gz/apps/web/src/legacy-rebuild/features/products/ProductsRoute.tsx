import { useEffect, useMemo, useRef, useState } from "react";
import { Alert, Button, Input, Pagination, Select, Table } from "@arco-design/web-react";
import { IconEdit } from "@arco-design/web-react/icon";
import type { TableProps } from "@arco-design/web-react";
import { usePagedQuery } from "@stage05";
import { navigate, saveListReturn } from "../../app/router";
import { PRODUCT_PAGE_SIZES, readAllReferences, type ProductListRow, type ReferenceRecord } from "./data";
import { emptyLegacyProductFilters, makeLegacyProductFetcher, type LegacyProductFilters } from "./legacyData";
import "./products.css";

function filtersFromLocation(): { filters: LegacyProductFilters; page: number; pageSize: number } {
  const query = new URLSearchParams(window.location.search);
  const list = (name: string) => query.getAll(name).filter(Boolean);
  const rawPage = Number(query.get("page")), rawSize = Number(query.get("size"));
  return {
    filters: {
      q: query.get("q") || "",
      years: list("year"), categories: list("category"), seasons: list("season"),
      supplierId: query.get("supplier") || "", fitId: query.get("fit") || "",
      thickness: query.get("thickness") || "", shapeCode: query.get("shape") || "", schemeId: query.get("scheme") || "",
    },
    page: Number.isSafeInteger(rawPage) && rawPage > 0 ? rawPage : 1,
    pageSize: PRODUCT_PAGE_SIZES.includes(rawSize as (typeof PRODUCT_PAGE_SIZES)[number]) ? rawSize : 50,
  };
}

function updateLocation(filters: LegacyProductFilters, page: number, size: number) {
  const query = new URLSearchParams();
  if (filters.q) query.set("q", filters.q);
  filters.years.forEach(value => query.append("year", value));
  filters.categories.forEach(value => query.append("category", value));
  filters.seasons.forEach(value => query.append("season", value));
  if (filters.supplierId) query.set("supplier", filters.supplierId);
  if (filters.fitId) query.set("fit", filters.fitId);
  if (filters.thickness) query.set("thickness", filters.thickness);
  if (filters.shapeCode) query.set("shape", filters.shapeCode);
  if (filters.schemeId) query.set("scheme", filters.schemeId);
  query.set("page", String(page)); query.set("size", String(size));
  window.history.replaceState({}, "", `/products?${query}`);
}

function sourceText(value: unknown, fallback = "—"): string {
  return value === null || value === undefined || value === "" ? fallback : String(value);
}

const years = Array.from({ length: new Date().getFullYear() - 2015 + 1 }, (_, index) => String(2015 + index));
const seasons = ["春季", "夏季", "秋季", "冬季", "春夏", "秋冬"];
const fits = [
  ["Y", "Y版（修身）"], ["A", "A版（标准）"], ["B", "B版（宽松）"],
  ["C", "C版（加肥）"], ["D", "D版（加肥加大）"], ["E", "E版（特体）"],
 ] as const;
const shapes = [
  ["01", "圆领"], ["02", "中领"], ["03", "高领"], ["15", "西装领"], ["16", "翻领"],
  ["17", "立领"], ["18", "立翻领"], ["19", "棒球领"], ["20", "带帽"], ["21", "交叉领"],
  ["22", "正常裤脚"], ["23", "裤脚偏小"], ["24", "裤脚偏大"], ["26", "大版裤"], ["27", "小脚裤"],
 ] as const;
const schemes = [
  ["2026", "2026 条码方案"], ["2023", "2023年条码方案"], ["2021fit", "2021年版型条码方案"],
  ["2021", "2021年条码方案"], ["2020", "2020年新方案"], ["2018", "2018年货品"],
 ] as const;

export function ProductsRoute() {
  const initial = useMemo(filtersFromLocation, []);
  const categoriesRef = useRef<ReferenceRecord[]>([]);
  const fetcher = useMemo(() => makeLegacyProductFetcher(() => categoriesRef.current), []);
  const { state, controller } = usePagedQuery<LegacyProductFilters, ProductListRow>(initial.filters, initial.pageSize, fetcher);
  const [categories, setCategories] = useState<ReferenceRecord[]>([]);
  const [suppliers, setSuppliers] = useState<ReferenceRecord[]>([]);
  const [dictionaryError, setDictionaryError] = useState("");
  const [moreFilters, setMoreFilters] = useState(false);

  useEffect(() => {
    const abort = new AbortController();
    void Promise.all([
      readAllReferences("categories", abort.signal),
      readAllReferences("suppliers", abort.signal),
    ]).then(([nextCategories, nextSuppliers]) => {
      if (abort.signal.aborted) return;
      categoriesRef.current = nextCategories;
      setCategories(nextCategories); setSuppliers(nextSuppliers);
      void controller.restore(initial.filters, initial.page, initial.pageSize);
    }).catch(issue => {
      if (abort.signal.aborted) return;
      setDictionaryError(issue instanceof Error ? issue.message : "商品筛选资料读取失败");
      void controller.restore(initial.filters, initial.page, initial.pageSize);
    });
    return () => abort.abort();
  }, [controller, initial]);

  useEffect(() => {
    if (state.hasExecuted) updateLocation(state.applied, state.page, state.pageSize);
  }, [state.applied, state.page, state.pageSize, state.hasExecuted]);

  const categoryByCode = useMemo(() => new Map(categories.filter(row => row.code).map(row => [row.code!, row] as const)), [categories]);
  const supplierById = useMemo(() => new Map(suppliers.map(row => [row.id, row] as const)), [suppliers]);
  const draftChanged = JSON.stringify(state.draft) !== JSON.stringify(state.applied);
  const openProduct = (row: ProductListRow) => {
    saveListReturn("products", { filters: state.applied, page: state.page, pageSize: state.pageSize });
    navigate(`/products/${encodeURIComponent(row.code)}`);
  };
  const setDraft = <K extends keyof LegacyProductFilters>(key: K, value: LegacyProductFilters[K]) => controller.setDraft({ ...state.draft, [key]: value });
  const selectMany = (key: "years" | "categories" | "seasons", placeholder: string, options: Array<{label: string; value: string}>) =>
    <Select className="lr-product-filter-select" aria-label={placeholder} mode="multiple" showSearch allowClear maxTagCount={1} placeholder={placeholder}
      value={state.draft[key]} options={options} virtualListProps={{height: 280}} onChange={value => setDraft(key, Array.isArray(value) ? value.map(String) : [])} />;

  const categoryOptions = categories.filter(row => row.code).map(row => {
    const parent = row.parent_code ? categoryByCode.get(row.parent_code) : undefined;
    return { label: parent?.name ? `${parent.name} / ${row.name || row.code}` : row.name || row.code || "待确认分类", value: row.code! };
  });
  const columns: NonNullable<TableProps["columns"]> = [
    { title: "款号", key: "code", width: 156, fixed: "left", render: (_value, raw) => <Button type="text" className="lr-product-cell-link" onClick={() => openProduct(raw as ProductListRow)}>{(raw as ProductListRow).code}</Button> },
    { title: "商品名称", key: "name", width: 200, render: (_value, raw) => <Button type="text" className="lr-product-cell-link lr-product-name-link" onClick={() => openProduct(raw as ProductListRow)}>{(raw as ProductListRow).name || "未命名"}</Button> },
    { title: "商品分类", key: "category", width: 150, render: (_value, raw) => {
      const row = raw as ProductListRow;
      const code = typeof row.attributes.categoryId === "string" ? row.attributes.categoryId : "";
      const category = categoryByCode.get(code);
      return category ? category.name || category.code || "—" : <span>待确认分类<small className="lr-product-cell-meta">原：{sourceText(row.attributes.category, "未设置")}</small></span>;
    } },
    { title: "年份 / 季节", key: "year-season", width: 124, render: (_value, raw) => {
      const row = raw as ProductListRow; return `${sourceText(row.attributes.year)} / ${sourceText(row.attributes.season)}`;
    } },
    { title: "供应商", key: "supplier", width: 150, render: (_value, raw) => {
      const row = raw as ProductListRow; return row.counterparty_id ? supplierById.get(row.counterparty_id)?.name || "未选择" : "未选择";
    } },
    { title: "版型 / 厚薄", key: "fit-thickness", width: 130, render: (_value, raw) => {
      const row = raw as ProductListRow;
      return <span>{sourceText(row.attributes.fitCode)}<small className="lr-product-cell-meta">{sourceText(row.attributes.thickness)}</small></span>;
    } },
    { title: "零售价", key: "price", width: 100, align: "right", render: (_value, raw) => {
      const price = (raw as ProductListRow).attributes.price;
      return price === null || price === undefined || price === "" ? "—" : Number(price).toFixed(2);
    } },
    { title: "总库存", key: "stock", width: 100, align: "right", render: (_value, raw) => sourceText((raw as ProductListRow).stock_total) },
    { title: "操作", key: "action", width: 78, fixed: "right", render: (_value, raw) => <Button type="text" icon={<IconEdit />} aria-label="编辑商品" title="编辑" onClick={() => openProduct(raw as ProductListRow)} /> },
  ];

  return <section className="lr-product-page">
    <div className="lr-product-head"><div><h1>商品信息</h1><p>商品档案 · 一款一行</p></div><Button type="primary" onClick={() => {saveListReturn("products", {filters: state.applied, page: state.page, pageSize: state.pageSize}); navigate("/products/new");}}>新增商品</Button></div>
    <div className="lr-product-filters">
      <label className="lr-product-field"><span>找商品</span><Input.Search aria-label="找商品" value={state.draft.q} onChange={value => setDraft("q", value)} onSearch={() => void controller.apply()} onPressEnter={() => void controller.apply()} placeholder="款号 / 商品名称 / 系统货号" /></label>
      <label className="lr-product-field"><span>年份</span>{selectMany("years", "全部年份", years.map(value => ({label: `${value}年`, value})))}</label>
      <label className="lr-product-field"><span>分类</span>{selectMany("categories", "全部分类", categoryOptions)}</label>
      <label className="lr-product-field"><span>季节</span>{selectMany("seasons", "全部季节", seasons.map(value => ({label: value, value})))}</label>
      <Button type="text" aria-expanded={moreFilters} onClick={() => setMoreFilters(value => !value)}>更多筛选</Button>
      <Button type="primary" onClick={() => void controller.apply()}>查询</Button>
      <Button type="text" onClick={() => {controller.setDraft(emptyLegacyProductFilters()); void controller.apply();}}>重置</Button>
      {moreFilters && <div className="lr-product-more-filters">
        {([
          ["supplierId", "供应商", suppliers.map(row => ({label: row.name || row.code || "未命名", value: row.id}))],
          ["fitId", "版型", fits.map(([value, label]) => ({value, label}))],
          ["thickness", "厚薄", ["薄款", "常规", "厚款"].map(value => ({value, label: value}))],
          ["shapeCode", "领型 / 裤型", shapes.map(([value, label]) => ({value, label}))],
          ["schemeId", "条码方案", schemes.map(([value, label]) => ({value, label}))],
        ] as const).map(([key, label, options]) => <label className="lr-product-field" key={key}><span>{label}</span><Select showSearch allowClear aria-label={label} value={state.draft[key]} placeholder="全部" options={[...options]} virtualListProps={{height: 260}} onChange={value => setDraft(key, String(value || ""))} /></label>)}
      </div>}
    </div>
    {dictionaryError && <Alert type="error" showIcon content={dictionaryError} />}
    {draftChanged && <p className="lr-product-draft-note">条件已修改，点击“查询”后更新结果。</p>}
    {state.error && <Alert type="error" showIcon content={state.error.message} action={<Button size="small" onClick={() => void controller.reload()}>重试</Button>} />}
    <section className="lr-product-list-panel">
      <div className="lr-product-list-head"><h2>商品档案 <small>{state.total} 款</small></h2><span>— 表示来源未设置</span></div>
      <div className="lr-product-table-wrap"><Table rowKey="id" columns={columns} data={state.items} size="small" pagination={false} scroll={{x: 1188}} loading={state.loading !== "idle"} noDataElement="没有匹配的商品，请调整条件。" /></div>
      <div className="lr-product-pagination"><Select aria-label="商品每页款数" value={state.pageSize} options={PRODUCT_PAGE_SIZES.map(value => ({label: `${value} 款 / 页`, value}))} onChange={value => void controller.setPageSize(Number(value))} /><span>共 {state.total} 款 · 第 {state.page} / {Math.max(1, Math.ceil(state.total / state.pageSize))} 页</span><Pagination size="small" simple current={state.page} pageSize={state.pageSize} total={state.total} onChange={page => void controller.setPage(page)} /></div>
    </section>
  </section>;
}
