import { api, type PageFetcher } from "@stage05";
import { loadSkuProjection } from "./skuRepository";
import type { ProductListRow, ProductRecord, ReferenceRecord } from "./data";

export interface LegacyProductFilters {
  q: string;
  years: string[];
  categories: string[];
  seasons: string[];
  supplierId: string;
  fitId: string;
  thickness: string;
  shapeCode: string;
  schemeId: string;
}

export const emptyLegacyProductFilters = (): LegacyProductFilters => ({
  q: "", years: [], categories: [], seasons: [], supplierId: "", fitId: "", thickness: "", shapeCode: "", schemeId: "",
});

const apiBase = (import.meta as ImportMeta & { env?: { VITE_STAGE05_API_BASE?: string } }).env?.VITE_STAGE05_API_BASE || "/stage05-api";
const productCache = new Map<string, ProductRecord>();

function descendants(selected: readonly string[], categories: readonly ReferenceRecord[]): string[] {
  const picked = new Set(selected);
  let changed = true;
  while (changed) {
    changed = false;
    for (const category of categories) {
      if (!category.code || !category.parent_code || !picked.has(category.parent_code) || picked.has(category.code)) continue;
      picked.add(category.code); changed = true;
    }
  }
  return [...picked];
}

function runtimeError(value: unknown): string {
  return value && typeof value === "object" && "error" in value && typeof value.error === "string"
    ? value.error : "商品查询服务未返回有效结果";
}

async function productCodes(filters: LegacyProductFilters, categories: readonly ReferenceRecord[], page: number, size: number, signal: AbortSignal) {
  const query = {
    page, size,
    filters: {
      ...(filters.q.trim() ? { q: filters.q.trim() } : {}),
      ...(filters.years.length ? { years: filters.years } : {}),
      ...(filters.categories.length ? { categories: descendants(filters.categories, categories) } : {}),
      ...(filters.seasons.length ? { seasons: filters.seasons } : {}),
      ...(filters.supplierId ? { supplierId: filters.supplierId } : {}),
      ...(filters.fitId ? { fitId: filters.fitId } : {}),
      ...(filters.thickness ? { thickness: filters.thickness } : {}),
      ...(filters.shapeCode ? { shapeCode: filters.shapeCode } : {}),
      ...(filters.schemeId ? { schemeId: filters.schemeId } : {}),
    },
  };
  const response = await fetch(`${apiBase}/runtime/products?query=${encodeURIComponent(JSON.stringify(query))}`, { credentials: "same-origin", cache: "no-store", signal });
  const body: unknown = await response.json().catch(() => null);
  if (!response.ok || !body || typeof body !== "object" || !("ok" in body) || body.ok !== true) throw Error(runtimeError(body));
  if (!("source" in body) || body.source !== "REAL_TPLUS_RUNTIME" || !("schema" in body) || body.schema !== "v2_runtime_stage03c") throw Error("商品查询来源不符");
  const data = "data" in body ? body.data : null;
  if (!data || typeof data !== "object" || !("codes" in data) || !Array.isArray(data.codes) || !("total" in data) || !Number.isSafeInteger(data.total)) throw Error("商品分页数据无效");
  const codes = data.codes as unknown[];
  if (codes.length > size || codes.some(code => typeof code !== "string") || new Set(codes).size !== codes.length) throw Error("商品分页款号无效");
  return { codes: codes as string[], total: data.total as number };
}

async function currentPage(codes: readonly string[], signal: AbortSignal): Promise<ProductRecord[]> {
  const items = new Array<ProductRecord>(codes.length);
  let cursor = 0;
  async function worker() {
    while (cursor < codes.length) {
      if (signal.aborted) throw new DOMException("Aborted", "AbortError");
      const index = cursor++, code = codes[index]!;
      let record = productCache.get(code);
      if (!record) {
        record = await api.getProduct(code, signal);
        if (!signal.aborted) productCache.set(code, record);
      }
      items[index] = record;
    }
  }
  await Promise.all(Array.from({ length: Math.min(8, codes.length) }, worker));
  return items;
}

export function makeLegacyProductFetcher(getCategories: () => readonly ReferenceRecord[]): PageFetcher<LegacyProductFilters, ProductListRow> {
  return async ({ applied, page, pageSize, signal }) => {
    const [lookup, result] = await Promise.all([
      loadSkuProjection(),
      productCodes(applied, getCategories(), page, pageSize, signal).then(async slice => ({ ...slice, items: await currentPage(slice.codes, signal) })),
    ]);
    const items = result.items.map(record => {
      const identity = lookup.productByCode(record.code);
      if (!identity || identity.productId !== record.id) throw Error(`商品身份与来源规格不一致：${record.code}`);
      return { ...record, identity };
    });
    return { items, total: result.total };
  };
}
