// Shared Stage05 data and domain adapter; UI lives in legacy-rebuild.
export * from "@stage05/features/products/logic";
