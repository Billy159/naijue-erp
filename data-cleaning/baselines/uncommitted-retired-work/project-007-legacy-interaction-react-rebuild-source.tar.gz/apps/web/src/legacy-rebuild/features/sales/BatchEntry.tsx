import { useEffect, useMemo, useState } from "react";
import { Alert, Button, Input, InputNumber, Modal, Space, Table, Typography } from "@arco-design/web-react";
import {
  api, formatSignedQuantity, parseSignedQuantity,
  type DisplaySku, type ProductRecord, type SkuInputReference, type SkuLookup,
} from "@stage05";
import { text, type RawLine } from "./model";

export interface PendingSku {reference: SkuInputReference; sku: DisplaySku; quantity: string; unitPrice: string; productName?: string}
export function BatchEntry({visible, lookup, existing, onCancel, onAppend}: {
  visible: boolean; lookup: SkuLookup | null; existing: RawLine[];
  onCancel: () => void; onAppend: (lines: PendingSku[]) => void;
}) {
  const [q, setQ] = useState(""), [results, setResults] = useState<ProductRecord[]>([]);
  const [product, setProduct] = useState<ProductRecord | null>(null), [entries, setEntries] = useState<Record<string, string>>({});
  const [price, setPrice] = useState("0"), [loading, setLoading] = useState(false), [error, setError] = useState("");
  useEffect(() => {if (visible) {setQ(""); setResults([]); setProduct(null); setEntries({}); setPrice("0"); setError("");}}, [visible]);
  const current = useMemo(() => {
    const totals = new Map<string, bigint>();
    for (const line of existing) totals.set(line.sku_id, (totals.get(line.sku_id) || 0n) + parseSignedQuantity(line.source_quantity));
    return Object.fromEntries([...totals].map(([id, value]) => [id, formatSignedQuantity(value)]));
  }, [existing]);
  const identity = product && lookup?.productByCode(product.code);
  const matrix = identity ? lookup?.matrixForProduct(identity.productId, current) : null;
  const selected = Object.values(entries).filter(value => value && parseSignedQuantity(value) !== 0n).length;
  async function search() {
    setLoading(true); setError("");
    try { const response = await api.listProducts({page: 1, pageSize: 20, q: q.trim()}); setResults(response.items); }
    catch (issue) {setError(issue instanceof Error ? issue.message : "查找商品失败");}
    finally {setLoading(false);}
  }
  function append() {
    if (!lookup || !matrix) return;
    try {
      const pending: PendingSku[] = [];
      for (const section of matrix.sections) for (const row of section.rows) for (const cell of row.cells) for (const entry of cell.entries) {
        if (!entry.skuId) continue;
        const value = entries[entry.skuId];
        if (!value || parseSignedQuantity(value) === 0n) continue;
        if (!entry.editable) throw Error("该规格当前不可录入");
        pending.push({reference: lookup.inputReference(entry), sku: lookup.skuById(entry.skuId)!, quantity: value, unitPrice: price, ...(product?.name ? {productName: product.name} : {})});
      }
      if (!pending.length) throw Error("请先填写本次追加数量");
      onAppend(pending);
      setError("");
    } catch (issue) {setError(issue instanceof Error ? issue.message : "批量录入失败");}
  }
  return <Modal visible={visible} title="商品批量录入" style={{width: "min(1200px, calc(100vw - 48px))"}} onCancel={onCancel} onOk={append} okText={`追加 ${selected} 个规格`} unmountOnExit maskClosable={false}>
    <Space direction="vertical" size="medium" style={{width: "100%"}}>
      <Alert type="info" showIcon content="矩阵中的“本次追加”只表示即将加入单据的数量；“当前已有”来自现有单据。确认后按原 SKU 身份追加，不覆盖当前数量。" />
      <Space wrap><Input.Search aria-label="批量搜索商品" value={q} onChange={setQ} onSearch={() => void search()} placeholder="货号或商品名称" style={{width: 300}} loading={loading} /><Button onClick={() => void search()}>搜索商品</Button><InputNumber aria-label="本次追加单价" value={Number(price)} min={0} precision={2} hideControl onChange={value => setPrice(String(value ?? 0))} prefix="¥" style={{width: 165}} /></Space>
      {error && <Alert type="error" showIcon content={error} />}
      {!product && <Table rowKey="id" size="small" pagination={false} data={results} columns={[
        {title: "款号", dataIndex: "code"}, {title: "商品名称", dataIndex: "name"},
        {title: "操作", render: (_: unknown, item: ProductRecord) => <Button size="small" type="text" onClick={() => {setProduct(item); setEntries({}); setPrice(text(item.attributes?.price) || "0");}}>选择</Button>},
      ]} noDataElement="输入货号或名称搜索商品" />}
      {product && <><Space><Typography.Text bold>{product.code} · {product.name}</Typography.Text><Button type="text" onClick={() => {setProduct(null); setEntries({});}}>换商品</Button></Space>
        {!matrix && <Alert type="error" content="该商品未进入已验证的 SKU 投影，不能按展示名称猜规格。" />}
        {matrix?.sections.map(section => <div key={section.group.name} className="s05-sales-matrix-section"><Typography.Title heading={6}>{section.group.name}</Typography.Title><div className="s05-sales-matrix-scroll"><table className="s05-sales-matrix"><thead><tr><th>颜色</th>{section.group.columns.map(column => <th key={column.key}>{column.name}</th>)}</tr></thead><tbody>{section.rows.map(row => <tr key={`${row.product.productId}:${row.color.colorId}`}><th>{row.color.name}</th>{row.cells.map(cell => <td key={cell.column.key}>{cell.missing ? <span className="s05-sales-muted">— 无此规格</span> : cell.entries.map(entry => <div key={entry.skuId} className="s05-sales-matrix-entry"><span>{entry.fit?.code}版 · 当前已有 {entry.displayValue ?? "0"}</span><InputNumber aria-label={`${row.color.name} ${cell.column.name} ${entry.fit?.code}版 本次追加`} value={entry.skuId && entries[entry.skuId] ? Number(entries[entry.skuId]) : undefined} disabled={!entry.editable} precision={4} hideControl placeholder="本次追加" onChange={value => {
          if (!entry.skuId) return;
          setEntries(currentEntries => ({...currentEntries, [entry.skuId!]: value === undefined || value === null ? "" : String(value)}));
        }} /></div>)}</td>)}</tr>)}</tbody></table></div></div>)}
      </>}
    </Space>
  </Modal>;
}
