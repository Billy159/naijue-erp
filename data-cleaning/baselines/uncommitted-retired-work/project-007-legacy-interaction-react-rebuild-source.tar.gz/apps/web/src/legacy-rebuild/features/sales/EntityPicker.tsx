import { useMemo, useState } from "react";
import { Button, Select } from "@arco-design/web-react";

export interface EntityOption {id: string; name: string; subtitle?: string; disabled?: boolean}

// Keep the 8877 staged multi-select action inside Arco Select's dropdown.
export function EntityPicker({label, items, value, onChange, multiple = false, allLabel, disabled = false}: {
  label: string;
  items: readonly EntityOption[];
  value: string | string[];
  onChange: (value: string | string[]) => void;
  multiple?: boolean;
  allLabel?: string;
  disabled?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [query, setQuery] = useState("");
  const ids = Array.isArray(value) ? value : value ? [value] : [];
  const selectedIds = open ? selected : ids;
  const options = useMemo(() => items.map(item => ({
    label: item.subtitle ? <span>{item.name}<small className="lr-sale-entity-subtitle">{item.subtitle}</small></span> : item.name,
    value: item.id,
    ...(item.disabled ? {disabled: true} : {}),
  })), [items]);
  const matching = useMemo(() => items.filter(item => `${item.name} ${item.subtitle || ""} ${item.id}`.toLocaleLowerCase().includes(query.toLocaleLowerCase()) && !item.disabled), [items, query]);
  const matchedSelected = matching.filter(item => selectedIds.includes(item.id)).length;
  function apply() {
    const enabled = items.filter(item => !item.disabled);
    onChange(enabled.length && enabled.every(item => selected.includes(item.id)) ? [] : selected);
    setOpen(false);
  }
  return <Select
    className="lr-sale-entity-control"
    aria-label={label}
    disabled={disabled}
    {...(multiple ? {mode: "multiple" as const, maxTagCount: 1} : {})}
    placeholder={allLabel || `请选择${label}`}
    allowClear
    showSearch
    popupVisible={open}
    value={multiple ? selectedIds : ids[0] || ""}
    options={options}
    filterOption={(input, option) => {
      const item = items.find(candidate => candidate.id === (option.props as {value?: string}).value);
      return Boolean(item && `${item.name} ${item.subtitle || ""} ${item.id}`.toLocaleLowerCase().includes(input.toLocaleLowerCase()));
    }}
    virtualListProps={{height: Math.min(Math.max(items.length, 1) * 36, 320)}}
    dropdownMenuStyle={{maxHeight: 320}}
    onVisibleChange={visible => {setOpen(visible); if (visible) {setSelected(ids); setQuery("");}}}
    onInputValueChange={input => setQuery(input)}
    onChange={next => {
      if (multiple) setSelected(Array.isArray(next) ? next.map(String) : []);
      else {onChange(String(next || "")); setOpen(false);}
    }}
    {...(multiple ? {dropdownRender: (menu: React.ReactNode) => <div className="lr-sale-entity-dropdown">
      <div className="lr-sale-entity-tools" onMouseDown={event => event.preventDefault()}>
        <Button type="text" size="small" disabled={!matching.length} onClick={() => setSelected(current => matchedSelected === matching.length ? current.filter(id => !matching.some(item => item.id === id)) : [...new Set([...current, ...matching.map(item => item.id)])])}>{matching.length && matchedSelected === matching.length ? "取消全选当前匹配" : "全选当前匹配"}</Button>
        <span>匹配 {matching.length} 项</span>
      </div>
      {menu}
      <footer onMouseDown={event => event.preventDefault()}><span>已选 {selected.length} 项</span><Button size="small" onClick={() => setOpen(false)}>取消</Button><Button size="small" type="primary" onClick={apply}>确定</Button></footer>
    </div>} : {})}
  />;
}
