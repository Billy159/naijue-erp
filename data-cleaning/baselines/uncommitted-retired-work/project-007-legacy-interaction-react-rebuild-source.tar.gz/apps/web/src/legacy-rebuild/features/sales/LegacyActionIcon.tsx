import { Button } from "@arco-design/web-react";

const paths = {
  detail: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8Z" /><path d="M14 2v6h6M8 13h8M8 17h6" /></>,
  edit: <path d="m4 16-1 5 5-1L20 8l-4-4Z M14 6l4 4" />,
  remove: <path d="M3 6h18M9 6V3h6v3M6 6l1 15h10l1-15M10 10v7M14 10v7" />,
  more: <><circle cx="5" cy="12" r="1" /><circle cx="12" cy="12" r="1" /><circle cx="19" cy="12" r="1" /></>,
};
export function LegacyActionIcon({kind, label, onClick}: {kind: keyof typeof paths; label: string; onClick: () => void}) {
  return <Button className="lr-sale-action-icon" type="text" aria-label={label} title={label} onClick={onClick}><svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[kind]}</svg></Button>;
}
