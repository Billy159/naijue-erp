import { useEffect, useMemo, useState } from "react";
import { Alert, Button, InputNumber, Modal, Select } from "@arco-design/web-react";
import { AmountDisplay, moneyFromDecimal, type Money } from "@stage05";
import { amount, cents, decimal, text, type RawFund } from "./model";

export interface PaymentOption {id: string; name: string; primary_payment_method_id?: string | null}
interface Row {
  id: string; methodId: string; accountId: string; amountText: string; referenceText: string;
  original?: RawFund;
}
const blank = (): Row => ({id: crypto.randomUUID(), methodId: "", accountId: "", amountText: "", referenceText: ""});
const fromFund = (fund: RawFund): Row => ({
  id: fund.source_id, methodId: fund.payment_method_id, accountId: fund.fund_account_id,
  amountText: text(fund.amount), referenceText: text((fund.reference as Record<string, unknown> | null)?.note), original: fund,
});
export function commitPaymentRows(rows: readonly Row[], accounts: readonly PaymentOption[], methods: readonly PaymentOption[]): RawFund[] {
  const result: RawFund[] = [];
  for (const [index, row] of rows.entries()) {
    if (!row.methodId && !row.accountId && row.amountText === "" && !row.referenceText.trim()) continue;
    if (!row.methodId) throw Error(`第 ${index + 1} 笔缺少收款方式`);
    if (!row.accountId) throw Error(`第 ${index + 1} 笔缺少资金账户`);
    if (row.amountText === "") throw Error(`第 ${index + 1} 笔缺少金额`);
    const value = cents(row.amountText);
    if (value === null) throw Error(`第 ${index + 1} 笔金额无效`);
    const account = accounts.find(item => item.id === row.accountId);
    const method = methods.find(item => item.id === row.methodId);
    if (!account || !method) throw Error(`第 ${index + 1} 笔方式或账户不存在`);
    if (account.primary_payment_method_id !== row.methodId && !(row.original && row.original.payment_method_id === row.methodId && row.original.fund_account_id === row.accountId)) throw Error(`第 ${index + 1} 笔方式与账户不匹配`);
    const direction = value > 0n ? "receipt" : value < 0n ? "refund" : "zero";
    result.push({
      ...row.original,
      source_id: row.id, settlement_id: row.original?.settlement_id || row.id,
      payment_method_id: row.methodId, fund_account_id: row.accountId,
      source_payment_method_name: method.name, source_fund_account_name: account.name,
      amount: decimal(value), direction,
      reference: row.referenceText.trim() ? {...((row.original?.reference as Record<string, unknown> | null) || {}), note: row.referenceText.trim()} : row.original?.reference ?? null,
    });
  }
  return result;
}
export function PaymentEditor({visible, funds, due, accounts, methods, onCancel, onConfirm}: {
  visible: boolean; funds: RawFund[]; due: Money;
  accounts: PaymentOption[]; methods: PaymentOption[];
  onCancel: () => void; onConfirm: (next: RawFund[]) => void;
}) {
  const [rows, setRows] = useState<Row[]>([]), [error, setError] = useState("");
  useEffect(() => { if (visible) {setRows(funds.length ? funds.map(fromFund) : [blank()]); setError("");} }, [visible, funds]);
  const entered = useMemo(() => rows.reduce((sum, row) => sum + (row.amountText === "" ? 0n : cents(row.amountText) ?? 0n), 0n), [rows]);
  const gap = due.kind === "known" ? amount(BigInt(due.minorUnits) - entered) : {kind: "unknown", reason: "missing"} as Money;
  const change = (id: string, patch: Partial<Row>) => setRows(current => current.map(row => row.id === id ? {...row, ...patch} : row));
  const confirm = () => {
    try { const next = commitPaymentRows(rows, accounts, methods); onConfirm(next); setError(""); }
    catch (issue) { setError(issue instanceof Error ? issue.message : "支付明细无效"); }
  };
  return <Modal className="lr-sale-payment-modal" title="支付明细" visible={visible} style={{width: "min(700px, calc(100vw - 32px))"}} onCancel={onCancel} onOk={confirm} okText="确定" cancelText="取消" unmountOnExit maskClosable={false} escToExit>
    <div className="lr-sale-funds-editor">
      <div className="lr-sale-funds-summary">应结 <AmountDisplay value={due} />　 已填 <AmountDisplay value={amount(entered)} />　 差额 <AmountDisplay value={gap} /></div>
      <p className="lr-sale-funds-note">账户展示全部门店；选择账户后带出其支付方式。金额支持负数退款。</p>
      {rows.map((row, index) => <div className="lr-sale-funds-row" key={row.id}>
        <label>支付方式<Select aria-label={`第 ${index + 1} 笔方式`} showSearch value={row.methodId} placeholder="请选择" options={methods.map(item => ({label: item.name, value: item.id}))} onChange={value => change(row.id, {methodId: String(value || ""), accountId: ""})} /></label>
        <label>资金账户<Select aria-label={`第 ${index + 1} 笔账户`} showSearch value={row.accountId} placeholder="请选择" options={accounts.map(item => ({label: item.name, value: item.id}))} onChange={value => {const account = accounts.find(item => item.id === value); change(row.id, {accountId: String(value || ""), methodId: account?.primary_payment_method_id || row.methodId});}} /></label>
        <label>金额<InputNumber aria-label={`第 ${index + 1} 笔金额`} value={row.amountText === "" ? undefined : Number(row.amountText)} precision={2} hideControl placeholder="请输入金额" onChange={value => change(row.id, {amountText: value == null ? "" : String(value)})} /></label>
        <Button onClick={() => setRows(current => current.filter(item => item.id !== row.id))}>移除</Button>
      </div>)}
      <Button onClick={() => setRows(current => [...current, blank()])}>增加支付</Button>
      {error && <Alert type="error" showIcon content={error} />}
    </div>
  </Modal>;
}
export {moneyFromDecimal};
