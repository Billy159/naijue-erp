import { useState } from "react";
import { Alert, Button, Collapse, DatePicker, Input, Modal, Table } from "@arco-design/web-react";
import { AmountDisplay, moneyToDecimal, type SkuLookup } from "@stage05";
import {
  amount, businessDate, cents, dueAmount, fundView, fundsAmount, headerValue, isHistoricalSettlementUnknown,
  lineTotal, quantityTotal, saleKind, text, type RawFund, type RawLine, type SaleDocument,
} from "./model";
import { LegacyActionIcon } from "./LegacyActionIcon";

function sourceName(header: Record<string, unknown>, key: string) {
  const payload = header.source_payload as Record<string, unknown> | undefined;
  const source = payload?.source as Record<string, unknown> | undefined;
  return text(source?.[key]);
}
function ReadField({label, value, hint}: {label: React.ReactNode; value: React.ReactNode; hint?: React.ReactNode}) {
  return <label>{label}<span className="lr-sale-read-value">{value}</span>{hint && <small>{hint}</small>}</label>;
}
function categoryTotals(lines: RawLine[], categories: Map<string, string>): Array<[string, string]> {
  const groups = new Map<string, RawLine[]>();
  for (const line of lines) {
    if (line.gift) continue;
    const name = categories.get(text(line.source_product_code)) || text(line.source_category_name) || "分类来源未提供";
    groups.set(name, [...(groups.get(name) || []), line]);
  }
  return [...groups].map(([name, rows]) => [name, quantityTotal(rows)]);
}
export function SaleFundsTable({funds, historicalUnknown}: {funds: RawFund[]; historicalUnknown?: boolean}) {
  return <div className="lr-sale-funds-readonly">
    {historicalUnknown && <Alert type="warning" showIcon content="历史收退款记录不完整 / 未知，未补造付款事实。" />}
    {funds.length ? funds.map((raw, index) => {const fund = fundView(raw); return <div className="lr-sale-funds-row" key={raw.source_id}>
      <ReadField label="支付方式" value={fund.paymentMethod.kind === "known" ? fund.paymentMethod.value.name : "未提供"} />
      <ReadField label="资金账户" value={fund.account.kind === "known" ? fund.account.value.name : "未提供"} />
      <ReadField label="金额" value={<AmountDisplay value={fund.amount} />} />
      <span className="lr-sale-funds-index">第 {index + 1} 笔</span>
    </div>;}) : <p>0 笔收退款</p>}
  </div>;
}
function SaleLinesTable({lines, lookup}: {lines: RawLine[]; lookup?: SkuLookup | undefined}) {
  const columns = [
    {title: "商品名称／款号", key: "product", width: 310, render: (_: unknown, line: RawLine) => <div className="lr-sale-product-cell"><strong>{text(line.source_product_code) || lookup?.skuById(line.sku_id)?.product.sourceCode || "未提供"}</strong><span>{text(line.source_product_name) || "商品"}</span>{Boolean(line.gift) && <small>赠品</small>}</div>},
    {title: "颜色", key: "color", render: (_: unknown, line: RawLine) => lookup?.skuById(line.sku_id)?.color.name || text(line.source_color_name) || "—"},
    {title: "尺码", key: "size", render: (_: unknown, line: RawLine) => text(line.source_size_name) || lookup?.skuById(line.sku_id)?.column.name || "—"},
    {title: "数量", key: "quantity", render: (_: unknown, line: RawLine) => text(line.source_quantity)},
    {title: "参考零售价", key: "reference", align: "right" as const, render: (_: unknown, line: RawLine) => {const value = cents(text(line.reference_price)); return value === null ? "—" : moneyToDecimal(amount(value));}},
    {title: "折扣", key: "discount", render: (_: unknown, line: RawLine) => {const reference = cents(text(line.reference_price)), price = cents(line.unit_price); return reference && reference > 0n && price !== null ? `${(Number(price) / Number(reference) * 10).toFixed(4)}折` : "—";}},
    {title: "成交单价", key: "price", align: "right" as const, render: (_: unknown, line: RawLine) => {const value = cents(line.unit_price); return value === null ? "—" : moneyToDecimal(amount(value));}},
    {title: "金额", key: "amount", align: "right" as const, render: (_: unknown, line: RawLine) => moneyToDecimal(lineTotal([line])) || "—"},
    {title: "操作", key: "action", width: 136, render: (_: unknown, line: RawLine) => <LegacyActionIcon kind="detail" label="查看商品详情" onClick={() => window.open(`/products/${encodeURIComponent(text(line.source_product_code))}`, "_blank", "noopener,noreferrer")} />},
  ];
  return <div className="lr-sale-lines"><Table className="lr-sale-lines-table" rowKey="source_id" columns={columns} data={lines} pagination={false} tableLayoutFixed={false} size="small" border={{wrapper: false, cell: false}} noDataElement="没有商品明细" /></div>;
}
export function SaleFacts({document, lookup, names, categories = new Map(), print = false, scanCount = 0, onOpenScan}: {document: SaleDocument; lookup?: SkuLookup | undefined; names?: {hall?: string | undefined; warehouse?: string | undefined; customer?: string | undefined; employee?: string | undefined}; categories?: Map<string, string>; print?: boolean; scanCount?: number; onOpenScan?: () => void}) {
  const [fundsOpen, setFundsOpen] = useState(false);
  const header = document.body.header, kind = saleKind(document.body.lines), funds = document.body.fundsRecords;
  const payload = header.source_payload as Record<string, unknown> | undefined;
  const hall = text(header.hall_name) || names?.hall || (payload?.hallResolution === "functional_department_not_a_hall" ? "未映射营业厅" : sourceName(header, "部门") || "待确认");
  const warehouse = text(header.warehouse_name) || text(header.source_warehouse_name) || names?.warehouse || sourceName(header, "仓库") || "历史未提供";
  const customer = text(header.customer_name) || names?.customer || sourceName(header, "客户") || "未提供";
  const employee = text(header.employee_name) || names?.employee || sourceName(header, "业务员") || "未提供";
  const incoming = document.body.lines.filter(line => Number(line.source_quantity) < 0), outgoing = document.body.lines.filter(line => Number(line.source_quantity) > 0);
  const unknown = isHistoricalSettlementUnknown(document);
  return <div className={`lr-sale-detail-facts${print ? " s05-sales-print-content" : ""}`}>
    {print && <h1>奈爵服饰 · 销货单 {document.number}</h1>}
    <div className="lr-sale-doc-header">
      <ReadField label={<>业务类型 <span className="lr-sale-required">*</span></>} value={kind === "销售" ? "销售" : "退货/换货"} />
      <ReadField label="营业厅" value={hall} />
      <ReadField label="出库仓" value={warehouse} />
      <ReadField label="营业员" value={employee} />
      <ReadField label="客户" value={customer} />
      <label>单据日期<DatePicker aria-label="单据日期" disabled showTime={{format: "HH:mm"}} format="YYYY-MM-DD HH:mm" value={(headerValue(header, "business_date").includes("T") ? headerValue(header, "business_date").slice(0, 16) : `${businessDate(header)} 00:00`).replace("T", " ")} />{document.baseline_was_included && businessDate(header).length === 10 && <small>历史日期来源未提供时分</small>}</label>
      <ReadField label="整单优惠 / 抹零" value={`¥${Number(headerValue(header, "adjustment") || 0).toFixed(2)}`} />
      <label>收退款账户{print ? <span className="lr-sale-read-value">{funds.length} 笔支付明细</span> : <Button className="lr-sale-funds-button" onClick={() => setFundsOpen(true)}>{funds.length ? `${funds.length} 笔支付明细` : "请选择"}</Button>}</label>
      <ReadField label="结算合计" value={fundsAmount(funds).kind === "known" ? moneyToDecimal(fundsAmount(funds)) : "未知"} hint={unknown ? "历史收退款记录不完整 / 未知" : <>应结 <AmountDisplay value={dueAmount(document.body)} /></>} />
      <div className="lr-sale-meta"><span>单号：{document.number}</span><span>制单人：{document.baseline_was_included ? "历史未提供" : "管理员"}</span></div>
    </div>
    {kind === "换货" ? <>
      <div className="lr-sale-entry-section"><div className="lr-sale-section-head"><h2>退回商品</h2></div><SaleLinesTable lines={incoming} lookup={lookup} /></div>
      <div className="lr-sale-entry-section"><div className="lr-sale-section-head"><h2>换出商品</h2><div>{onOpenScan && !print && <Button type="text" onClick={onOpenScan}>扫码记录（{scanCount}）</Button>}</div></div><SaleLinesTable lines={outgoing} lookup={lookup} /></div>
    </> : <div className="lr-sale-entry-section"><div className="lr-sale-section-head"><h2>{kind === "退货" ? "退回商品" : "商品明细"}</h2><div>{onOpenScan && !print && <Button type="text" onClick={onOpenScan}>扫码记录（{scanCount}）</Button>}</div></div><SaleLinesTable lines={document.body.lines} lookup={lookup} /></div>}
    <Collapse className="lr-sale-note" bordered={false} defaultActiveKey={headerValue(header, "note") ? ["note"] : []}><Collapse.Item name="note" header="整单备注（可选）"><Input aria-label="整单备注" readOnly value={headerValue(header, "note")} /></Collapse.Item></Collapse>
    <footer className="lr-sale-summary"><div className="lr-sale-core-metrics">{kind !== "销售" && <div className="lr-sale-core-metric"><span>退回</span><strong>{quantityTotal(incoming).replace(/^-/, "")}</strong></div>}{kind === "换货" && <div className="lr-sale-core-metric"><span>换出</span><strong>{quantityTotal(outgoing)}</strong></div>}{kind === "销售" && <div className="lr-sale-core-metric"><span>销售数量</span><strong>{quantityTotal(document.body.lines)}</strong></div>}<div className="lr-sale-core-metric"><span>{kind === "销售" ? "销售金额" : "应结金额"}</span><strong><AmountDisplay value={dueAmount(document.body)} /></strong></div></div>{kind === "销售" && <div className="lr-sale-category-summary" aria-label="销售分类汇总">{categoryTotals(document.body.lines, categories).length ? categoryTotals(document.body.lines, categories).map(([name, total], index) => <span key={name}>{index > 0 && <i aria-hidden="true"> · </i>}{name} {total}</span>) : <span>暂无销售商品</span>}</div>}<div className="lr-sale-summary-secondary"><span>{new Set(document.body.lines.map(line => text(line.source_product_code))).size} 款 · {document.body.lines.length} 条明细</span><span>商品金额 <AmountDisplay value={lineTotal(document.body.lines)} /></span><span>整单调整 {Number(headerValue(header, "adjustment") || 0).toFixed(2)}</span></div></footer>
    {print && <SaleFundsTable funds={funds} historicalUnknown={unknown} />}
    <Modal className="lr-sale-payment-modal" title="支付明细" visible={fundsOpen} style={{width: "min(700px, calc(100vw - 32px))"}} onCancel={() => setFundsOpen(false)} footer={<Button onClick={() => setFundsOpen(false)}>关闭</Button>}><div className="lr-sale-funds-summary">应结 <AmountDisplay value={dueAmount(document.body)} />　 已填 <AmountDisplay value={fundsAmount(funds)} /></div><SaleFundsTable funds={funds} historicalUnknown={unknown} /></Modal>
  </div>;
}
