import { Tag } from "@arco-design/web-react";

export function SaleStatusTag({status}: {status: string}) {
  const approved = status === "APPROVED";
  return <Tag className={`lr-sale-status${approved ? " is-approved" : ""}`} color={approved ? "green" : "gold"}>{approved ? "已审核" : status === "VOIDED" ? "已作废" : "未审核"}</Tag>;
}
