import { useEffect, useMemo, useRef, useState } from "react";
import "./style.css";
import { Alert, Button, Collapse, Drawer, Dropdown, Menu, Modal, Space, Timeline, Typography } from "@arco-design/web-react";
import {
  api, ApiError, DocumentCommandController, ErrorState, LoadingState,
  NotFoundState, feedback, navigate, newRequestKey, returnToList,
  type DocumentCommand, type SkuLookup,
} from "@stage05";
import { SaleFacts } from "./SaleFacts";
import { SaleStatusTag } from "./SaleStatusTag";
import { ScanRecordWindow } from "./ScanRecordWindow";
import { asSale, headerValue, text, type SaleBody, type SaleDocument } from "./model";
import { salesSkuRepository } from "./session";
import type { ReferenceName } from "@stage05/contracts/reference";

type DetailState = {kind: "loading" | "ready" | "not-found" | "error"; document?: SaleDocument; message?: string};
type HistoryEntry = {version: number; operation: string; actor_id: string | null; created_at: string | null; revision: number; body?: unknown; previous_body?: unknown};
type Named = {id: string; name: string; department_id?: string | null};
type References = {halls: Named[]; warehouses: Named[]; customers: Named[]; employees: Named[]; aliases: Record<string, string>; configuredHalls: Named[]; categories: Map<string, string>};
const EMPTY_REFS: References = {halls: [], warehouses: [], customers: [], employees: [], aliases: {}, configuredHalls: [], categories: new Map()};
async function allReference(name: ReferenceName, signal: AbortSignal): Promise<Named[]> {
  const first = await api.listReference<Named>(name, {page: 1, pageSize: 200}, signal);
  const items = [...first.items];
  for (let page = 2; items.length < first.total; page++) items.push(...(await api.listReference<Named>(name, {page, pageSize: 200}, signal)).items);
  return items;
}
const operationName: Record<string, string> = {create: "新建保存", save: "保存修订", approve: "审核", unapprove: "弃审"};
function revisionChanges(entry: HistoryEntry): string[] {
  const before = entry.previous_body as SaleBody | undefined, after = entry.body as SaleBody | undefined;
  if (!before?.header || !after?.header) return ["该版本没有可显示的正文对比；服务端仍保留版本记录。"];
  const changes: string[] = [];
  for (const [key, label] of [["business_date", "业务日期"], ["hall_name", "营业厅"], ["warehouse_name", "仓库"], ["customer_name", "客户"], ["employee_name", "营业员"], ["adjustment", "整单调整"], ["note", "备注"]] as const) {
    const oldValue = headerValue(before.header, key), newValue = headerValue(after.header, key);
    if (oldValue !== newValue) changes.push(`${label}：${oldValue || "未提供"} → ${newValue || "未提供"}`);
  }
  if (JSON.stringify(before.lines) !== JSON.stringify(after.lines)) changes.push(`商品明细已修订：${before.lines.length} 行 → ${after.lines.length} 行`);
  if (JSON.stringify(before.fundsRecords) !== JSON.stringify(after.fundsRecords)) changes.push(`收退款明细已修订：${before.fundsRecords.length} 笔 → ${after.fundsRecords.length} 笔`);
  return changes.length ? changes : ["本次保存未改变当前展示字段；服务端仍保留版本记录。"];
}
function HistoryDrawer({visible, document, onCancel}: {visible: boolean; document: SaleDocument; onCancel: () => void}) {
  const entries = (document.history || []) as HistoryEntry[];
  return <Drawer visible={visible} title={`操作历史 · ${document.number}`} width="min(560px, calc(100vw - 48px))" footer={null} onCancel={onCancel}>
    {entries.length ? <Timeline>{entries.map(entry => <Timeline.Item key={entry.version} label={entry.created_at ? new Date(entry.created_at).toLocaleString("zh-CN") : "时间未提供"}>
      <strong>版本 {entry.version} · {operationName[entry.operation] || entry.operation}</strong>
      <div className="s05-sales-muted">操作人：{entry.actor_id === "local-admin" ? "管理员" : entry.actor_id || "历史未提供"} · 修订 {entry.revision}</div>
      {entry.operation === "save" && <Collapse bordered={false}><Collapse.Item name="revision" header="修订记录"><Space direction="vertical" size="mini">{revisionChanges(entry).map(change => <Typography.Text key={change} type="secondary">{change}</Typography.Text>)}</Space></Collapse.Item></Collapse>}
    </Timeline.Item>)}</Timeline> : <Alert type="info" showIcon content="这张历史导入单没有运行操作记录；原创建者、审核人和时间未提供。" />}
  </Drawer>;
}
export function SalesDetailPage({id}: {id: string}) {
  const [state, setState] = useState<DetailState>({kind: "loading"});
  const [lookup, setLookup] = useState<SkuLookup | undefined>();
  const [refs, setRefs] = useState<References>(EMPTY_REFS);
  const [retry, setRetry] = useState(0), [pending, setPending] = useState(false), [error, setError] = useState("");
  const [uncertain, setUncertain] = useState<DocumentCommand | null>(null);
  const [confirmUnapprove, setConfirmUnapprove] = useState(false), [historyOpen, setHistoryOpen] = useState(false), [printOpen, setPrintOpen] = useState(false);
  const [scanOpen, setScanOpen] = useState(false), [scanRecords, setScanRecords] = useState<Record<string, unknown>[]>([]), [scanError, setScanError] = useState("");
  const running = useRef(false), command = useMemo(() => new DocumentCommandController(api), []);
  useEffect(() => {
    const abort = new AbortController(); setState({kind: "loading"});
    void api.getDocument(id, abort.signal).then(value => {
      if (abort.signal.aborted) return;
      const document = asSale(value);
      setState({kind: "ready", document});
      void api.listRuntimeWork(document.number, abort.signal).then(records => {if (!abort.signal.aborted) {setScanRecords(records); setScanError("");}}).catch(issue => {if (!abort.signal.aborted) setScanError(issue instanceof Error ? issue.message : "读取失败");});
    }).catch(issue => {
      if (!abort.signal.aborted) setState(issue instanceof ApiError && issue.kind === "not-found" ? {kind: "not-found"} : {kind: "error", message: issue instanceof Error ? issue.message : "读取销货单失败"});
    });
    void salesSkuRepository().load().then(value => {if (!abort.signal.aborted) setLookup(value);}).catch(() => {});
    void Promise.all([
      allReference("halls", abort.signal), allReference("warehouses", abort.signal),
      allReference("customers", abort.signal), allReference("employees", abort.signal),
      api.getHallConfiguration(abort.signal),
      api.getRuntimeCatalog<{products: Array<{code: string; category_name?: string | null}>}>(abort.signal),
    ]).then(([halls, warehouses, customers, employees, configuration, catalog]) => {
      if (!abort.signal.aborted) setRefs({halls, warehouses, customers, employees, aliases: configuration.aliases, configuredHalls: configuration.stores, categories: new Map(catalog.products.map(product => [product.code, product.category_name || ""]))});
    }).catch(() => {});
    return () => abort.abort();
  }, [id, retry]);
  async function run(operation: "approve" | "unapprove") {
    const document = state.document;
    if (!document || running.current || uncertain) return;
    running.current = true; setPending(true); setError("");
    try {
      const attempt: DocumentCommand = {documentId: document.id, operation, expectedVersion: document.version, requestKey: newRequestKey()};
      const result = await command.submit(attempt);
      if (!result) {const failure = command.getSnapshot(); if (failure.state === "failure" && failure.kind === "network-uncertain") setUncertain(attempt); setError(failure.state === "failure" ? failure.reason : "命令未确认"); return;}
      let latest: SaleDocument;
      try {latest = asSale(await api.getDocument(document.id));}
      catch {setUncertain(attempt); throw Error("命令已提交，但服务端回读未确认；原 requestKey 已保留，请先核对命令结果。");}
      setState({kind: "ready", document: latest});
      setConfirmUnapprove(false);
      feedback.success(operation === "approve" ? "审核成功" : "弃审成功，原流水保留");
    } catch (issue) {setError(issue instanceof Error ? issue.message : "命令后回读失败，请重新读取服务端版本");}
    finally {running.current = false; setPending(false);}
  }
  async function reconcileUncertain() {
    if (!uncertain || running.current) return;
    running.current = true; setPending(true);
    try {
      let latest = asSale(await command.readCurrentDocument(uncertain.documentId));
      if (latest.version === uncertain.expectedVersion) {
        const result = await command.submit(uncertain);
        if (!result) {const failure = command.getSnapshot(); throw Error(failure.state === "failure" ? failure.reason : "原命令仍未确认");}
        latest = asSale(await command.readCurrentDocument(uncertain.documentId));
      }
      const matched = (latest.history as Array<{request_key?: string}>).some(entry => entry.request_key === uncertain.requestKey);
      if (!matched) throw Error("服务端版本已由其它命令改变；原操作未确认，请核对服务端状态。");
      setState({kind: "ready", document: latest}); setUncertain(null); setError(""); setConfirmUnapprove(false);
      feedback.success("已核对原命令及服务端版本");
    } catch (issue) {setError(issue instanceof Error ? issue.message : "结果仍未确认");}
    finally {running.current = false; setPending(false);}
  }
  if (state.kind === "loading") return <LoadingState text="正在读取已保存销货单" />;
  if (state.kind === "not-found") return <NotFoundState title="销货单不存在" onBack={() => returnToList("sales")} backLabel="返回销货列表" />;
  if (state.kind === "error") return <ErrorState message={state.message || "读取失败"} onRetry={() => setRetry(value => value + 1)} />;
  const document = state.document!;
  const header = document.body.header, saved = document.status === "APPROVED";
  const sourceHall = text(header.hall_id) || refs.halls.find(item => item.department_id === text(header.source_department_id))?.id || "";
  const hallId = refs.aliases[sourceHall] || sourceHall;
  const names = {
    hall: refs.halls.find(item => item.id === hallId)?.name || refs.configuredHalls.find(item => item.id === hallId)?.name,
    warehouse: refs.warehouses.find(item => item.id === text(header.source_warehouse_id))?.name,
    customer: refs.customers.find(item => item.id === text(header.source_party_id))?.name,
    employee: refs.employees.find(item => item.id === text(header.source_employee_id))?.name,
  };
  return <section className="lr-sale-workbench lr-sale-editor lr-sale-detail">
    <div className="lr-sale-head"><div className="lr-sale-title"><h1>销货单</h1><SaleStatusTag status={document.status} /><span className="lr-sale-muted">已保存</span></div><div className="lr-sale-head-actions">
      <Button onClick={() => returnToList("sales")}>返回列表</Button>
      {!saved && <Button onClick={() => navigate(`/sales/${encodeURIComponent(id)}/edit`)}>修改</Button>}
      {!saved && <Button type="primary" loading={pending} onClick={() => void run("approve")}>审核</Button>}
      {saved && <Button loading={pending} onClick={() => setConfirmUnapprove(true)}>弃审</Button>}
      <Button onClick={() => setPrintOpen(true)}>打印</Button>
      <Button onClick={() => navigate("/sales/new")}>新增销货单</Button>
      <Dropdown trigger="click" position="br" droplist={<Menu><Menu.Item key="history" onClick={() => setHistoryOpen(true)}>操作历史</Menu.Item></Menu>}><Button>更多操作</Button></Dropdown>
    </div></div>
    {saved && <span className="lr-sale-muted">已审核单如需修改，请先弃审；原版本与来源事实保留在操作历史中。</span>}
    {error && <Alert type="error" showIcon title={error.includes("VERSION_CONFLICT") ? "版本冲突，当前页面没有覆盖服务器" : "操作未完成"} content={<Space direction="vertical">{error}<Button size="small" onClick={() => setRetry(value => value + 1)}>重新读取已保存版本</Button></Space>} />}
    {uncertain && <Alert type="warning" showIcon title="命令结果未确认" content={<Space wrap>原 requestKey 已保留，不能发起新命令。<Button size="small" loading={pending} onClick={() => void reconcileUncertain()}>核对并重试原命令</Button></Space>} />}
    <SaleFacts document={document} lookup={lookup} names={names} categories={refs.categories} scanCount={scanRecords.length} onOpenScan={() => setScanOpen(true)} />
    <ScanRecordWindow visible={scanOpen} documentNumber={document.number} records={scanRecords} error={scanError} onClose={() => setScanOpen(false)} />
    <div className="lr-sale-bottom-note">保存未审核单据不动库存；审核后库存生效，结算明细保留。录错请联系仓库人员弃审。</div>
    <Modal title="确认弃审销货单" visible={confirmUnapprove} onCancel={() => {if (!pending) setConfirmUnapprove(false);}} onOk={() => void run("unapprove")} confirmLoading={pending} okText="确认弃审" maskClosable={false} closable={!pending} escToExit={!pending}>
      <Space direction="vertical"><Typography.Text>单号：{document.number}</Typography.Text><Typography.Text>当前状态：已审核</Typography.Text><Alert type="warning" showIcon content="弃审会反向影响对应仓库库存；已发生的历史流水会保留。" /></Space>
    </Modal>
    <Modal title={`已保存单据打印预览 · ${document.number}`} visible={printOpen} style={{width: "min(1000px, calc(100vw - 32px))"}} onCancel={() => setPrintOpen(false)} onOk={() => window.print()} okText="浏览器打印"><SaleFacts document={document} lookup={lookup} names={names} categories={refs.categories} print /></Modal>
    <HistoryDrawer visible={historyOpen} document={document} onCancel={() => setHistoryOpen(false)} />
  </section>;
}
