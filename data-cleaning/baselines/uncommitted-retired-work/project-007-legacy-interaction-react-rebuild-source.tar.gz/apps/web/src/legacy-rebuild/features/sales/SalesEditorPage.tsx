import { useEffect, useMemo, useRef, useState } from "react";
import "./style.css";
import { Alert, Button, Collapse, DatePicker, Dropdown, Input, InputNumber, Menu, Modal, Select, Space } from "@arco-design/web-react";
import {
  AmountDisplay, ApiError, DocumentCommandController, ErrorState, LoadingState, moneyToDecimal,
  PageContainer, api, feedback, formatSignedQuantity, navigate, newRequestKey, parseSignedQuantity,
  type ConfiguredStore, type DisplaySku, type DocumentCommand, type SkuLookup,
} from "@stage05";
import { BatchEntry, type PendingSku } from "./BatchEntry";
import { PaymentEditor, type PaymentOption } from "./PaymentEditor";
import { SaleFacts } from "./SaleFacts";
import { ScanPanel } from "./ScanPanel";
import { SalesInlineTable, type InlinePendingPresentation } from "./SalesInlineTable";
import { EntityPicker } from "./EntityPicker";
import { SaleStatusTag } from "./SaleStatusTag";
import { inventoryReferences, type InventoryReferences } from "../inventory/data";
import {
  asSale, commandBody, difference, draftFrom, dueAmount, fundsAmount, headerValue,
  lineTotal, makeLine, newDraft, quantityTotal, saleKind, text, updateLine, type RawLine, type SaleDocument, type SaleDraft,
} from "./model";
import { salesSkuRepository } from "./session";
import type { ReferenceName } from "@stage05/contracts/reference";

type Entity = {id: string; name: string; hall_id?: string | null};
type SourceHall = Entity & {default_customer_id?: string | null; source_payload?: Record<string, unknown> | null};
type References = {halls: ConfiguredStore[]; warehouses: Entity[]; customers: Entity[]; employees: Entity[]; methods: PaymentOption[]; accounts: PaymentOption[]; recommendedCustomers: Map<string, string>; categories: Map<string, string>};
const EMPTY: References = {halls: [], warehouses: [], customers: [], employees: [], methods: [], accounts: [], recommendedCustomers: new Map(), categories: new Map()};
function currentDateTime(): string {
  const now = new Date();
  const part = (value: number) => String(value).padStart(2, "0");
  return `${now.getFullYear()}-${part(now.getMonth() + 1)}-${part(now.getDate())}T${part(now.getHours())}:${part(now.getMinutes())}`;
}
function storedHallKey(): string {
  try { const operator = JSON.parse(sessionStorage.getItem("stage05:operator") || "{}"); return `lr-sales-last-hall:${operator.id || "local"}`; }
  catch { return "lr-sales-last-hall:local"; }
}
async function allReference<T>(name: ReferenceName): Promise<T[]> {
  const first = await api.listReference<T>(name, {page: 1, pageSize: 200});
  const items = [...first.items];
  for (let page = 2; items.length < first.total; page++) items.push(...(await api.listReference<T>(name, {page, pageSize: 200})).items);
  return items;
}
function saleCategoryTotals(lines: SaleDraft["lines"], categories: Map<string, string>): Array<[string, string]> {
  const groups = new Map<string, SaleDraft["lines"]>();
  for (const line of lines) {
    if (line.gift) continue;
    const name = categories.get(text(line.source_product_code)) || text(line.source_category_name) || "分类来源未提供";
    groups.set(name, [...(groups.get(name) || []), line]);
  }
  return [...groups].map(([name, items]) => [name, quantityTotal(items)]);
}
function findCell(lookup: SkuLookup, sku: DisplaySku) {
  return lookup.matrixForProduct(sku.product.productId).sections.flatMap(section => section.rows).flatMap(row => row.cells).flatMap(cell => cell.entries).find(entry => entry.skuId === sku.identity.skuId);
}
function sourceName(header: Record<string, unknown>, name: string): string {
  const source = (header.source_payload as Record<string, unknown> | undefined)?.source as Record<string, unknown> | undefined;
  return text(source?.[name]);
}
function validateDraft(draft: SaleDraft, refs: References, hallChecked: boolean): string | null {
  const header = draft.header;
  if (!headerValue(header, "business_date")) return "请填写业务日期";
  if (!headerValue(header, "hall_id")) return "请选择营业厅";
  if (!headerValue(header, "source_warehouse_id")) return "请选择出库仓库";
  if (!headerValue(header, "source_employee_id")) return "请选择营业员";
  if (!headerValue(header, "source_party_id")) return "请选择客户";
  if (!draft.lines.length) return "请至少录入一个商品规格";
  const hall = refs.halls.find(item => item.id === headerValue(header, "hall_id"));
  if (hall && !hall.warehouseIds.includes(headerValue(header, "source_warehouse_id"))) return "所选仓库不属于当前营业厅，请手动重新选择";
  const employeeId = headerValue(header, "source_employee_id");
  const employee = refs.employees.find(item => item.id === employeeId);
  if (hall && employee?.hall_id && employee.hall_id !== hall.id) return "所选营业员不属于当前营业厅，请手动重新选择";
  if (!hallChecked) return "营业厅已变化，请核对仓库、客户和营业员后确认";
  if (draft.kind !== saleKind(draft.lines)) return `当前明细属于${saleKind(draft.lines)}，请调整业务类型或数量符号`;
  for (const [index, line] of draft.lines.entries()) {
    if (!line.sku_id || !line.product_id || !line.color_id || !line.size_id) return `第 ${index + 1} 行缺少真实 SKU 引用`;
    if (!text(line.source_quantity) || !text(line.unit_price)) return `第 ${index + 1} 行数量或单价未填写`;
  }
  return null;
}
export function SalesEditorPage({id}: {id?: string}) {
  const [initialDraft] = useState<SaleDraft>(() => newDraft(currentDateTime()));
  const [draft, setDraft] = useState<SaleDraft>(initialDraft);
  const [saved, setSaved] = useState<SaleDocument | null>(null), [savedSnapshot, setSavedSnapshot] = useState(() => JSON.stringify(initialDraft));
  const [loading, setLoading] = useState(Boolean(id)), [fatal, setFatal] = useState("");
  const [refs, setRefs] = useState<References>(EMPTY), [lookup, setLookup] = useState<SkuLookup | null>(null);
  const [finderRefs, setFinderRefs] = useState<InventoryReferences | null>(null);
  const [referenceError, setReferenceError] = useState("");
  const [hallChecked, setHallChecked] = useState(true);
  const [paymentOpen, setPaymentOpen] = useState(false), [batchOpen, setBatchOpen] = useState(false), [scanOpen, setScanOpen] = useState(false), [printOpen, setPrintOpen] = useState(false);
  const [confirmLeave, setConfirmLeave] = useState(false);
  const [leaveTarget, setLeaveTarget] = useState<string | null>(null);
  const [confirmType, setConfirmType] = useState<SaleDraft["kind"] | null>(null);
  const [error, setError] = useState(""), [pending, setPending] = useState(false);
  const [inlinePending, setInlinePending] = useState<Record<string, InlinePendingPresentation>>({});
  const [uncertain, setUncertain] = useState<{command: DocumentCommand; snapshot: string} | null>(null);
  const [noteOpen, setNoteOpen] = useState(false);
  const running = useRef(false), paymentTrigger = useRef<HTMLButtonElement>(null), batchTrigger = useRef<HTMLButtonElement>(null), scanTrigger = useRef<HTMLButtonElement>(null), command = useMemo(() => new DocumentCommandController(api), []);
  const dirtyRef = useRef(false), allowNavigate = useRef(false), currentPath = useRef(window.location.pathname + window.location.search);
  function closePayment() {setPaymentOpen(false); requestAnimationFrame(() => paymentTrigger.current?.focus());}
  function closeBatch() {setBatchOpen(false); requestAnimationFrame(() => batchTrigger.current?.focus());}
  function closeScan() {setScanOpen(false); requestAnimationFrame(() => scanTrigger.current?.focus());}
  const commandFailure = () => {const snapshot = command.getSnapshot(); return snapshot.state === "failure" ? snapshot.reason : "命令未确认";};
  useEffect(() => {
    let alive = true;
    void Promise.all([
      api.getHallConfiguration(), allReference<Entity>("warehouses"),
      allReference<Entity>("customers"), allReference<Entity>("employees"), allReference<SourceHall>("halls"),
      allReference<PaymentOption>("payment-methods"), allReference<PaymentOption>("fund-accounts"),
      api.getRuntimeCatalog<{products: Array<{code: string; category_name?: string | null}>}>(),
    ]).then(([halls, warehouses, customers, employees, sourceHalls, methods, accounts, catalog]) => {
      if (!alive) return;
      const recommendedCustomers = new Map<string, string>();
      for (const hall of halls.stores) {
        const ids = [...new Set(sourceHalls.filter(source => hall.sourceIds.includes(source.id)).map(source => text(source.default_customer_id || source.source_payload?.defaultCustomerId)).filter(Boolean))];
        if (ids.length === 1 && customers.some(customer => customer.id === ids[0])) recommendedCustomers.set(hall.id, ids[0]!);
      }
      setRefs({halls: halls.stores, warehouses, customers, employees, methods, accounts, recommendedCustomers, categories: new Map(catalog.products.map(product => [product.code, product.category_name || ""]))});
      if (!id) {
        const storedId = localStorage.getItem(storedHallKey());
        const selected = halls.stores.find(hall => hall.id === storedId) || (halls.stores.length === 1 ? halls.stores[0] : undefined);
        if (selected) {
          const warehouse = warehouses.find(item => item.id === selected.defaultWarehouseId && selected.warehouseIds.includes(item.id));
          const defaults = {hall_id: selected.id, hall_name: selected.name, ...(warehouse ? {source_warehouse_id: warehouse.id, warehouse_name: warehouse.name} : {})};
          setSavedSnapshot(JSON.stringify({...initialDraft, header: {...initialDraft.header, ...defaults}}));
          setDraft(current => headerValue(current.header, "hall_id") ? current : {...current, header: {...current.header, ...defaults}});
        }
      }
    }).catch(issue => {if (alive) setReferenceError(issue instanceof Error ? issue.message : "基础资料读取失败");});
    void salesSkuRepository().load().then(value => {if (alive) setLookup(value);}).catch(issue => {if (alive) setReferenceError(issue instanceof Error ? issue.message : "SKU目录读取失败");});
    const finderAbort = new AbortController();
    void inventoryReferences(finderAbort.signal).then(value => {if (alive) setFinderRefs(value);}).catch(issue => {if (alive && !finderAbort.signal.aborted) setReferenceError(issue instanceof Error ? issue.message : "商品联想读取失败");});
    if (id) void api.getDocument(id).then(value => {
      if (!alive) return;
      const document = asSale(value);
      if (document.status === "APPROVED") {setFatal("已审核单不能直接编辑。请先在详情页弃审。"); setLoading(false); return;}
      const next = draftFrom(document); setSaved(document); setDraft(next); setSavedSnapshot(JSON.stringify(next)); setLoading(false);
    }).catch(issue => {if (alive) {setFatal(issue instanceof ApiError && issue.kind === "not-found" ? "销货单不存在" : issue instanceof Error ? issue.message : "读取销货单失败"); setLoading(false);}});
    return () => {alive = false; finderAbort.abort();};
  }, [id]);
  const body = commandBody(draft);
  const pendingFacts = Object.values(inlinePending), pendingProducts = pendingFacts.flatMap(item => item.products);
  const pendingLines = pendingProducts.filter(item => /^[-+]?\d+$/.test(item.quantity) && Number(item.quantity) !== 0).map((item, index) => ({
    source_id: `__pending__:${index}`, sku_id: "", product_id: "", warehouse_id: "", source_product_code: item.code, source_category_name: refs.categories.get(item.code),
    source_quantity: item.quantity, amount: item.amount || "0", unit_price: item.amount ? "0" : "", gift: false,
  } as RawLine));
  const displayLines = [...body.lines, ...pendingLines], displayBody = {...body, lines: displayLines};
  const pendingIncomplete = pendingProducts.filter(item => !item.completeSpecs).length;
  const pendingUnpriced = pendingProducts.filter(item => !item.priced).length;
  const dirty = JSON.stringify(draft) !== savedSnapshot || pendingFacts.some(item => item.hasInput);
  dirtyRef.current = dirty;
  useEffect(() => {
    const beforeRoute = (event: Event) => {
      const target = (event as CustomEvent<{target: string}>).detail.target;
      if (!dirtyRef.current || allowNavigate.current || target === currentPath.current) return;
      event.preventDefault(); setLeaveTarget(target); setConfirmLeave(true);
    };
    const beforeBack = () => {
      if (!dirtyRef.current || allowNavigate.current) return;
      const target = window.location.pathname + window.location.search;
      if (target === currentPath.current) return;
      window.history.pushState({}, "", currentPath.current);
      setLeaveTarget(target); setConfirmLeave(true);
    };
    const beforeUnload = (event: BeforeUnloadEvent) => {if (dirtyRef.current) {event.preventDefault(); event.returnValue = "";}};
    window.addEventListener("stage05:before-route", beforeRoute);
    window.addEventListener("popstate", beforeBack, true);
    window.addEventListener("beforeunload", beforeUnload);
    return () => {window.removeEventListener("stage05:before-route", beforeRoute); window.removeEventListener("popstate", beforeBack, true); window.removeEventListener("beforeunload", beforeUnload);};
  }, []);
  const settlementGap = difference(displayBody);
  useEffect(() => {setNoteOpen(Boolean(headerValue(draft.header, "note")));}, [saved?.id]);
  const hall = refs.halls.find(item => item.id === headerValue(draft.header, "hall_id"));
  const warehouseId = headerValue(draft.header, "source_warehouse_id");
  const warehouseInvalid = Boolean(hall && warehouseId && !hall.warehouseIds.includes(warehouseId));
  const employee = refs.employees.find(item => item.id === headerValue(draft.header, "source_employee_id"));
  const employeeInvalid = Boolean(hall && employee?.hall_id && employee.hall_id !== hall.id);
  function setHeader(patch: Record<string, unknown>) { setDraft(current => ({...current, header: {...current.header, ...patch}})); }
  function appendPending(pendingLines: PendingSku[]): boolean {
    if (!warehouseId) {setError("请先选择出库仓库"); return false;}
    try {
      const lines = draft.lines.map(line => ({...line}));
      for (const pendingLine of pendingLines) {
        const next = makeLine(pendingLine.reference, pendingLine.sku, warehouseId, pendingLine.quantity, pendingLine.unitPrice, pendingLine.productName);
        const matchIndex = lines.findIndex(line => line.sku_id === next.sku_id && line.warehouse_id === next.warehouse_id && text(line.unit_price) === text(next.unit_price) && Math.sign(Number(line.source_quantity)) === Math.sign(Number(next.source_quantity)));
        if (matchIndex >= 0) {
          const old = lines[matchIndex]!;
          lines[matchIndex] = updateLine(old, {source_quantity: formatSignedQuantity(parseSignedQuantity(old.source_quantity) + parseSignedQuantity(next.source_quantity))});
        } else lines.push(next);
      }
      setDraft({...draft, lines, kind: lines.length ? saleKind(lines) : draft.kind});
      setError(""); if (batchOpen) closeBatch();
      return true;
    } catch (issue) {setError(issue instanceof Error ? issue.message : "规格录入失败"); return false;}
  }
  function addInline(sku: DisplaySku, quantity: string, unitPrice: string, productName: string): boolean {
    if (!lookup) {setError("SKU目录仍在加载"); return false;}
    const cell = findCell(lookup, sku);
    if (!cell) {setError("SKU 未在已验证矩阵中，不能录入"); return false;}
    return appendPending([{reference: lookup.inputReference(cell), sku, quantity, unitPrice, ...(productName ? {productName} : {})}]);
  }
  function applyBusinessType(kind: SaleDraft["kind"]) {
    try {
      setDraft(current => {
        const lines = current.lines.map(line => updateLine(line, {source_quantity: `${kind === "退货" ? "-" : ""}${Math.abs(Number(line.source_quantity))}`}));
        return {...current, kind, lines};
      });
      setConfirmType(null);
    } catch (issue) {setError(issue instanceof Error ? issue.message : "切换业务类型失败");}
  }
  function changeBusinessType(value: string) {
    const kind: SaleDraft["kind"] = value === "销售" ? "销售" : "退货";
    if ((draft.kind === "销售") === (kind === "销售")) return;
    if (draft.lines.length) setConfirmType(kind);
    else applyBusinessType(kind);
  }
  function leave() {navigate(saved ? `/sales/${encodeURIComponent(saved.id)}` : "/sales");}
  async function saveOrApprove(approve: boolean) {
    if (running.current) return;
    if (uncertain) {setError("上一笔命令结果尚未确认，请先核对服务端结果；不会生成新 requestKey。"); return;}
    if (pendingFacts.some(item => item.hasInput)) {setError("请完成本区正在录入的商品和价格"); return;}
    const issue = validateDraft(draft, refs, hallChecked);
    if (issue) {setError(issue); return;}
    running.current = true; setPending(true); setError("");
    try {
      let document = saved;
      if (!document) {
        const documentId = crypto.randomUUID();
        const attempt: DocumentCommand = {documentId, documentType: "SALE", operation: "create", expectedVersion: 0, requestKey: newRequestKey(), body};
        const created = await command.submit(attempt);
        const createState = command.getSnapshot();
        if (!created && createState.state === "failure" && createState.kind === "network-uncertain") setUncertain({command: attempt, snapshot: JSON.stringify(draft)});
        if (!created) throw Error(commandFailure());
        document = asSale(await api.getDocument(documentId));
        setSaved(document); setSavedSnapshot(JSON.stringify(draft));
      } else if (dirty) {
        const attempt: DocumentCommand = {documentId: document.id, operation: "save", expectedVersion: document.version, requestKey: newRequestKey(), body};
        const result = await command.submit(attempt);
        const saveState = command.getSnapshot();
        if (!result && saveState.state === "failure" && saveState.kind === "network-uncertain") setUncertain({command: attempt, snapshot: JSON.stringify(draft)});
        if (!result) throw Error(commandFailure());
        document = asSale(await api.getDocument(document.id));
        setSaved(document); setSavedSnapshot(JSON.stringify(draft));
      }
      if (approve) {
        const attempt: DocumentCommand = {documentId: document.id, operation: "approve", expectedVersion: document.version, requestKey: newRequestKey()};
        const approved = await command.submit(attempt);
        const approveState = command.getSnapshot();
        if (!approved && approveState.state === "failure" && approveState.kind === "network-uncertain") setUncertain({command: attempt, snapshot: JSON.stringify(draft)});
        if (!approved) throw Error(commandFailure());
        document = asSale(await api.getDocument(document.id));
      }
      feedback.success(approve ? "保存并审核成功" : document.status === "DRAFT" ? "草稿已保存" : "未审核单据已保存");
      allowNavigate.current = true;
      navigate(`/sales/${encodeURIComponent(document.id)}`);
    } catch (failure) {setError(failure instanceof Error ? failure.message : "命令未确认；草稿已保留");}
    finally {running.current = false; setPending(false);}
  }
  async function reconcileUncertain() {
    if (!uncertain || running.current) return;
    running.current = true; setPending(true);
    try {
      let current: SaleDocument | null = null;
      try {current = asSale(await command.readCurrentDocument(uncertain.command.documentId));}
      catch (issue) {if (!(issue instanceof ApiError && issue.kind === "not-found" && uncertain.command.operation === "create")) throw issue;}
      if (!current || current.version === uncertain.command.expectedVersion) {
        const result = await command.submit(uncertain.command);
        if (!result) throw Error(commandFailure());
        current = asSale(await command.readCurrentDocument(uncertain.command.documentId));
      }
      const matched = (current.history as Array<{request_key?: string}>).some(entry => entry.request_key === uncertain.command.requestKey);
      if (!matched) throw Error("服务端版本已由其它命令改变；原操作未确认。草稿已保留，请核对版本后处理。");
      setSaved(current); setSavedSnapshot(uncertain.snapshot); setUncertain(null); setError("");
      feedback.success("已核对原命令及服务端版本");
      allowNavigate.current = true;
      navigate(`/sales/${encodeURIComponent(current.id)}`);
    } catch (issue) {setError(issue instanceof Error ? issue.message : "结果仍未确认，草稿已保留");}
    finally {running.current = false; setPending(false);}
  }
  if (loading) return <LoadingState text="正在读取销货单草稿" />;
  if (fatal.startsWith("已审核单不能直接编辑")) return <PageContainer title="编辑受限" actions={<Button onClick={() => navigate(`/sales/${encodeURIComponent(id!)}`)}>返回详情</Button>}><Alert type="warning" showIcon title="请先弃审" content={fatal} /></PageContainer>;
  if (fatal) return <ErrorState message={fatal} onRetry={() => id ? navigate(`/sales/${encodeURIComponent(id)}`) : window.location.reload()} />;
  return <>
    <section className="lr-sale-workbench lr-sale-editor">
      <div className="lr-sale-head"><div className="lr-sale-title"><h1>{saved ? "销货单" : "新增销货单"}</h1><SaleStatusTag status={saved?.status || "DRAFT"} /><span className="lr-sale-muted">{dirty ? "有未保存修改" : saved ? "已保存" : ""}</span></div><div className="lr-sale-head-actions">
        <Button onClick={leave}>返回列表</Button>
        {saved && <Button onClick={() => navigate(`/sales/${encodeURIComponent(saved.id)}`)}>取消修改</Button>}
        <Button type="primary" loading={pending} onClick={() => void saveOrApprove(false)}>{saved ? "保存修改" : "保存销货单"}</Button>
        <Button loading={pending} onClick={() => void saveOrApprove(true)}>审核</Button>
        {saved && <Dropdown trigger="click" position="br" droplist={<Menu><Menu.Item key="print" onClick={() => setPrintOpen(true)}>打印已保存版本</Menu.Item></Menu>}><Button>更多操作</Button></Dropdown>}
      </div></div>
      {referenceError && <Alert type="error" showIcon content={referenceError} />}
      {error && <Alert type="error" showIcon title={error.includes("VERSION_CONFLICT") ? "版本冲突，草稿已保留" : "请检查当前草稿"} content={error} />}
      {uncertain && <Alert type="warning" showIcon title="命令结果未确认" content={<Space wrap>原 requestKey 和草稿已保留。<Button size="small" loading={pending} onClick={() => void reconcileUncertain()}>核对并重试原命令</Button></Space>} />}
      <div className="lr-sale-doc-header">
        <label>业务类型 <span className="lr-sale-required">*</span><Select aria-label="业务类型" value={draft.kind === "销售" ? "销售" : "退货/换货"} options={[{label: "销售", value: "销售"}, {label: "退货/换货", value: "退货/换货"}]} onChange={value => changeBusinessType(String(value))} /></label>
        <label>营业厅 <span className="lr-sale-required">*</span><EntityPicker label="营业厅" items={refs.halls.map(item => ({id: item.id, name: item.name}))} value={headerValue(draft.header, "hall_id")} onChange={value => {const nextId = String(value); const selected = refs.halls.find(item => item.id === nextId); const previousId = headerValue(draft.header, "hall_id"); const changed = Boolean(previousId && previousId !== nextId); const warehouse = !previousId && refs.warehouses.find(item => item.id === selected?.defaultWarehouseId && selected?.warehouseIds.includes(item.id)); setHeader({hall_id: nextId, hall_name: selected?.name || "", ...(warehouse ? {source_warehouse_id: warehouse.id, warehouse_name: warehouse.name} : {})}); if (selected) localStorage.setItem(storedHallKey(), selected.id); if (changed) setHallChecked(false);}} /></label>
        <label>出库仓 <span className="lr-sale-required">*</span><EntityPicker label="出库仓" items={refs.warehouses.map(item => ({id: item.id, name: item.name}))} value={warehouseId} onChange={value => {const id = String(value); setHeader({source_warehouse_id: id, warehouse_name: refs.warehouses.find(item => item.id === id)?.name || ""});}} /></label>
        <label>营业员 <span className="lr-sale-required">*</span><EntityPicker label="营业员" items={refs.employees.map(item => ({id: item.id, name: item.name}))} value={headerValue(draft.header, "source_employee_id")} onChange={value => {const id = String(value); setHeader({source_employee_id: id || null, employee_name: refs.employees.find(item => item.id === id)?.name || ""});}} /></label>
        <label>客户 <span className="lr-sale-required">*</span><EntityPicker label="客户" items={refs.customers.map(item => ({id: item.id, name: item.name}))} value={headerValue(draft.header, "source_party_id")} onChange={value => {const id = String(value); setHeader({source_party_id: id, customer_name: refs.customers.find(item => item.id === id)?.name || ""});}} />{!headerValue(draft.header, "source_party_id") && refs.recommendedCustomers.has(headerValue(draft.header, "hall_id")) && <Button className="lr-sale-recommend" type="text" onClick={() => {const id = refs.recommendedCustomers.get(headerValue(draft.header, "hall_id"))!; setHeader({source_party_id: id, customer_name: refs.customers.find(item => item.id === id)?.name || ""});}}>推荐：{refs.customers.find(item => item.id === refs.recommendedCustomers.get(headerValue(draft.header, "hall_id")))?.name}</Button>}</label>
        <label>单据日期<DatePicker aria-label="单据日期" showTime={{format: "HH:mm"}} format="YYYY-MM-DD HH:mm" value={headerValue(draft.header, "business_date").slice(0, 16).replace("T", " ")} onChange={value => setHeader({business_date: value.replace(" ", "T")})} />{saved?.baseline_was_included && <small>历史日期来源未提供时分</small>}</label>
        <label className="lr-sale-discount-field">整单优惠 / 抹零<InputNumber aria-label="整单优惠 / 抹零" value={Math.abs(Number(headerValue(draft.header, "adjustment") || 0))} min={0} precision={2} hideControl onChange={value => setHeader({adjustment: String(value ?? 0)})} /><small>按优惠扣减，正负输入均减少应收</small></label>
        <label>收退款账户<Button ref={paymentTrigger} className="lr-sale-funds-button" onClick={() => setPaymentOpen(true)}>{draft.fundsRecords.length ? `${draft.fundsRecords.length} 笔支付明细` : "请选择"}</Button></label>
        <label>结算合计<span className="lr-sale-read-value">{fundsAmount(draft.fundsRecords).kind === "known" ? moneyToDecimal(fundsAmount(draft.fundsRecords)) : "未知"}</span><small className="lr-sale-funds-hint">应结 <AmountDisplay value={dueAmount(displayBody)} />{settlementGap.kind === "known" && settlementGap.minorUnits !== "0" ? " · 金额不一致，无法审核" : ""}</small></label>
        <div className="lr-sale-meta"><span>单号：{saved?.number || "未生成"}</span><span>{saved ? "制单人" : "录单人"}：{saved?.baseline_was_included ? "历史未提供" : "管理员"}</span></div>
      </div>
      {saved?.baseline_was_included && !headerValue(draft.header, "hall_id") && <Alert type="info" showIcon content="历史单未提供已确认的营业厅关系。请选择营业厅并核对仓库、客户和营业员。" />}
      {!hallChecked && <Alert type="warning" showIcon title="营业厅已变化" content={<Space wrap>请核对仓库、客户与营业员。原选择未被自动更换。<Button size="small" onClick={() => setHallChecked(true)}>已核对，保留当前选择</Button></Space>} />}
      {warehouseInvalid && <Alert type="error" showIcon content="原仓库不属于当前营业厅；请手动改选仓库。" />}
      {employeeInvalid && <Alert type="error" showIcon content="原营业员不属于当前营业厅；请手动改选营业员。" />}
      {draft.kind === "换货" ? <>
        <div className="lr-sale-entry-section"><div className="lr-sale-section-head"><h2>退回商品</h2><div><Button ref={batchTrigger} type="text" onClick={() => setBatchOpen(true)} disabled={!lookup}>批量录入</Button><Button ref={scanTrigger} type="text" onClick={() => setScanOpen(true)} disabled={!lookup}>扫码录入（0）</Button></div></div><SalesInlineTable draft={draft} lookup={lookup} finderRefs={finderRefs} section="in" onDraft={setDraft} onAdd={addInline} onError={setError} onPendingChange={value => setInlinePending(current => JSON.stringify(current.in) === JSON.stringify(value) ? current : {...current, in: value})} /></div>
        <div className="lr-sale-entry-section"><div className="lr-sale-section-head"><h2>换出商品</h2><div><Button type="text" onClick={() => setBatchOpen(true)} disabled={!lookup}>批量录入</Button><Button type="text" onClick={() => setScanOpen(true)} disabled={!lookup}>扫码录入（0）</Button></div></div><SalesInlineTable draft={draft} lookup={lookup} finderRefs={finderRefs} section="out" onDraft={setDraft} onAdd={addInline} onError={setError} onPendingChange={value => setInlinePending(current => JSON.stringify(current.out) === JSON.stringify(value) ? current : {...current, out: value})} /></div>
      </> : <div className="lr-sale-entry-section"><div className="lr-sale-section-head"><h2>{draft.kind === "退货" ? "退回商品" : "商品明细"}</h2><div><Button ref={batchTrigger} type="text" onClick={() => setBatchOpen(true)} disabled={!lookup}>批量录入</Button><Button ref={scanTrigger} type="text" onClick={() => setScanOpen(true)} disabled={!lookup}>扫码录入（0）</Button></div></div><SalesInlineTable draft={draft} lookup={lookup} finderRefs={finderRefs} {...(draft.kind === "退货" ? {section: "in" as const} : {})} onDraft={setDraft} onAdd={addInline} onError={setError} onPendingChange={value => setInlinePending(current => JSON.stringify(current.main) === JSON.stringify(value) ? current : {...current, main: value})} /></div>}
      <Collapse className="lr-sale-note" bordered={false} activeKey={noteOpen ? ["note"] : []} onChange={(_key, keys) => setNoteOpen(keys.includes("note"))}><Collapse.Item name="note" header="整单备注（可选）"><Input aria-label="整单备注" value={headerValue(draft.header, "note")} onChange={note => setHeader({note})} /></Collapse.Item></Collapse>
      <footer className="lr-sale-summary"><div className="lr-sale-core-metrics">{draft.kind !== "销售" && <div className="lr-sale-core-metric"><span>退回</span><strong>{quantityTotal(displayLines.filter(line => Number(line.source_quantity) < 0)).replace(/^-/, "")}</strong></div>}{draft.kind === "换货" && <div className="lr-sale-core-metric"><span>换出</span><strong>{quantityTotal(displayLines.filter(line => Number(line.source_quantity) > 0))}</strong></div>}{draft.kind === "销售" && <div className="lr-sale-core-metric"><span>销售数量</span><strong>{quantityTotal(displayLines)}</strong></div>}<div className="lr-sale-core-metric"><span>{draft.kind === "销售" && (pendingIncomplete || pendingUnpriced) ? "已填写销售金额（未完成）" : draft.kind === "销售" ? "销售金额" : "应结金额"}</span><strong><AmountDisplay value={dueAmount(displayBody)} /></strong></div></div>{draft.kind === "销售" && <div className="lr-sale-category-summary" aria-label="销售分类汇总">{saleCategoryTotals(displayLines, refs.categories).length ? saleCategoryTotals(displayLines, refs.categories).map(([name, total], index) => <span key={name}>{index > 0 && <i aria-hidden="true"> · </i>}{name} {total}</span>) : <span>暂无销售商品</span>}</div>}<div className="lr-sale-summary-secondary"><span>{new Set([...draft.lines.map(line => text(line.source_product_code)), ...pendingProducts.map(item => item.code)]).size} 款 · {draft.lines.length + pendingProducts.length} 条明细</span><span>商品金额 <AmountDisplay value={lineTotal(displayLines)} /></span><span>整单调整 {Number(headerValue(draft.header, "adjustment") || 0).toFixed(2)}</span>{pendingUnpriced > 0 && <span>{pendingUnpriced}条待定价</span>}{pendingIncomplete > 0 && <span>{pendingIncomplete}条待选颜色尺码</span>}</div></footer>
      <div className="lr-sale-bottom-note">保存未审核单据不动库存；审核后库存生效，结算明细保留。录错请联系仓库人员弃审。</div>
    </section>
    <PaymentEditor visible={paymentOpen} funds={draft.fundsRecords} due={dueAmount(displayBody)} accounts={refs.accounts} methods={refs.methods} onCancel={closePayment} onConfirm={fundsRecords => {setDraft(current => ({...current, fundsRecords})); closePayment();}} />
    <BatchEntry visible={batchOpen} lookup={lookup} existing={draft.lines} onCancel={closeBatch} onAppend={appendPending} />
    <ScanPanel visible={scanOpen} lookup={lookup} initialQuantity={draft.kind === "退货" ? "-1" : "1"} onCancel={closeScan} onAppend={appendPending} />
    <Modal title="有未保存的修改" visible={confirmLeave} onCancel={() => {setConfirmLeave(false); setLeaveTarget(null);}} onOk={() => {const target = leaveTarget || (saved ? `/sales/${encodeURIComponent(saved.id)}` : "/sales"); setConfirmLeave(false); setLeaveTarget(null); allowNavigate.current = true; navigate(target);}} okText="放弃修改并离开" cancelText="继续录单" maskClosable={false}>此单尚有未保存的输入。离开后本次修改不会产生库存变动。</Modal>
    <Modal title="切换业务类型" visible={Boolean(confirmType)} onCancel={() => setConfirmType(null)} onOk={() => {if (confirmType) applyBusinessType(confirmType);}} okText="确认切换" maskClosable={false}>本单数量将统一改为所选类型的默认方向，请核对商品明细。</Modal>
    <Modal title={`已保存单据打印预览 · ${saved?.number || ""}`} visible={printOpen} style={{width: "min(1000px, calc(100vw - 32px))"}} onCancel={() => setPrintOpen(false)} onOk={() => window.print()} okText="浏览器打印">{dirty && <Alert type="warning" showIcon content="当前编辑有未保存内容，此预览只打印已保存版本。" />}{saved && <SaleFacts document={saved} lookup={lookup || undefined} print />}</Modal>
  </>;
}
