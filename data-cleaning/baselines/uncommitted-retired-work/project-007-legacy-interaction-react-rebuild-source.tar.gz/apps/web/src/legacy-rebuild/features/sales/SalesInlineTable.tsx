import { useEffect, useRef, useState } from "react";
import { Button, Dropdown, InputNumber, Menu, Select, Table } from "@arco-design/web-react";
import { api, moneyToDecimal, type DisplaySku, type ProductRecord, type SkuLookup } from "@stage05";
import { InventoryFinder } from "../inventory/InventoryFinder";
import type { InventoryReferences } from "../inventory/data";
import { legacySkuOrder } from "../inventory/legacySkuOrder";
import { LegacyActionIcon } from "./LegacyActionIcon";
import { calculatedLineAmount, cents, decimal, lineTotal, saleKind, text, updateLine, type RawLine, type SaleDraft } from "./model";

interface Entry {
  id: string;
  query: string;
  product: ProductRecord | null;
  colorId: string;
  skuId: string;
  quantity: string;
  price: string;
}
export interface InlinePendingPresentation {
  hasInput: boolean;
  products: Array<{code: string; quantity: string; amount: string | null; completeSpecs: boolean; priced: boolean}>;
}
const blank = (): Entry => ({id: crypto.randomUUID(), query: "", product: null, colorId: "", skuId: "", quantity: "", price: ""});
const rowId = (id: string) => `__entry__:${id}`;

export function SalesInlineTable({draft, lookup, finderRefs, section, onDraft, onAdd, onError, onPendingChange}: {
  draft: SaleDraft;
  lookup: SkuLookup | null;
  finderRefs: InventoryReferences | null;
  section?: "in" | "out";
  onDraft: (change: (draft: SaleDraft) => SaleDraft) => void;
  onAdd: (sku: DisplaySku, quantity: string, price: string, name: string) => boolean;
  onError: (message: string) => void;
  onPendingChange: (pending: InlinePendingPresentation) => void;
}) {
  const [entries, setEntries] = useState<Entry[]>(() => [blank()]);
  const serial = useRef(new Map<string, number>());
  const onPendingRef = useRef(onPendingChange);
  onPendingRef.current = onPendingChange;
  const pending: InlinePendingPresentation = {
    hasInput: entries.some(entry => Boolean(entry.query.trim() || entry.product)),
    products: entries.filter(entry => entry.product).map(entry => {
      let calculated: string | null = null;
      if (/^[-+]?\d+$/.test(entry.quantity) && Number(entry.quantity) !== 0 && cents(entry.price) !== null) {
        try {calculated = calculatedLineAmount(entry.quantity, entry.price);} catch { /* A partial price remains unpriced. */ }
      }
      return {code: entry.product!.code, quantity: entry.quantity, amount: calculated, completeSpecs: Boolean(entry.colorId && entry.skuId), priced: cents(entry.price) !== null};
    }),
  };
  const pendingSignature = JSON.stringify(pending);
  useEffect(() => {onPendingRef.current(JSON.parse(pendingSignature) as InlinePendingPresentation);}, [pendingSignature]);
  useEffect(() => () => onPendingRef.current({hasInput: false, products: []}), []);

  function updateEntry(id: string, change: (entry: Entry) => Entry) {
    setEntries(current => current.map(entry => entry.id === id ? change(entry) : entry));
  }
  function entryFor(row: RawLine) { return row.source_id.startsWith("__entry__:") ? entries.find(entry => row.source_id === rowId(entry.id)) : undefined; }
  function skusFor(entry: Entry) {
    const identity = entry.product && lookup?.productByCode(entry.product.code);
    return identity ? legacySkuOrder(lookup!.skusForProduct(identity.productId).filter(sku => sku.sourceEnabled)) : [];
  }
  function changeQuery(id: string, query: string) {
    serial.current.set(id, (serial.current.get(id) || 0) + 1);
    updateEntry(id, entry => ({...entry, query, product: null, colorId: "", skuId: "", quantity: "", price: ""}));
  }
  async function pick(id: string, code: string, matchedSku: string | null) {
    const token = (serial.current.get(id) || 0) + 1;
    serial.current.set(id, token);
    updateEntry(id, entry => ({...entry, query: code, product: null, colorId: "", skuId: "", quantity: "", price: ""}));
    try {
      const product = await api.getProduct(code);
      if (serial.current.get(id) !== token) return;
      if (!lookup?.productByCode(product.code)) throw Error("商品未进入正式 SKU 目录");
      const sku = matchedSku ? lookup.skuById(matchedSku) : null;
      setEntries(current => {
        const next = current.map(entry => entry.id === id ? {
          ...entry, product, price: text(product.attributes?.price) || "", quantity: "",
          colorId: sku?.product.sourceCode === code ? sku.color.colorId : "",
          skuId: sku?.product.sourceCode === code ? sku.identity.skuId : "",
        } : entry);
        if (!next.some(entry => !entry.query && !entry.product)) next.push(blank());
        return next;
      });
      onError("");
      requestAnimationFrame(() => document.querySelector<HTMLElement>(`[data-sale-entry="${id}"] [aria-label="录入颜色"]`)?.focus());
    } catch (issue) { onError(issue instanceof Error ? issue.message : "读取商品失败"); }
  }
  function submitQuery(id: string) {
    const value = entries.find(entry => entry.id === id)?.query.trim();
    if (!value) return;
    const exact = finderRefs?.catalog.products.find(item => item.code.toLocaleLowerCase() === value.toLocaleLowerCase());
    if (exact) void pick(id, exact.code, null);
    else onError("请选择商品候选中的款号，再录入颜色尺码");
  }
  function add(id: string) {
    const entry = entries.find(item => item.id === id);
    if (!entry) return;
    const selectedSku = skusFor(entry).find(sku => sku.identity.skuId === entry.skuId);
    if (!selectedSku) {onError("请选择真实商品、颜色和尺码"); return;}
    const validPrice = cents(entry.price);
    if (!entry.quantity || validPrice === null || validPrice < 0n) {onError("请填写有效数量与成交单价"); return;}
    if (!onAdd(selectedSku, entry.quantity, entry.price, entry.product?.name || "")) return;
    serial.current.delete(id);
    setEntries(current => {
      const next = current.filter(item => item.id !== id);
      return next.some(item => !item.query && !item.product) ? next : [...next, blank()];
    });
    requestAnimationFrame(() => document.querySelector<HTMLElement>('[aria-label="商品搜索"]')?.focus());
  }
  function removeEntry(id: string) {
    serial.current.delete(id);
    setEntries(current => {
      const next = current.filter(entry => entry.id !== id);
      return next.length ? next : [blank()];
    });
  }
  function changeLine(id: string, patch: Partial<Pick<RawLine, "source_quantity" | "unit_price">>) {
    try {
      onDraft(current => {
        const lines = current.lines.map(line => line.source_id === id ? updateLine(line, patch) : line);
        return {...current, lines, kind: lines.length ? saleKind(lines) : current.kind};
      });
      onError("");
    } catch (issue) {onError(issue instanceof Error ? issue.message : "商品明细无效");}
  }
  function toggleGift(id: string) {
    onDraft(current => ({...current, lines: current.lines.map(line => line.source_id === id ? {
      ...line, gift: !line.gift,
      unit_price: line.gift ? text(line.previous_unit_price) || "0" : "0",
      previous_unit_price: line.gift ? null : line.unit_price,
      amount: line.gift ? updateLine(line, {unit_price: text(line.previous_unit_price) || "0"}).amount : "0",
    } : line)}));
  }
  const rows = [...draft.lines.filter(line => section === "in" ? Number(line.source_quantity) < 0 : section === "out" && draft.kind === "换货" ? Number(line.source_quantity) >= 0 : true), ...entries.map(entry => ({source_id: rowId(entry.id)} as RawLine))];
  const columns = [
    {title: "商品名称／款号", key: "product", width: 310, render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      return entry ? <div className="lr-sale-inline-product" data-sale-entry={entry.id}><InventoryFinder value={entry.query} refs={finderRefs} showHistory={false} allowBarcodeFragments={false} onChange={value => changeQuery(entry.id, value)} onSelect={(code, skuId) => void pick(entry.id, code, skuId)} onSubmit={() => submitQuery(entry.id)} />{entry.product && <span title={entry.product.name}>{entry.product.name}</span>}</div> : <div className="lr-sale-product-cell"><strong>{text(row.source_product_code) || "未提供"}</strong><span title={text(row.source_product_name)}>{text(row.source_product_name) || "商品"}</span>{Boolean(row.gift) && <small>赠品</small>}</div>;
    }},
    {title: "颜色", key: "color", render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      if (!entry) return text(row.source_color_name) || lookup?.skuById(row.sku_id)?.color.name || "—";
      const colors = [...new Map(skusFor(entry).map(sku => [sku.color.colorId, sku.color])).values()];
      return <Select aria-label="录入颜色" disabled={!entry.product} value={entry.colorId} placeholder="请选择颜色" options={colors.map(color => ({label: color.name, value: color.colorId}))} onChange={value => {
        updateEntry(entry.id, current => ({...current, colorId: String(value), skuId: ""}));
        requestAnimationFrame(() => document.querySelector<HTMLElement>(`[data-sale-entry="${entry.id}"] [aria-label="录入尺码"]`)?.focus());
      }} />;
    }},
    {title: "尺码", key: "size", render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      if (!entry) return `${lookup?.skuById(row.sku_id)?.column.name || text(row.source_size_name) || "—"}${lookup?.skuById(row.sku_id)?.fit.code ? ` · ${lookup.skuById(row.sku_id)!.fit.code}版` : ""}`;
      const colors = skusFor(entry).filter(sku => sku.color.colorId === entry.colorId);
      return <Select aria-label="录入尺码" disabled={!entry.colorId} value={entry.skuId} placeholder="请选择尺码" options={colors.map(sku => ({label: `${sku.column.name}${colors.filter(candidate => candidate.column.name === sku.column.name).length > 1 ? ` · ${sku.fit.code}版` : ""}`, value: sku.identity.skuId}))} onChange={value => {
        updateEntry(entry.id, current => ({...current, skuId: String(value)}));
        requestAnimationFrame(() => document.querySelector<HTMLElement>(`[data-sale-entry="${entry.id}"] [aria-label="录入数量"]`)?.focus());
      }} />;
    }},
    {title: "数量", key: "quantity", render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      return entry ? <div className="lr-sale-inline-quantity">{draft.kind !== "销售" && <Select aria-label="退回或换出" value={entry.quantity.startsWith("-") ? "return" : "out"} options={[{label: "退回 −", value: "return"}, {label: "换出 ＋", value: "out"}]} onChange={value => updateEntry(entry.id, current => ({...current, quantity: `${value === "return" ? "-" : ""}${Math.abs(Number(current.quantity || 1))}`}))} />}<InputNumber aria-label="录入数量" value={entry.quantity === "" ? undefined : Number(entry.quantity)} disabled={!entry.product} hideControl onChange={value => updateEntry(entry.id, current => ({...current, quantity: String(value ?? "")}))} onKeyDown={event => {if ((event as KeyboardEvent).key === "Enter") document.querySelector<HTMLElement>(`[data-sale-entry="${entry.id}"] [aria-label="录入成交单价"]`)?.focus();}} /></div> : <div className="lr-sale-inline-quantity">{draft.kind !== "销售" && <Select aria-label={`退回或换出 ${row.source_id}`} value={Number(row.source_quantity) < 0 ? "return" : "out"} options={[{label: "退回 −", value: "return"}, {label: "换出 ＋", value: "out"}]} onChange={value => changeLine(row.source_id, {source_quantity: `${value === "return" ? "-" : ""}${Math.abs(Number(row.source_quantity))}`})} />}<InputNumber aria-label={`数量 ${row.source_id}`} value={Number(row.source_quantity)} hideControl onChange={value => changeLine(row.source_id, {source_quantity: String(value ?? 0)})} /></div>;
    }},
    {title: "参考零售价", key: "reference", align: "right" as const, render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      const product = entry?.product || finderRefs?.catalog.products.find(item => item.code === row.source_product_code);
      const raw = product?.attributes?.price, reference = raw == null ? null : cents(text(raw));
      return reference === null ? "—" : decimal(reference);
    }},
    {title: "折扣", key: "discount", render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      const product = entry?.product || finderRefs?.catalog.products.find(item => item.code === row.source_product_code);
      const raw = product?.attributes?.price, reference = raw == null ? null : cents(text(raw)), price = cents(entry ? entry.price : text(row.unit_price));
      return reference && reference > 0n && price !== null ? (Number(price) / Number(reference) * 10).toFixed(4) : "—";
    }},
    {title: "成交单价", key: "price", render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      return entry ? <InputNumber aria-label="录入成交单价" value={entry.price === "" ? undefined : Number(entry.price)} disabled={!entry.product} min={0} precision={2} hideControl placeholder="待填写" onChange={value => updateEntry(entry.id, current => ({...current, price: value == null ? "" : String(value)}))} onKeyDown={event => {if ((event as KeyboardEvent).key === "Enter") add(entry.id);}} /> : <InputNumber aria-label={`单价 ${row.source_id}`} value={Number(row.unit_price)} min={0} precision={2} hideControl disabled={Boolean(row.gift)} onChange={value => changeLine(row.source_id, {unit_price: String(value ?? 0)})} />;
    }},
    {title: "金额", key: "amount", align: "right" as const, render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      if (!entry) return moneyToDecimal(lineTotal([row])) || "—";
      if (!entry.product || !entry.quantity || cents(entry.price) === null) return "—";
      try {const result = cents(calculatedLineAmount(entry.quantity, entry.price)); return result === null ? "—" : decimal(result);}
      catch {return "—";}
    }},
    {title: "操作", key: "action", width: 136, render: (_: unknown, row: RawLine) => {
      const entry = entryFor(row);
      if (entry) return entry.product ? <div className="lr-sale-line-actions"><Button type="text" onClick={() => add(entry.id)}>确认</Button><LegacyActionIcon kind="remove" label="取消待录明细" onClick={() => removeEntry(entry.id)} /></div> : null;
      return <div className="lr-sale-line-actions"><LegacyActionIcon kind="detail" label="查看商品详情" onClick={() => window.open(`/products/${encodeURIComponent(text(row.source_product_code))}`, "_blank", "noopener,noreferrer")} /><LegacyActionIcon kind="remove" label="移除明细" onClick={() => onDraft(current => ({...current, lines: current.lines.filter(line => line.source_id !== row.source_id)}))} /><Dropdown droplist={<Menu onClickMenuItem={key => {if (key === "gift") toggleGift(row.source_id);}}><Menu.Item key="gift">{row.gift ? "取消赠品" : "设为赠品"}</Menu.Item></Menu>} trigger="click"><LegacyActionIcon kind="more" label="更多明细操作" onClick={() => {}} /></Dropdown></div>;
    }},
  ];
  return <div className="lr-sale-lines"><Table className="lr-sale-lines-table" rowKey="source_id" columns={columns} data={rows} pagination={false} tableLayoutFixed={false} size="small" border={{wrapper: false, cell: false}} /></div>;
}
