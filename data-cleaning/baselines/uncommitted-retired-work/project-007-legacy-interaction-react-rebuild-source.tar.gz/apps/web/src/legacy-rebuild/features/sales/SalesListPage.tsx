import { useEffect, useMemo, useRef, useState } from "react";
import { Button, Collapse, DatePicker, Input, Pagination, Select, Table } from "@arco-design/web-react";
import { AmountDisplay, api, moneyToDecimal, navigate, readListReturn, saveListReturn, usePagedQuery, type PageRequest } from "@stage05";
import { readAllReferences, type ReferenceRecord } from "@stage05/features/products/data";
import type { ReferenceName } from "@stage05/contracts/reference";
import { EntityPicker, type EntityOption } from "./EntityPicker";
import { LegacyActionIcon } from "./LegacyActionIcon";
import { SaleStatusTag } from "./SaleStatusTag";
import { asSale, businessDate, dueAmount, headerValue, pageApprovedDue, quantityTotal, saleKind, text, type SaleDocument } from "./model";
import "./style.css";

interface Filter {
  start: string; end: string; number: string; businessType: string; status: string;
  storeId: string[]; salespersonId: string[]; creatorId: string;
  customerId: string[]; warehouseId: string[];
}
interface References {
  halls: EntityOption[]; employees: EntityOption[]; customers: EntityOption[];
  warehouses: EntityOption[]; categories: Map<string, string>;
  hallAliases: Record<string, string>; hallByDepartment: Map<string, string>;
}
type SourceHall = ReferenceRecord & {department_id?: string | null};
const INITIAL: Filter = {start: "", end: "", number: "", businessType: "", status: "", storeId: [], salespersonId: [], creatorId: "", customerId: [], warehouseId: []};
const emptyRefs: References = {halls: [], employees: [], customers: [], warehouses: [], categories: new Map(), hallAliases: {}, hallByDepartment: new Map()};
const multi = (value: unknown): string[] => Array.isArray(value) ? value.map(String) : value ? [String(value)] : [];
const options = (rows: ReferenceRecord[]): EntityOption[] => rows.map(row => ({id: row.id, name: row.name || row.code || row.id}));
const nameOf = (rows: EntityOption[], id: string) => rows.find(row => row.id === id)?.name || "";
async function readAll<T extends ReferenceRecord = ReferenceRecord>(name: ReferenceName, signal: AbortSignal): Promise<T[]> {
  const first = await api.listReference<T>(name, {page: 1, pageSize: 200}, signal);
  const rows = [...first.items];
  for (let page = 2; rows.length < first.total; page++) rows.push(...(await api.listReference<T>(name, {page, pageSize: 200}, signal)).items);
  return rows;
}

async function loadReferences(signal: AbortSignal): Promise<References> {
  const [halls, sourceHalls, warehouses, customers, employees, catalog] = await Promise.all([
    api.getHallConfiguration(signal), readAll<SourceHall>("halls", signal),
    readAllReferences("warehouses", signal),
    readAll("customers", signal), readAll("employees", signal),
    api.getRuntimeCatalog<{products: Array<{code: string; category_name?: string | null}>}>(signal),
  ]);
  if (signal.aborted) throw new DOMException("Aborted", "AbortError");
  return {halls: halls.stores.map(row => ({id: row.id, name: row.name})), warehouses: options(warehouses),
    customers: options(customers), employees: options(employees),
    categories: new Map(catalog.products.map(row => [row.code, row.category_name || ""])),
    hallAliases: halls.aliases,
    hallByDepartment: new Map(sourceHalls.filter(row => row.department_id).map(row => [String(row.department_id), row.id])),
  };
}
const fetchSales = async ({applied, page, pageSize, signal}: PageRequest<Filter>) => {
  const f = applied;
  const result = await api.listRuntimeDocuments("SALE", {page, pageSize, filters: {
    number: f.number.trim(), start: f.start, end: f.end, businessType: f.businessType,
    status: f.status, storeId: f.storeId, salespersonId: f.salespersonId, creatorId: f.creatorId,
    customerId: f.customerId, warehouseId: f.warehouseId,
  }}, signal);
  return {items: result.items.map(asSale), total: result.total};
};
function sourceName(item: SaleDocument, key: string) {
  const payload = item.body.header.source_payload as Record<string, unknown> | undefined;
  const source = payload?.source as Record<string, unknown> | undefined;
  return text(source?.[key]);
}
function lineSummary(item: SaleDocument, categories: Map<string, string>) {
  const summarize = (lines: SaleDocument["body"]["lines"]) => {
    const groups = new Map<string, SaleDocument["body"]["lines"]>();
    for (const line of lines) {
      const code = text(line.source_product_code), name = categories.get(code) || text(line.source_product_name) || code || "商品";
      groups.set(name, [...(groups.get(name) || []), line]);
    }
    const facts = [...groups].map(([name, items]) => `${name} ${quantityTotal(items).replace(/^-/, "")}`);
    return facts.length ? facts.join(" · ") : "0";
  };
  if (!item.body.lines.length) return "暂无销售商品";
  return saleKind(item.body.lines) === "销售" ? summarize(item.body.lines) : `退：${summarize(item.body.lines.filter(line => Number(line.source_quantity) < 0))} · 换：${summarize(item.body.lines.filter(line => Number(line.source_quantity) > 0))}`;
}
function hallName(item: SaleDocument, refs: References): string {
  const header = item.body.header;
  const rawId = headerValue(header, "hall_id") || refs.hallByDepartment.get(headerValue(header, "source_department_id")) || "";
  const canonicalId = refs.hallAliases[rawId] || rawId;
  return headerValue(header, "hall_name") || nameOf(refs.halls, canonicalId) || "待确认";
}
function readLocation() {
  const params = new URLSearchParams(location.search), keys = ["start", "end", "number", "businessType", "status", "creatorId", "storeId", "salespersonId", "customerId", "warehouseId", "page"];
  if (!keys.some(key => params.has(key))) return null;
  const filter: Filter = {...INITIAL, storeId: [], salespersonId: [], customerId: [], warehouseId: []};
  for (const key of ["start", "end", "number", "businessType", "status", "creatorId"] as const) filter[key] = params.get(key) || "";
  for (const key of ["storeId", "salespersonId", "customerId", "warehouseId"] as const) filter[key] = params.getAll(key);
  return {filter, page: Math.max(1, Number(params.get("page")) || 1)};
}
function writeLocation(filter: Filter, page: number) {
  const params = new URLSearchParams();
  for (const key of ["start", "end", "number", "businessType", "status", "creatorId"] as const) if (filter[key]) params.set(key, filter[key]);
  for (const key of ["storeId", "salespersonId", "customerId", "warehouseId"] as const) for (const value of filter[key]) params.append(key, value);
  if (page > 1) params.set("page", String(page));
  history.replaceState({}, "", `/sales${params.size ? `?${params}` : ""}`);
}

export function SalesListPage() {
  const {state, controller} = usePagedQuery<Filter, SaleDocument>(INITIAL, 20, fetchSales);
  const [refs, setRefs] = useState<References>(emptyRefs), [referenceError, setReferenceError] = useState("");
  const [moreOpen, setMoreOpen] = useState(false), [validation, setValidation] = useState("");
  const scroll = useRef<HTMLDivElement>(null), restored = useRef(false);
  useEffect(() => {
    const location = readLocation(), remembered = readListReturn("sales");
    if (location) void controller.restore(location.filter, location.page);
    else if (remembered) {
      const old = remembered.applied as Partial<Filter>;
      void controller.restore({...INITIAL, ...old, storeId: multi(old.storeId), salespersonId: multi(old.salespersonId), customerId: multi(old.customerId), warehouseId: multi(old.warehouseId)}, 1);
    } else void controller.reload();
  }, [controller]);
  useEffect(() => {const abort = new AbortController(); void loadReferences(abort.signal).then(setRefs).catch(error => {if (!abort.signal.aborted) setReferenceError(error instanceof Error ? error.message : "筛选资料读取失败");}); return () => abort.abort();}, []);
  useEffect(() => {if (state.hasExecuted) writeLocation(state.applied, state.page);}, [state.applied, state.page, state.hasExecuted]);
  useEffect(() => {
    if (restored.current || !state.hasExecuted || state.loading !== "idle") return;
    restored.current = true;
    const remembered = readListReturn("sales");
    if (remembered?.url === location.pathname + location.search) requestAnimationFrame(() => {if (scroll.current) scroll.current.scrollTop = remembered.scrollY;});
  }, [state.hasExecuted, state.loading]);
  const f = state.draft, dirty = JSON.stringify(f) !== JSON.stringify(state.applied);
  const today = new Date().toLocaleDateString("sv-SE", {timeZone: "Asia/Shanghai"});
  function setDraft(patch: Partial<Filter>) {controller.setDraft({...f, ...patch}); setValidation("");}
  function query(event?: React.FormEvent) {event?.preventDefault(); if (f.start && f.end && f.start > f.end) {setValidation("开始日期不能晚于结束日期"); return;} scroll.current?.scrollTo({top: 0}); void controller.apply();}
  function quick(patch: Partial<Filter>) {setValidation(""); scroll.current?.scrollTo({top: 0}); void controller.restore({...f, ...patch}, 1);}
  function reset() {setValidation(""); setMoreOpen(false); scroll.current?.scrollTo({top: 0}); void controller.reset();}
  function open(item: SaleDocument, edit = false) {writeLocation(state.applied, state.page); saveListReturn("sales", state.applied as unknown as Record<string, unknown>, scroll.current?.scrollTop || 0); navigate(`/sales/${encodeURIComponent(item.id)}${edit ? "/edit" : ""}`);}
  function newSale() {writeLocation(state.applied, state.page); saveListReturn("sales", state.applied as unknown as Record<string, unknown>, scroll.current?.scrollTop || 0); navigate("/sales/new");}
  const columns = useMemo(() => [
    {title: "日期", key: "date", render: (_: unknown, item: SaleDocument) => <>{headerValue(item.body.header, "business_date").replace("T", " ") || "未提供"}{businessDate(item.body.header).length === 10 && !headerValue(item.body.header, "business_date").includes("T") && <small>时分未记录</small>}</>},
    {title: "销货单号", key: "number", render: (_: unknown, item: SaleDocument) => <><Button className="lr-sale-number-link" type="text" onClick={() => open(item)}>{item.number}</Button><small className="lr-sale-found-product" title={lineSummary(item, refs.categories)}>{lineSummary(item, refs.categories)}</small></>},
    {title: "业务类型", key: "kind", render: (_: unknown, item: SaleDocument) => saleKind(item.body.lines) === "销售" ? "销售" : "退货/换货"},
    {title: "营业厅", key: "hall", render: (_: unknown, item: SaleDocument) => hallName(item, refs)},
    {title: "客户", key: "customer", render: (_: unknown, item: SaleDocument) => headerValue(item.body.header, "customer_name") || nameOf(refs.customers, headerValue(item.body.header, "source_party_id")) || sourceName(item, "客户") || "未提供"},
    {title: "出库仓", key: "warehouse", render: (_: unknown, item: SaleDocument) => headerValue(item.body.header, "warehouse_name") || nameOf(refs.warehouses, headerValue(item.body.header, "source_warehouse_id")) || sourceName(item, "仓库") || "未提供"},
    {title: "营业员", key: "employee", render: (_: unknown, item: SaleDocument) => headerValue(item.body.header, "employee_name") || nameOf(refs.employees, headerValue(item.body.header, "source_employee_id")) || sourceName(item, "业务员") || "未选择"},
    {title: "数量", key: "quantity", render: (_: unknown, item: SaleDocument) => saleKind(item.body.lines) === "销售" ? quantityTotal(item.body.lines) : `退${quantityTotal(item.body.lines.filter(line => Number(line.source_quantity) < 0)).replace(/^-/, "")} · 换${quantityTotal(item.body.lines.filter(line => Number(line.source_quantity) > 0))}`},
    {title: "金额", key: "amount", align: "right" as const, render: (_: unknown, item: SaleDocument) => moneyToDecimal(dueAmount(item.body)) || "未知"},
    {title: "状态", key: "status", render: (_: unknown, item: SaleDocument) => <SaleStatusTag status={item.status} />},
    {title: "操作", key: "action", render: (_: unknown, item: SaleDocument) => <div className="lr-sale-row-actions"><LegacyActionIcon kind="detail" label="查看单据" onClick={() => open(item)} />{item.status === "UNAUDITED" && <LegacyActionIcon kind="edit" label="编辑单据" onClick={() => open(item, true)} />}</div>},
  ], [refs]);
  return <section className="lr-sale-workbench">
    <div className="lr-sale-head"><h1>销货单列表</h1><div><Button type="primary" onClick={newSale}>新增销货单</Button></div></div>
    <div className="lr-sale-quick-filters"><Button aria-pressed={f.creatorId === "local-admin"} onClick={() => quick({creatorId: f.creatorId === "local-admin" ? "" : "local-admin"})}>我的单据</Button><Button onClick={() => quick({status: "未审核"})}>未审核</Button><Button onClick={() => quick({start: today, end: today})}>今天</Button><Button onClick={reset}>全部</Button></div>
    <form className="lr-sale-filters" onSubmit={query}>
      <label>单据日期<DatePicker aria-label="开始日期" {...(f.start ? {value: f.start} : {})} onChange={start => setDraft({start})} /></label>
      <label>至<DatePicker aria-label="结束日期" {...(f.end ? {value: f.end} : {})} onChange={end => setDraft({end})} /></label>
      <label className="lr-sale-search-field">查找单据<Input aria-label="查找单据：单号、货号、商品名称、客户" value={f.number} placeholder="单号／货号／名称／客户" onChange={number => setDraft({number})} /></label>
      <label>业务类型<Select aria-label="筛选业务类型" value={f.businessType} options={[{label: "全部", value: ""}, {label: "销售", value: "销售"}, {label: "退货/换货", value: "退货/换货"}]} onChange={businessType => setDraft({businessType: String(businessType || "")})} /></label>
      <label>单据状态<Select aria-label="筛选单据状态" value={f.status} options={[{label: "全部状态", value: ""}, {label: "未审核", value: "未审核"}, {label: "已审核", value: "已审核"}]} onChange={status => setDraft({status: String(status || "")})} /></label>
      <label>营业厅<EntityPicker label="营业厅" items={refs.halls} value={f.storeId} multiple allLabel="全部营业厅" onChange={value => setDraft({storeId: multi(value)})} /></label>
      <label>营业员<EntityPicker label="营业员" items={refs.employees} value={f.salespersonId} multiple allLabel="全部营业员" onChange={value => setDraft({salespersonId: multi(value)})} /></label>
      <Button htmlType="submit" type="primary" loading={state.loading !== "idle"}>查询</Button><Button onClick={reset}>重置</Button>
      <Collapse className="lr-sale-more-filter" bordered={false} activeKey={moreOpen ? ["more"] : []} onChange={(_key, keys) => setMoreOpen(keys.includes("more"))}><Collapse.Item name="more" header={`更多筛选${f.storeId.length || f.salespersonId.length || f.status ? "（有条件）" : ""}`}><div className="lr-sale-more-filter-fields">
        <label>创建者<Select aria-label="创建者" value={f.creatorId} options={[{label: "全部创建者", value: ""}, {label: "管理员", value: "local-admin"}]} onChange={creatorId => setDraft({creatorId: String(creatorId || "")})} /></label>
        <label>客户<EntityPicker label="客户" items={refs.customers} value={f.customerId} multiple allLabel="全部客户" onChange={value => setDraft({customerId: multi(value)})} /></label>
        <label>出库仓<EntityPicker label="出库仓" items={refs.warehouses} value={f.warehouseId} multiple allLabel="全部出库仓" onChange={value => setDraft({warehouseId: multi(value)})} /></label>
      </div></Collapse.Item></Collapse>
    </form>
    <div className="lr-sale-query-note" role="status">{validation || referenceError || (dirty ? "条件已修改，点击“查询”更新结果。" : "查询销售及退货/换货；支持单号、款号、商品名称或客户。")}</div>
    <div ref={scroll} className="lr-sale-list-scroll">{state.loading === "initial" ? <div className="lr-sale-empty" role="status">正在查询…</div> : state.error && !state.stale ? <div className="lr-sale-empty" role="alert">{state.error.message} <Button onClick={() => void controller.reload()}>重试</Button></div> : <><Table className="lr-sale-list-table" rowKey="id" columns={columns} data={state.items} pagination={false} tableLayoutFixed={false} size="small" border={{wrapper: false, cell: false}} noDataElement={<div className="lr-sale-empty">没有符合条件的销货单</div>} />{state.error && <div className="lr-sale-query-error" role="alert">读取失败，保留上次结果：{state.error.message} <Button onClick={() => void controller.reload()}>重试</Button></div>}</>}</div>
    <footer className="lr-sale-foot"><span>共 {state.total} 张 · 每页 {state.pageSize} 张 · 已审核销售合计 <AmountDisplay value={pageApprovedDue(state.items)} /> 元</span><div><Pagination simple current={state.page} pageSize={state.pageSize} total={state.total} size="small" showJumper={false} itemRender={(page, type, origin) => type === "prev" ? "上一页" : type === "next" ? "下一页" : origin} onChange={page => {scroll.current?.scrollTo({top: 0}); void controller.setPage(page);}} /></div></footer>
  </section>;
}
