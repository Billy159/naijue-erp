import { useRef, useState } from "react";
import { Alert, Button, Drawer, Input, InputNumber, Space, Typography } from "@arco-design/web-react";
import { type SkuLookup } from "@stage05";
import type { PendingSku } from "./BatchEntry";

export function ScanPanel({visible, lookup, onCancel, onAppend, initialQuantity = "1"}: {
  visible: boolean; lookup: SkuLookup | null; onCancel: () => void; onAppend: (lines: PendingSku[]) => void; initialQuantity?: string;
}) {
  const [barcode, setBarcode] = useState(""), [quantity, setQuantity] = useState(initialQuantity);
  const [price, setPrice] = useState("0"), [result, setResult] = useState<{type: "success" | "warning" | "error"; message: string} | null>(null);
  const dispatching = useRef(false), lastSuccessfulEvent = useRef("");
  function scan() {
    if (dispatching.current) return;
    dispatching.current = true;
    try {
      if (!lookup) throw Error("商品目录仍在加载，请稍后重试");
      const code = barcode.trim();
      if (!code) throw Error("请先输入或扫描条码");
      const event = `${code}\u0000${quantity}\u0000${price}`;
      if (event === lastSuccessfulEvent.current) return;
      const found = lookup.barcode(code);
      if (found.kind === "not-found") {setResult({type: "error", message: `未知条码：${code}。未追加商品。`}); return;}
      if (found.kind === "product-only") {setResult({type: "warning", message: "此条码仅指向商品，请手动选择颜色和尺码；未追加任何 SKU。"}); return;}
      if (found.kind === "ambiguous") {setResult({type: "warning", message: `此条码对应 ${found.skuIds.length} 个 SKU，存在歧义；未自动选择。`}); return;}
      if (!found.sku.sourceEnabled) throw Error("该 SKU 当前不可录入");
      const matrix = lookup.matrixForProduct(found.sku.product.productId);
      const cell = matrix.sections.flatMap(section => section.rows).flatMap(row => row.cells).flatMap(place => place.entries).find(entry => entry.skuId === found.sku.identity.skuId);
      if (!cell) throw Error("条码 SKU 不在已验证的矩阵中");
      const reference = lookup.inputReference(cell);
      onAppend([{reference, sku: found.sku, quantity, unitPrice: price}]);
      lastSuccessfulEvent.current = event;
      setResult({type: "success", message: `已追加 ${found.sku.product.sourceCode} · ${found.sku.color.name} · ${found.sku.column.name} · ${found.sku.fit.code}版，数量 ${quantity}`});
      setBarcode("");
    } catch (issue) {setResult({type: "error", message: issue instanceof Error ? issue.message : "扫码失败"});}
    finally {dispatching.current = false;}
  }
  return <Drawer title="扫码录入" visible={visible} width="min(560px, calc(100vw - 48px))" footer={null} onCancel={onCancel}>
    <Space direction="vertical" size="large" style={{width: "100%"}}>
      <Typography.Text type="secondary">只有绑定到唯一原 SKU 的条码会追加明细。商品级条码、歧义码和未知码都需要人工处理。</Typography.Text>
      <Input.Search aria-label="扫描条码" value={barcode} onChange={value => {setBarcode(value); lastSuccessfulEvent.current = "";}} onSearch={scan} placeholder="扫描或输入条码，按 Enter" autoFocus />
      <Space wrap><div><Typography.Text type="secondary">本次数量</Typography.Text><InputNumber aria-label="扫码数量" value={Number(quantity)} precision={4} hideControl onChange={value => setQuantity(String(value ?? 0))} style={{width: 150}} /></div><div><Typography.Text type="secondary">单价</Typography.Text><InputNumber aria-label="扫码单价" value={Number(price)} min={0} precision={2} prefix="¥" hideControl onChange={value => setPrice(String(value ?? 0))} style={{width: 150}} /></div></Space>
      <Button type="primary" onClick={scan}>确认追加</Button>
      {result && <Alert type={result.type} showIcon content={result.message} />}
    </Space>
  </Drawer>;
}
