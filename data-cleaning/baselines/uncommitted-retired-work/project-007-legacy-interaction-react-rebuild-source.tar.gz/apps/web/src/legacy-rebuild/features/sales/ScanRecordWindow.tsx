import { useRef, useState, type PointerEvent as ReactPointerEvent } from "react";
import { Button, Collapse, Input } from "@arco-design/web-react";

export function ScanRecordWindow({visible, documentNumber, records, error, onClose}: {
  visible: boolean;
  documentNumber: string;
  records: Record<string, unknown>[];
  error: string;
  onClose: () => void;
}) {
  const [position, setPosition] = useState(() => ({x: Math.max(8, innerWidth - 418), y: Math.min(260, innerHeight - 140)}));
  const [minimized, setMinimized] = useState(false);
  const drag = useRef<{id: number; dx: number; dy: number} | null>(null);
  const box = useRef<HTMLElement>(null);
  function clamp(x: number, y: number) {
    const width = Math.min(400, innerWidth - 16), height = box.current?.getBoundingClientRect().height || 160;
    setPosition({x: Math.max(8, Math.min(x, innerWidth - width - 8)), y: Math.max(8, Math.min(y, innerHeight - Math.min(height, innerHeight - 16) - 8))});
  }
  function down(event: ReactPointerEvent<HTMLElement>) {
    if ((event.target as HTMLElement).closest("button")) return;
    const rect = box.current?.getBoundingClientRect();
    if (!rect) return;
    drag.current = {id: event.pointerId, dx: event.clientX - rect.left, dy: event.clientY - rect.top};
    event.currentTarget.setPointerCapture(event.pointerId);
    event.preventDefault();
  }
  function move(event: ReactPointerEvent<HTMLElement>) {
    if (drag.current?.id !== event.pointerId) return;
    clamp(event.clientX - drag.current.dx, event.clientY - drag.current.dy);
  }
  if (!visible) return null;
  return <section ref={box} className="lr-sale-scan-window" aria-label="扫码工作窗" style={{left: position.x, top: position.y, width: Math.min(400, innerWidth - 16), maxHeight: innerHeight - 16}}>
    <header onPointerDown={down} onPointerMove={move} onPointerUp={() => {drag.current = null;}}>
      <strong>换出／销售商品 · 扫码录入</strong><span>当前不可录入</span>
      <Button aria-label="最小化扫码窗口" onClick={() => setMinimized(value => !value)}>{minimized ? "展开" : "−"}</Button>
      <Button aria-label="关闭扫码窗口" onClick={onClose}>×</Button>
    </header>
    {!minimized && <div className="lr-sale-scan-body">
      <small>{documentNumber}</small>
      <div className="lr-sale-scan-form"><Input aria-label="准确条码" placeholder="扫描准确条码" disabled /><Button type="primary" disabled>录入</Button></div>
      <Button disabled>撤销上一扫</Button>
      {error && <p role="alert">扫码记录读取失败：{error}</p>}
      <Collapse bordered={false} defaultActiveKey={["records"]}><Collapse.Item name="records" header={`扫码记录 （${records.length}）`}><div>{records.length ? [...records].reverse().map((record, index) => <article key={String(record.id || index)}>
        <div>{String((record.actor as Record<string, unknown> | undefined)?.name || "—")} · {record.time ? new Date(String(record.time)).toLocaleString("zh-CN", {hour12: false}) : "时间未提供"}</div>
        <code>{String(record.code || record.input || "")}</code>
        <div>{String(record.error || [record.productId || record.p, record.color, record.size].filter(Boolean).join(" "))}</div>
        <span>{record.error ? "失败" : record.undone ? "已撤销" : record.query ? "查询定位" : "成功 +1"}</span>
      </article>) : <p>暂无扫码记录</p>}</div></Collapse.Item></Collapse>
    </div>}
  </section>;
}
