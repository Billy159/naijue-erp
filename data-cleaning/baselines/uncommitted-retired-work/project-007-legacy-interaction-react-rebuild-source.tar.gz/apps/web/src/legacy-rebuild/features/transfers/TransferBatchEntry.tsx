import { useEffect, useMemo, useState } from "react";
import { Alert, Button, Input, Modal, Space, Table, Tag, Typography } from "@arco-design/web-react";
import {
  api, formatSignedQuantity, parseSignedQuantity,
  type DisplaySku, type ProductRecord, type SkuInputReference, type SkuLookup,
} from "@stage05";
import type { TransferLine } from "./model";

export type PendingTransferSku = {reference: SkuInputReference; sku: DisplaySku; quantity: string; productName: string};
export function TransferBatchEntry({visible, lookup, existing, initialProductId, warehouseIssue, onCancel, onAppend}: {
  visible: boolean; lookup: SkuLookup | null; existing: readonly TransferLine[]; initialProductId: string | null;
  warehouseIssue: string; onCancel: () => void; onAppend: (lines: PendingTransferSku[]) => boolean;
}) {
  const [q, setQ] = useState(""), [results, setResults] = useState<ProductRecord[]>([]);
  const [product, setProduct] = useState<ProductRecord | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false), [error, setError] = useState("");
  useEffect(() => {
    if (!visible) return;
    setQ(""); setResults([]); setProduct(null); setValues({}); setError("");
    if (initialProductId && lookup) {
      const identity = lookup.productById(initialProductId);
      if (identity) void api.getProduct(identity.sourceCode).then(setProduct).catch(issue => setError(issue instanceof Error ? issue.message : "商品读取失败"));
    }
  }, [visible, initialProductId, lookup]);
  const current = useMemo(() => {
    const quantities = new Map<string, bigint>();
    try {
      for (const line of existing) quantities.set(line.sku_id, (quantities.get(line.sku_id) || 0n) + parseSignedQuantity(line.source_quantity));
      return {values: Object.fromEntries([...quantities].map(([id, value]) => [id, formatSignedQuantity(value)])), invalid: false};
    } catch {return {values: {}, invalid: true};}
  }, [existing]);
  const identity = product && lookup?.productByCode(product.code);
  const matrix = identity && lookup && !current.invalid ? lookup.matrixForProduct(identity.productId, current.values) : null;
  async function search() {
    setLoading(true); setError("");
    try {const result = await api.listProducts({page: 1, pageSize: 20, q: q.trim()}); setResults(result.items);}
    catch (issue) {setError(issue instanceof Error ? issue.message : "商品查询失败");}
    finally {setLoading(false);}
  }
  function append() {
    if (warehouseIssue) {setError(warehouseIssue); return;}
    if (!lookup || !matrix || !product) {setError("请先选择商品及可录入规格"); return;}
    try {
      const pending: PendingTransferSku[] = [];
      for (const section of matrix.sections) for (const row of section.rows) for (const cell of row.cells) for (const entry of cell.entries) {
        if (!entry.skuId || !values[entry.skuId]?.trim()) continue;
        const quantity = formatSignedQuantity(parseSignedQuantity(values[entry.skuId]!));
        if (parseSignedQuantity(quantity) === 0n) continue;
        if (!entry.editable) throw Error("停用规格不可新增调拨明细");
        const sku = lookup.skuById(entry.skuId);
        if (!sku) throw Error("原 SKU 身份未找到");
        pending.push({reference: lookup.inputReference(entry), sku, quantity, productName: product.name});
      }
      if (!pending.length) throw Error("请先填写本次追加数量");
      if (!onAppend(pending)) {setError("明细未追加，请核对仓库和规格"); return;}
      setValues({}); setError("");
    } catch (issue) {setError(issue instanceof Error ? issue.message : "本次追加未完成");}
  }
  const selected = Object.values(values).filter(value => value.trim() && value !== "0").length;
  return <Modal visible={visible} title="批量追加商品规格" style={{width: "min(1220px, calc(100vw - 40px))"}} onCancel={onCancel} onOk={append} okText={`确认追加 · ${selected} 个 SKU`} maskClosable={false} unmountOnExit>
    <Space direction="vertical" size="medium" style={{width: "100%"}}>
      {warehouseIssue && <Alert type="warning" showIcon content={warehouseIssue} />}
      {!lookup && <Alert type="info" showIcon content="正在读取商品规格目录，稍后可选择规格" />}
      <Alert type="info" showIcon content="“当前已有”是单据草稿数量；“本次追加”会按原 SKU 身份加到草稿，不会覆盖已有数量。缺格不可输入；同格 A/B 版分别录入。" />
      <Space wrap><Input.Search aria-label="批量搜索商品" value={q} onChange={setQ} onSearch={() => void search()} loading={loading} placeholder="货号或商品名称" style={{width: 300}} /><Button onClick={() => void search()}>搜索</Button></Space>
      {error && <Alert type="error" showIcon content={error} />}
      {current.invalid && <Alert type="error" showIcon content="当前草稿含无效数量，请先修正明细后再打开批量矩阵。" />}
      {!product && <Table rowKey="id" size="small" pagination={false} data={results} noDataElement="搜索并选择商品" columns={[
        {title: "款号", dataIndex: "code"}, {title: "商品名称", dataIndex: "name"},
        {title: "操作", render: (_: unknown, item: ProductRecord) => <Button type="text" size="small" onClick={() => {setProduct(item); setValues({});}}>选择</Button>},
      ]} />}
      {product && <><Space wrap><Typography.Text bold>{product.code} · {product.name}</Typography.Text><Button type="text" onClick={() => {setProduct(null); setValues({});}}>换商品</Button></Space>
        {!matrix && <Alert type="error" showIcon content="该商品没有已核验的 SKU 矩阵。" />}
        {matrix?.sections.map(section => <div key={section.group.name} className="s05-transfer-batch-section"><Typography.Title heading={6}>{section.group.name}</Typography.Title><div className="s05-transfer-matrix-scroll"><table className="s05-transfer-matrix">
          <thead><tr><th>颜色</th>{section.group.columns.map(column => <th key={column.key}>{column.name}</th>)}</tr></thead>
          <tbody>{section.rows.map(row => <tr key={row.product.productId + ":" + row.color.colorId}><th>{row.color.name}</th>{row.cells.map(cell => <td key={cell.column.key}>{cell.missing ? <span className="s05-transfer-missing">— 无此规格</span> : cell.entries.map(entry => <div key={entry.skuId} className="s05-transfer-batch-cell">
            <Tag size="small">{entry.fit?.code}版{cell.entries.length > 1 ? ` · 原 ${entry.originalIdentity.sourceSizeName}` : ""}</Tag>
            <small>当前已有 {entry.displayValue ?? "0"}</small>
            <Input aria-label={`${row.color.name} ${cell.column.name} ${entry.fit?.code}版 本次追加`} inputMode="decimal" disabled={!entry.editable} value={entry.skuId ? values[entry.skuId] || "" : ""} placeholder="本次追加" onChange={value => {if (entry.skuId) setValues(old => ({...old, [entry.skuId!]: value}));}} />
          </div>)}</td>)}</tr>)}</tbody>
        </table></div></div>)}
      </>}
    </Space>
  </Modal>;
}
