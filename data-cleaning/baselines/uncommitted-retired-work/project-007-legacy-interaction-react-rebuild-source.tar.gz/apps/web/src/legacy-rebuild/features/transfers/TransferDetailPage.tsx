import { useEffect, useMemo, useRef, useState } from "react";
import { Alert, Button, Collapse, Descriptions, Drawer, Dropdown, Input, Menu, Modal, Select, Space, Timeline, Typography } from "@arco-design/web-react";
import {
  ApiError, DocumentCommandController, DocumentStatus, ErrorState, LoadingState, NotFoundState,
  PageContainer, api, feedback, navigate, newRequestKey, returnToList, type DocumentCommand, type SkuLookup,
} from "@stage05";
import { loadSkuProjection } from "../products/skuRepository";
import { downloadTransferXlsx } from "./export";
import { TransferMatrix } from "./TransferMatrix";
import { TransferEditorPage } from "./TransferEditorPage";
import {
  asTransfer, transferDate, transferHeader, transferSummary, transferText, transferView,
  warehouseIds, type TransferBody, type TransferDocument,
} from "./model";
import "./transfers.css";

type Warehouse = {id: string; name: string; code?: string};
type HistoryEntry = {
  version: number; operation: string; revision: number; actor_id: string | null;
  created_at: string | null; request_key: string; body?: TransferBody; previous_body?: TransferBody;
};
const operationName: Record<string, string> = {create: "新建保存", save: "保存修订", approve: "审核", unapprove: "弃审"};
function historyChanges(entry: HistoryEntry): string[] {
  const before = entry.previous_body, after = entry.body;
  if (!before?.header || !after?.header) return ["服务端保留了本次修订版本；正文差异未提供。"];
  const changes: string[] = [];
  for (const [key, label] of [["business_date", "业务日期"], ["source_from_warehouse_id", "调出仓"], ["source_to_warehouse_id", "调入仓"], ["note", "备注"]] as const) {
    const oldValue = transferHeader(before.header, key), nextValue = transferHeader(after.header, key);
    if (oldValue !== nextValue) changes.push(`${label}：${oldValue || "未提供"} → ${nextValue || "未提供"}`);
  }
  if (JSON.stringify(before.lines) !== JSON.stringify(after.lines)) changes.push(`明细：${before.lines.length} 行 / ${transferSummary(before.lines).quantity} → ${after.lines.length} 行 / ${transferSummary(after.lines).quantity}`);
  return changes.length ? changes : ["本次保存未改变当前展示字段；服务端版本仍保留。"];
}
function TransferHistory({visible, document, onCancel}: {visible: boolean; document: TransferDocument; onCancel: () => void}) {
  const history = (document.history || []) as HistoryEntry[];
  return <Drawer visible={visible} title={`操作历史 · ${document.number}`} width="min(580px, calc(100vw - 40px))" footer={null} onCancel={onCancel}>
    {history.length ? <Timeline>{history.map(entry => <Timeline.Item key={entry.version} label={entry.created_at ? new Date(entry.created_at).toLocaleString("zh-CN") : "时间未提供"}>
      <strong>版本 {entry.version} · {operationName[entry.operation] || entry.operation}</strong>
      <div className="s05-transfer-muted">操作人：{entry.actor_id === "local-admin" ? "管理员" : entry.actor_id || "历史未提供"} · 修订 {entry.revision}</div>
      {entry.operation === "save" && <Collapse bordered={false}><Collapse.Item name="changes" header="查看修订差异"><Space direction="vertical" size="mini">{historyChanges(entry).map(change => <Typography.Text key={change} type="secondary">{change}</Typography.Text>)}</Space></Collapse.Item></Collapse>}
    </Timeline.Item>)}</Timeline> : <Alert type="info" showIcon content="历史导入时没有伪造创建或审核操作。原操作人及时间未提供。" />}
  </Drawer>;
}
type DetailState = {kind: "loading" | "ready" | "not-found" | "error"; document?: TransferDocument; message?: string};
export function TransferDetailPage({id}: {id: string}) {
  const [state, setState] = useState<DetailState>({kind: "loading"});
  const [lookup, setLookup] = useState<SkuLookup | null>(null), [lookupError, setLookupError] = useState("");
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [retry, setRetry] = useState(0), [pending, setPending] = useState(false), [error, setError] = useState("");
  const [uncertain, setUncertain] = useState<DocumentCommand | null>(null);
  const [confirmUnapprove, setConfirmUnapprove] = useState(false), [historyOpen, setHistoryOpen] = useState(false), [printOpen, setPrintOpen] = useState(false);
  const [scanRecordsOpen, setScanRecordsOpen] = useState(false), [scanRecords, setScanRecords] = useState<Record<string, unknown>[]>([]);
  const [exportPending, setExportPending] = useState(false);
  const running = useRef(false), command = useMemo(() => new DocumentCommandController(api), []);
  useEffect(() => {
    window.document.body.classList.toggle("s05-transfer-printing", printOpen);
    return () => window.document.body.classList.remove("s05-transfer-printing");
  }, [printOpen]);
  useEffect(() => {
    const abort = new AbortController(); setState({kind: "loading"});
    void api.getDocument(id, abort.signal).then(value => {
      if (abort.signal.aborted) return;
      const doc = asTransfer(value);
      setState({kind: "ready", document: doc});
      void api.listRuntimeWork(doc.number, abort.signal).then(setScanRecords).catch(() => {});
    })
      .catch(issue => {if (!abort.signal.aborted) setState(issue instanceof ApiError && issue.kind === "not-found" ? {kind: "not-found"} : {kind: "error", message: issue instanceof Error ? issue.message : "调拨单读取失败"});});
    void loadSkuProjection().then(value => {if (!abort.signal.aborted) setLookup(value);})
      .catch(issue => {if (!abort.signal.aborted) setLookupError(issue instanceof Error ? issue.message : "SKU 投影读取失败");});
    void api.listReference<Warehouse>("warehouses", {page: 1, pageSize: 100}, abort.signal)
      .then(page => {if (!abort.signal.aborted) setWarehouses(page.items);})
      .catch(() => {});
    return () => abort.abort();
  }, [id, retry]);
  const document = state.document;
  const view = useMemo(() => {
    if (!document || !lookup) return null;
    try {return transferView(document, lookup);}
    catch (issue) {return issue instanceof Error ? issue : Error("调拨投影失败");}
  }, [document, lookup]);
  const names = useMemo(() => new Map(warehouses.map(row => [row.id, row.name || row.code || row.id])), [warehouses]);
  async function run(operation: "approve" | "unapprove") {
    if (!document || running.current || uncertain) return;
    running.current = true; setPending(true); setError("");
    try {
      const attempt: DocumentCommand = {documentId: document.id, operation, expectedVersion: document.version, requestKey: newRequestKey()};
      if (!await command.submit(attempt)) {
        const failure = command.getSnapshot();
        if (failure.state === "failure" && failure.kind === "network-uncertain") setUncertain(attempt);
        setError(failure.state === "failure" ? failure.reason : "命令未确认");
        return;
      }
      let latest: TransferDocument;
      try {latest = asTransfer(await api.getDocument(document.id));}
      catch {
        setUncertain(attempt);
        throw Error("命令已提交，但服务端回读未确认；原 requestKey 已保留，请先核对命令结果。");
      }
      setState({kind: "ready", document: latest}); setConfirmUnapprove(false);
      feedback.success(operation === "approve" ? "调拨审核成功，双仓库存已生效" : "弃审成功，库存效果已反转且原流水保留");
    } catch (issue) {setError(issue instanceof Error ? issue.message : "服务端回读失败，请重新读取");}
    finally {running.current = false; setPending(false);}
  }
  async function reconcile() {
    if (!uncertain || running.current) return;
    running.current = true; setPending(true); setError("");
    try {
      let latest = asTransfer(await command.readCurrentDocument(uncertain.documentId));
      if (latest.version === uncertain.expectedVersion) {
        if (!await command.submit(uncertain)) {
          const failure = command.getSnapshot();
          throw Error(failure.state === "failure" ? failure.reason : "原命令仍未确认");
        }
        latest = asTransfer(await command.readCurrentDocument(uncertain.documentId));
      }
      if (!(latest.history || []).some(raw => (raw as {request_key?: string}).request_key === uncertain.requestKey)) throw Error("服务端版本已变化，原命令未确认；请核对最新版本。");
      setState({kind: "ready", document: latest}); setUncertain(null); setConfirmUnapprove(false);
      feedback.success("已核对原 requestKey 与服务端版本");
    } catch (issue) {setError(issue instanceof Error ? issue.message : "命令结果仍未确认");}
    finally {running.current = false; setPending(false);}
  }
  async function exportWhole() {
    if (!view || view instanceof Error || exportPending) return;
    setExportPending(true); setError("");
    try {await downloadTransferXlsx(view, names); feedback.success("已导出整张已保存调拨单");}
    catch (issue) {setError(issue instanceof Error ? issue.message : "XLSX 导出失败");}
    finally {setExportPending(false);}
  }
  if (state.kind === "loading") return <LoadingState text="正在读取已保存调拨单" />;
  if (state.kind === "not-found") return <NotFoundState title="调拨单不存在" onBack={() => returnToList("transfers")} backLabel="返回调拨列表" />;
  if (state.kind === "error") return <ErrorState message={state.message || "读取失败"} onRetry={() => setRetry(value => value + 1)} />;
  const current = document!, header = current.body.header;
  const ids = warehouseIds(header, current.body.lines);
  const from = names.get(ids.from) || ids.from || "未提供", to = names.get(ids.to) || ids.to || "未提供";
  const summary = transferSummary(current.body.lines);
  const isApproved = current.status === "APPROVED" && current.current_effect_active !== false;
  const canEdit = !isApproved && current.status !== "APPROVED";
  const history = (current.history || []) as HistoryEntry[];
  const creator = transferHeader(header, "created_by") || history.find(entry => entry.operation === "create")?.actor_id || "历史未提供";
  const auditor = transferHeader(header, "audited_by") || [...history].reverse().find(entry => entry.operation === "approve")?.actor_id || "历史未提供";
  const creatorName = creator === "local-admin" ? "管理员" : creator;
  const auditorName = auditor === "local-admin" ? "管理员" : auditor;
  const lineage = header.source_payload as {sourceLineage?: Array<{side?: string; sheet?: string; row?: number}>} | undefined;
  if (canEdit) return <TransferEditorPage id={id} />;
  return <>
    <section className="lr-transfer-workbench lr-transfer-editor">
      <div className="lr-transfer-head">
        <h1>查看调拨单</h1><span className="lr-transfer-status">已审核</span>
        <div className="lr-transfer-head-actions">
          <Button onClick={() => returnToList("transfers")}>返回列表</Button>
          <Button loading={pending} disabled={!!uncertain} onClick={() => setConfirmUnapprove(true)}>弃审</Button>
          <Dropdown trigger="click" droplist={<Menu onClickMenuItem={key => {
            if (key === "history") setHistoryOpen(true);
            if (key === "print") setPrintOpen(true);
          }}><Menu.Item key="history">操作历史</Menu.Item><Menu.Item key="print">打印已保存版本</Menu.Item></Menu>}><Button>更多操作</Button></Dropdown>
        </div>
      </div>
      <div className="lr-transfer-doc-header">
        <div className="lr-transfer-direction">
          <label>调出仓<Select aria-label="调出仓" value={ids.from} disabled options={[{label: from, value: ids.from}]} /></label>
          <span aria-hidden="true">→</span>
          <label>调入仓<Select aria-label="调入仓" value={ids.to} disabled options={[{label: to, value: ids.to}]} /></label>
        </div>
        <label className="lr-transfer-date-label">单据日期<Input aria-label="单据日期" value={transferHeader(header, "business_date").replace("T", " ") || "历史未提供"} disabled />{transferDate(header).length === 10 && <small>历史日期 {transferDate(header)}，原记录未提供时分</small>}</label>
        <div className="lr-transfer-meta"><span>单号：{current.number}</span><span>创建者：{creatorName}</span><span>最后修改：{current.updated_at ? new Date(current.updated_at).toLocaleString("zh-CN", {hour12: false}) : "历史未提供"}</span></div>
        <div className="lr-transfer-entry-actions"><Button onClick={() => setScanRecordsOpen(true)}>扫码记录（{scanRecords.length}）</Button><Button disabled={!view || view instanceof Error} loading={exportPending} onClick={() => void exportWhole()}>导出</Button></div>
      </div>
      {error && <Alert type="error" showIcon title="操作未完成" content={<Space wrap>{error}<Button size="small" onClick={() => setRetry(value => value + 1)}>重新读取服务端版本</Button></Space>} />}
      {uncertain && <Alert type="warning" showIcon title="网络结果未确认" content={<Space wrap>原 requestKey 已保留，不能发起新命令。<Button size="small" loading={pending} onClick={() => void reconcile()}>核对并重试原命令</Button></Space>} />}
      {lookupError && <Alert type="error" showIcon title="SKU 投影不可用" content={lookupError} />}
      {view instanceof Error && <Alert type="error" showIcon title="规格身份不一致" content={view.message} />}
      <div className="lr-transfer-readonly">已审核，单据只读。修改前请先弃审。</div>
      <div className="lr-transfer-layout"><div className="lr-transfer-main">
        <div className="lr-transfer-section-head"><strong>调拨明细</strong></div>
        <div className="lr-transfer-matrix-scroll">{!lookup && !lookupError ? <div className="lr-transfer-empty">正在读取真实规格矩阵…</div> : view && !(view instanceof Error) ? <TransferMatrix view={view} /> : null}</div>
        <div className="lr-transfer-total">本次调拨：<strong>{summary.productCount}</strong>款 · 共 <strong>{summary.quantity} 件</strong></div>
      </div></div>
    </section>
    <Modal visible={confirmUnapprove} title="确认弃审调拨单" onCancel={() => {if (!pending) setConfirmUnapprove(false);}} onOk={() => void run("unapprove")} confirmLoading={pending} okText="确认弃审" maskClosable={false} closable={!pending} escToExit={!pending}>
      <Space direction="vertical" size="medium"><Typography.Text>单号：{current.number}</Typography.Text><Typography.Text>调出仓：{from} → 调入仓：{to}</Typography.Text><Alert type="warning" showIcon content="确认后会撤销这张单当前的双仓库存效果；原操作流水和版本历史仍保留。" /></Space>
    </Modal>
    <Modal visible={printOpen} title="调拨打印预览 · 已保存版本" style={{width: "min(1040px, calc(100vw - 32px))"}} onCancel={() => setPrintOpen(false)} onOk={() => window.print()} okText="浏览器打印" className="s05-transfer-print-modal">
      {view && !(view instanceof Error) && <div className="s05-transfer-print-sheet">
        <h1>奈爵服饰 · 调拨单</h1>
        <Descriptions column={3} data={[{label: "单号", value: current.number}, {label: "状态", value: "已审核"}, {label: "业务日期", value: transferDate(header) || "历史未提供"}, {label: "调出仓", value: from}, {label: "调入仓", value: to}, {label: "总数量", value: summary.quantity}]} />
        <TransferMatrix view={view} print />
        <div className="s05-transfer-signatures"><span>调出确认：____________</span><span>调入签收：____________</span></div>
      </div>}
    </Modal>
    {printOpen && <style>{"@media print{@page{size:A4 landscape;margin:10mm}}"}</style>}
    <TransferHistory visible={historyOpen} document={current} onCancel={() => setHistoryOpen(false)} />
    <Modal visible={scanRecordsOpen} title="调拨 · 扫码记录" style={{width: 400}} onCancel={() => setScanRecordsOpen(false)} footer={<Button onClick={() => setScanRecordsOpen(false)}>关闭</Button>}>{scanRecords.length ? scanRecords.map((record, index) => <p key={index}>{String(record.input || record.barcode || record.eventId || "工作记录")}</p>) : <p>暂无扫码记录</p>}</Modal>
  </>;
}
