import { useEffect, useMemo, useRef, useState } from "react";
import { Alert, Button, DatePicker, Descriptions, Dropdown, Input, Menu, Select, Space, Typography, Modal } from "@arco-design/web-react";
import {
  ApiError, DocumentCommandController, api, feedback, navigate, newRequestKey,
  type DocumentCommand, type SkuLookup,
} from "@stage05";
import { loadSkuProjection } from "../products/skuRepository";
import { inventoryReferences, type InventoryReferences } from "../inventory/data";
import { TransferBatchEntry, type PendingTransferSku } from "./TransferBatchEntry";
import { TransferInlineMatrix } from "./TransferInlineMatrix";
import { TransferScanPanel } from "./TransferScanPanel";
import { downloadEmptyTransferXlsx, downloadTransferXlsx } from "./export";
import {
  appendTransferLines, asTransfer, makeTransferLine, newTransferDraft, transferCommandBody,
  transferDraftFrom, transferHeader, transferSummary, transferText, transferView, validateTransferDraft,
  warehouseIds, type TransferDocument, type TransferDraft,
} from "./model";
import "./transfers.css";

type Warehouse = {id: string; name: string; code?: string};
type Uncertain = {command: DocumentCommand; snapshot: string};
function currentDateTime() {
  const now = new Date(), part = (value: number) => String(value).padStart(2, "0");
  return `${now.getFullYear()}-${part(now.getMonth() + 1)}-${part(now.getDate())}T${part(now.getHours())}:${part(now.getMinutes())}`;
}
export function TransferEditorPage({id}: {id?: string}) {
  const [initialDraft] = useState<TransferDraft>(() => newTransferDraft(currentDateTime()));
  const [draft, setDraft] = useState<TransferDraft>(initialDraft);
  const [saved, setSaved] = useState<TransferDocument | null>(null), [savedSnapshot, setSavedSnapshot] = useState(JSON.stringify(initialDraft));
  const [loading, setLoading] = useState(Boolean(id)), [fatal, setFatal] = useState("");
  const [lookup, setLookup] = useState<SkuLookup | null>(null), [warehouses, setWarehouses] = useState<Warehouse[]>([]);
  const [referenceError, setReferenceError] = useState("");
  const [finderRefs, setFinderRefs] = useState<InventoryReferences | null>(null), [chosenKeys, setChosenKeys] = useState<string[]>([]);
  const [batchOpen, setBatchOpen] = useState(false), [batchProductId, setBatchProductId] = useState<string | null>(null), [scanOpen, setScanOpen] = useState(false);
  const [confirmLeave, setConfirmLeave] = useState(false), [leaveTarget, setLeaveTarget] = useState<string | null>(null);
  const [noteOpen, setNoteOpen] = useState(false);
  const [pending, setPending] = useState(false), [error, setError] = useState("");
  const [uncertain, setUncertain] = useState<Uncertain | null>(null), [conflict, setConflict] = useState(false);
  const [comparison, setComparison] = useState<TransferDocument | null>(null), [comparisonOpen, setComparisonOpen] = useState(false);
  const running = useRef(false), batchTrigger = useRef<HTMLButtonElement>(null), scanTrigger = useRef<HTMLButtonElement>(null), command = useMemo(() => new DocumentCommandController(api), []);
  const dirtyRef = useRef(false), allowNavigate = useRef(false), currentPath = useRef(window.location.pathname + window.location.search);
  function closeBatch() {setBatchOpen(false); requestAnimationFrame(() => batchTrigger.current?.focus());}
  function closeScan() {setScanOpen(false); requestAnimationFrame(() => scanTrigger.current?.focus());}
  useEffect(() => {
    let alive = true;
    void api.listReference<Warehouse>("warehouses", {page: 1, pageSize: 100})
      .then(page => {if (alive) setWarehouses(page.items);})
      .catch(issue => {if (alive) setReferenceError(issue instanceof Error ? issue.message : "仓库字典读取失败");});
    void loadSkuProjection().then(value => {if (alive) setLookup(value);})
      .catch(issue => {if (alive) setReferenceError(issue instanceof Error ? issue.message : "SKU 目录读取失败");});
    const finderAbort = new AbortController();
    void inventoryReferences(finderAbort.signal).then(value => {if (alive) setFinderRefs(value);})
      .catch(issue => {if (alive && !finderAbort.signal.aborted) setReferenceError(issue instanceof Error ? issue.message : "商品联想读取失败");});
    if (id) void api.getDocument(id).then(value => {
      if (!alive) return;
      const document = asTransfer(value);
      if (document.status === "APPROVED" || document.current_effect_active) {
        setFatal("已审核调拨不能直接编辑。请先在详情页弃审。"); setLoading(false); return;
      }
      const next = transferDraftFrom(document);
      setSaved(document); setDraft(next); setSavedSnapshot(JSON.stringify(next)); setLoading(false);
    }).catch(issue => {if (alive) {setFatal(issue instanceof Error ? issue.message : "调拨单读取失败"); setLoading(false);}});
    return () => {alive = false; finderAbort.abort();};
  }, [id]);
  const {from, to} = warehouseIds(draft.header, draft.lines);
  const dirty = JSON.stringify(draft) !== savedSnapshot || chosenKeys.some(key => !draft.lines.some(line => key === `${line.product_id}:${line.color_id}`));
  dirtyRef.current = dirty;
  useEffect(() => {
    const beforeRoute = (event: Event) => {
      const target = (event as CustomEvent<{target: string}>).detail.target;
      if (!dirtyRef.current || allowNavigate.current || target === currentPath.current) return;
      event.preventDefault(); setLeaveTarget(target); setConfirmLeave(true);
    };
    const beforeBack = () => {
      if (!dirtyRef.current || allowNavigate.current) return;
      const target = window.location.pathname + window.location.search;
      if (target === currentPath.current) return;
      window.history.pushState({}, "", currentPath.current);
      setLeaveTarget(target); setConfirmLeave(true);
    };
    const beforeUnload = (event: BeforeUnloadEvent) => {if (dirtyRef.current) {event.preventDefault(); event.returnValue = "";}};
    window.addEventListener("stage05:before-route", beforeRoute);
    window.addEventListener("popstate", beforeBack, true);
    window.addEventListener("beforeunload", beforeUnload);
    return () => {window.removeEventListener("stage05:before-route", beforeRoute); window.removeEventListener("popstate", beforeBack, true); window.removeEventListener("beforeunload", beforeUnload);};
  }, []);
  const summary = useMemo(() => {
    try {return transferSummary(draft.lines);}
    catch {return null;}
  }, [draft.lines]);
  const nameOf = (warehouseId: string) => warehouses.find(row => row.id === warehouseId)?.name || warehouseId || "未选择";
  function setWarehouse(kind: "from" | "to", value: string) {
    const key = kind === "from" ? "source_from_warehouse_id" : "source_to_warehouse_id";
    const lineKey = kind === "from" ? "from_warehouse_id" : "to_warehouse_id";
    setDraft(current => ({
      ...current, header: {...current.header, [key]: value},
      lines: current.lines.map(line => ({...line, [lineKey]: value})),
    }));
  }
  function appendPending(lines: PendingTransferSku[]): boolean {
    if (!from || !to) {setError("请先选择调出仓与调入仓"); return false;}
    if (from === to) {setError("调出仓和调入仓不能相同"); return false;}
    try {
      const additions = lines.map(item => makeTransferLine(item.reference, item.sku, from, to, item.quantity, item.productName));
      setDraft(current => ({...current, lines: appendTransferLines(current.lines, additions)}));
      setError(""); if (batchOpen) closeBatch();
      return true;
    } catch (issue) {setError(issue instanceof Error ? issue.message : "规格追加失败"); return false;}
  }
  function commandFailure(attempt: DocumentCommand, snapshot: string) {
    const state = command.getSnapshot();
    if (state.state !== "failure") return "命令未确认";
    if (state.kind === "network-uncertain") setUncertain({command: attempt, snapshot});
    if (state.kind === "version-conflict" || state.kind === "edit-lock-conflict") setConflict(true);
    return state.reason;
  }
  async function readAfterCommand(attempt: DocumentCommand, snapshot: string): Promise<TransferDocument> {
    try {return asTransfer(await api.getDocument(attempt.documentId));}
    catch {
      setUncertain({command: attempt, snapshot});
      throw Error("命令已提交，但服务端回读未确认；草稿和原 requestKey 已保留，请先核对命令结果。");
    }
  }
  async function saveOrApprove(approve: boolean) {
    if (running.current || uncertain) {if (uncertain) setError("上一笔命令结果未确认，请先核对原 requestKey。"); return;}
    const issue = validateTransferDraft(draft, lookup, new Set(warehouses.map(row => row.id)));
    if (issue) {setError(issue); return;}
    running.current = true; setPending(true); setError(""); setConflict(false);
    const snapshot = JSON.stringify(draft);
    try {
      let current = saved;
      if (!current) {
        const documentId = crypto.randomUUID();
        const attempt: DocumentCommand = {documentId, documentType: "TRANSFER", operation: "create", expectedVersion: 0, requestKey: newRequestKey(), body: transferCommandBody(draft)};
        if (!await command.submit(attempt)) throw Error(commandFailure(attempt, snapshot));
        current = await readAfterCommand(attempt, snapshot);
        setSaved(current); setSavedSnapshot(snapshot);
      } else if (dirty) {
        const attempt: DocumentCommand = {documentId: current.id, operation: "save", expectedVersion: current.version, requestKey: newRequestKey(), body: transferCommandBody(draft)};
        if (!await command.submit(attempt)) throw Error(commandFailure(attempt, snapshot));
        current = await readAfterCommand(attempt, snapshot);
        setSaved(current); setSavedSnapshot(snapshot);
      }
      if (approve) {
        const attempt: DocumentCommand = {documentId: current.id, operation: "approve", expectedVersion: current.version, requestKey: newRequestKey()};
        if (!await command.submit(attempt)) throw Error(commandFailure(attempt, snapshot));
        current = await readAfterCommand(attempt, snapshot);
        setSaved(current); setSavedSnapshot(snapshot);
        feedback.success("调拨已审核；双仓库存由服务端生效");
      } else feedback.success("草稿已保存；库存未改变");
      allowNavigate.current = true;
      navigate(`/transfers/${encodeURIComponent(current.id)}`);
    } catch (issue) {setError(issue instanceof Error ? issue.message : "调拨命令未完成，草稿已保留");}
    finally {running.current = false; setPending(false);}
  }
  async function reconcile() {
    if (!uncertain || running.current) return;
    running.current = true; setPending(true); setError("");
    try {
      let current: TransferDocument | null = null;
      try {current = asTransfer(await command.readCurrentDocument(uncertain.command.documentId));}
      catch (issue) {if (!(issue instanceof ApiError && issue.kind === "not-found" && uncertain.command.operation === "create")) throw issue;}
      if (!current || current.version === uncertain.command.expectedVersion) {
        if (!await command.submit(uncertain.command)) throw Error(command.getSnapshot().state === "failure" ? (command.getSnapshot() as {reason: string}).reason : "原命令仍未确认");
        current = asTransfer(await command.readCurrentDocument(uncertain.command.documentId));
      }
      const matched = (current.history || []).some(raw => (raw as {request_key?: string}).request_key === uncertain.command.requestKey);
      if (!matched) throw Error("服务器版本已变化，原命令未确认；草稿仍在，请查看服务器版本后处理。");
      setSaved(current); setSavedSnapshot(uncertain.snapshot); setUncertain(null); setConflict(false);
      feedback.success("已核对原 requestKey 与服务端版本");
      if (current.status === "APPROVED") navigate(`/transfers/${encodeURIComponent(current.id)}`);
    } catch (issue) {setError(issue instanceof Error ? issue.message : "命令结果仍未确认");}
    finally {running.current = false; setPending(false);}
  }
  async function compareServer() {
    if (!saved) return;
    try {setComparison(asTransfer(await api.getDocument(saved.id))); setComparisonOpen(true);}
    catch (issue) {setError(issue instanceof Error ? issue.message : "服务器版本读取失败，草稿仍保留");}
  }
  async function exportDraft() {
    try {
      if (!draft.lines.length) {
        await downloadEmptyTransferXlsx(draft, saved?.number || "未生成", new Map(warehouses.map(row => [row.id, row.name || row.code || row.id])));
        feedback.success("已导出当前空白调拨矩阵");
        return;
      }
      if (!lookup) {setError("SKU 目录尚未加载，稍后再试"); return;}
      const exportDocument = {...(saved || {id: "unsaved", document_type: "TRANSFER", number: "未生成", status: "DRAFT", version: 0}), body: draft} as TransferDocument;
      await downloadTransferXlsx(transferView(exportDocument, lookup), new Map(warehouses.map(row => [row.id, row.name || row.code || row.id])));
      feedback.success("已导出本次调拨矩阵");
    } catch (issue) {setError(issue instanceof Error ? issue.message : "导出失败");}
  }
  const validationIssue = validateTransferDraft(draft, lookup, new Set(warehouses.map(row => row.id)));
  const warehouseIssue = !from || !to ? "请先选择调出仓与调入仓，再追加数量" : from === to ? "调出仓和调入仓不能相同" : "";
  const unitTotals = new Map<string, number>();
  for (const line of draft.lines) {
    const unit = transferText(line.unit) || "件";
    unitTotals.set(unit, (unitTotals.get(unit) || 0) + Number(line.source_quantity));
  }
  const totalLabel = [...unitTotals].map(([unit, count]) => count.toLocaleString("zh-CN") + " " + unit).join(" + ") || "0";
  const statusLabel = saved?.status === "UNAUDITED" ? "已弃审" : saved?.status === "APPROVED" ? "已审核" : saved?.status === "DRAFT" ? "草稿" : "未审核";
  if (loading) return <div className="lr-transfer-empty" role="status">正在读取调拨单…</div>;
  if (fatal) return <section className="lr-transfer-workbench"><div className="lr-transfer-head"><h1>编辑受限</h1><Button onClick={() => navigate(id ? "/transfers/" + encodeURIComponent(id) : "/transfers")}>返回</Button></div><Alert type="warning" showIcon content={fatal} /></section>;
  return <>
    <section className="lr-transfer-workbench lr-transfer-editor">
      <div className="lr-transfer-head">
        <h1>{id ? "编辑调拨单" : "新增调拨单"}</h1>
        <span className="lr-transfer-status">{statusLabel}</span>
        <span className="lr-transfer-save-state">{dirty ? "· 有未保存修改" : saved ? "· 已保存" : "· 未保存"}</span>
        <div className="lr-transfer-head-actions">
          <Button onClick={() => navigate("/transfers")}>返回列表</Button>
          <Button loading={pending} disabled={!!uncertain} onClick={() => void saveOrApprove(false)}>保存未审核单</Button>
          <Button type="primary" loading={pending} disabled={!!uncertain} onClick={() => void saveOrApprove(true)}>审核</Button>
          <Dropdown trigger="click" droplist={<Menu onClickMenuItem={key => {
            if (key === "note") setNoteOpen(true);
            if (key === "history" && saved) navigate("/transfers/" + encodeURIComponent(saved.id));
          }}><Menu.Item key="note">备注</Menu.Item>{saved && <Menu.Item key="history">操作历史</Menu.Item>}</Menu>}>
            <Button>更多操作</Button>
          </Dropdown>
        </div>
      </div>
      <div className="lr-transfer-doc-header">
        <div className="lr-transfer-direction">
          <label>调出仓<Select aria-label="调出仓" showSearch value={from} placeholder="请选择" options={warehouses.map(row => ({label: row.name || row.code || row.id, value: row.id, disabled: row.id === to}))} onChange={value => setWarehouse("from", String(value || ""))} /></label>
          <span aria-hidden="true">→</span>
          <label>调入仓<Select aria-label="调入仓" showSearch value={to} placeholder="请选择" options={warehouses.map(row => ({label: row.name || row.code || row.id, value: row.id, disabled: row.id === from}))} onChange={value => setWarehouse("to", String(value || ""))} /></label>
        </div>
        <label className="lr-transfer-date-label">单据日期<DatePicker aria-label="单据日期" showTime={{format: "HH:mm"}} format="YYYY-MM-DD HH:mm" value={(transferHeader(draft.header, "business_date").length === 10 ? `${transferHeader(draft.header, "business_date")}T00:00` : transferHeader(draft.header, "business_date")).replace("T", " ")} onChange={value => setDraft(current => ({...current, header: {...current.header, business_date: value.replace(" ", "T")}}))} />{saved?.baseline_was_included && transferHeader(saved.body.header, "business_date").length === 10 && <small>历史日期来源未提供时分</small>}</label>
        <div className="lr-transfer-meta"><span>单号：{saved?.number || "未生成"}</span><span>创建者：{saved?.baseline_was_included ? transferHeader(saved.body.header, "created_by") || "历史未提供" : "管理员"}</span>{saved && <span>最后修改：{saved.updated_at ? new Date(saved.updated_at).toLocaleString("zh-CN", {hour12: false}) : "历史未提供"}</span>}</div>
        <div className="lr-transfer-entry-actions">
          <Button ref={batchTrigger} disabled={pending || !!uncertain} onClick={() => {setBatchProductId(null); setBatchOpen(true);}}>批量录入</Button>
          <Button ref={scanTrigger} disabled={pending || !!uncertain} onClick={() => setScanOpen(true)}>扫码录入（0）</Button>
          <Button disabled={pending} onClick={() => void exportDraft()}>导出</Button>
        </div>
      </div>
      {referenceError && <Alert type="error" showIcon content={referenceError} />}
      {error && <Alert type="error" showIcon title={conflict ? "版本冲突或编辑锁，草稿已保留" : "请核对当前操作"} content={<Space wrap>{error}{conflict && <Button size="small" onClick={() => void compareServer()}>读取服务器版本并对比</Button>}</Space>} />}
      {uncertain && <Alert type="warning" showIcon title="网络结果未确认" content={<Space wrap>草稿与原 requestKey 已保留；不能发起新命令。<Button size="small" loading={pending} onClick={() => void reconcile()}>核对并重试原命令</Button></Space>} />}
      {from && to && from === to && <Alert type="error" showIcon content="调入仓不能与调出仓相同" />}
      <div className="lr-transfer-layout">
        <div className="lr-transfer-main">
          <div className="lr-transfer-section-head"><strong>调拨明细</strong><span>{validationIssue && draft.lines.length ? validationIssue : "空白或 0 不调拨"}</span></div>
          <TransferInlineMatrix draft={draft} lookup={lookup} finderRefs={finderRefs} from={from} to={to} onDraft={setDraft} onError={setError} onChosenChange={setChosenKeys} />
          <div className="lr-transfer-total">本次调拨：<strong>{summary?.productCount || 0}</strong>款 · 共 <strong>{totalLabel}</strong></div>
        </div>
      </div>
    </section>
    <TransferBatchEntry visible={batchOpen} lookup={lookup} existing={draft.lines} initialProductId={batchProductId} warehouseIssue={warehouseIssue} onCancel={closeBatch} onAppend={appendPending} />
    <TransferScanPanel visible={scanOpen} lookup={lookup} warehouseIssue={warehouseIssue} onCancel={closeScan} onAppend={appendPending} onSelectProduct={productId => {setScanOpen(false); setBatchProductId(productId); setBatchOpen(true);}} />
    <Modal title="当前有未保存的修改" visible={confirmLeave} onCancel={() => {setConfirmLeave(false); setLeaveTarget(null);}} onOk={() => {const target = leaveTarget || "/transfers"; setConfirmLeave(false); setLeaveTarget(null); allowNavigate.current = true; navigate(target);}} okText="确定离开" cancelText="继续录入" maskClosable={false}>当前有未保存的修改，确定离开吗？</Modal>
    <Modal title="调拨备注" visible={noteOpen} onCancel={() => setNoteOpen(false)} onOk={() => setNoteOpen(false)} okText="确定"><Input.TextArea aria-label="调拨备注" value={transferHeader(draft.header, "note")} onChange={note => setDraft(current => ({...current, header: {...current.header, note}}))} rows={3} /></Modal>
    <Modal visible={comparisonOpen} title="服务器版本与当前草稿" footer={<Button onClick={() => setComparisonOpen(false)}>关闭并继续编辑草稿</Button>} onCancel={() => setComparisonOpen(false)}>
      {comparison && <Descriptions column={1} data={[
        {label: "本地基于版本", value: saved?.version ?? "未保存"}, {label: "服务器当前版本", value: comparison.version},
        {label: "本地草稿", value: nameOf(from) + " → " + nameOf(to) + "；数量 " + (summary?.quantity ?? "待修正")},
        {label: "服务器已保存", value: nameOf(warehouseIds(comparison.body.header, comparison.body.lines).from) + " → " + nameOf(warehouseIds(comparison.body.header, comparison.body.lines).to) + "；数量 " + transferSummary(comparison.body.lines).quantity},
      ]} />}
      <Alert type="warning" showIcon content="本地草稿未被服务器版本覆盖。核对差异后可返回列表重新打开，或手动保留录入内容。" />
    </Modal>
  </>;
}
