import { useEffect, useMemo, useState } from "react";
import { Button, Input, Modal, Select } from "@arco-design/web-react";
import { type DisplaySku, type SkuCell, type SkuLookup } from "@stage05";
import { InventoryFinder } from "../inventory/InventoryFinder";
import type { InventoryReferences } from "../inventory/data";
import { legacySkuOrder } from "../inventory/legacySkuOrder";
import { makeTransferLine, transferText, type TransferDraft } from "./model";

type ChosenColor = {productId: string; colorId: string};
const keyOf = (productId: string, colorId: string) => `${productId}:${colorId}`;
export function TransferInlineMatrix({draft, lookup, finderRefs, from, to, onDraft, onError, onChosenChange}: {
  draft: TransferDraft; lookup: SkuLookup | null; finderRefs: InventoryReferences | null;
  from: string; to: string; onDraft: (draft: TransferDraft) => void; onError: (message: string) => void;
  onChosenChange?: (keys: string[]) => void;
}) {
  const [chosen, setChosen] = useState<ChosenColor[]>([]);
  const [query, setQuery] = useState(""), [productCode, setProductCode] = useState(""), [colorId, setColorId] = useState("");
  const [removeKey, setRemoveKey] = useState<string | null>(null);
  useEffect(() => {
    const seen = new Set(chosen.map(row => keyOf(row.productId, row.colorId)));
    const additions = draft.lines.filter(line => !seen.has(keyOf(line.product_id, line.color_id))).map(line => ({productId: line.product_id, colorId: line.color_id}));
    if (additions.length) setChosen(current => [...current, ...additions]);
  }, [draft.lines]);
  const chosenSignature = chosen.map(row => keyOf(row.productId, row.colorId)).join("|");
  useEffect(() => {onChosenChange?.(chosenSignature ? chosenSignature.split("|") : []);}, [chosenSignature]);
  const productIdentity = productCode ? lookup?.productByCode(productCode) : null;
  const skus = productIdentity && lookup ? legacySkuOrder(lookup.skusForProduct(productIdentity.productId).filter(sku => sku.sourceEnabled)) : [];
  const colors = [...new Map(skus.map(sku => [sku.color.colorId, sku.color])).values()];
  const quantities = useMemo(() => Object.fromEntries(draft.lines.map(line => [line.sku_id, transferText(line.source_quantity)])), [draft.lines]);
  const matrix = useMemo(() => {
    if (!lookup || !chosen.length) return null;
    try {return lookup.matrixForProducts([...new Set(chosen.map(row => row.productId))], quantities);}
    catch {return null;}
  }, [lookup, chosen, quantities]);
  const chosenKeys = new Set(chosen.map(row => keyOf(row.productId, row.colorId)));
  function addColor(productId: string, selectedColor: string) {
    const key = keyOf(productId, selectedColor);
    setChosen(current => current.some(row => keyOf(row.productId, row.colorId) === key) ? current : [...current, {productId, colorId: selectedColor}]);
    setQuery(""); setProductCode(""); setColorId(""); onError("");
    requestAnimationFrame(() => document.querySelector<HTMLElement>(`[data-transfer-row="${key}"] input`)?.focus());
  }
  function pick(code: string, skuId: string | null) {
    const identity = lookup?.productByCode(code);
    if (!identity) {onError("商品未进入正式 SKU 目录"); return;}
    const sku = skuId ? lookup?.skuById(skuId) : null;
    setProductCode(code); setQuery(code);
    if (sku?.product.productId === identity.productId) {addColor(identity.productId, sku.color.colorId); return;}
    const active = legacySkuOrder(lookup!.skusForProduct(identity.productId).filter(item => item.sourceEnabled));
    const choices = [...new Set(active.map(item => item.color.colorId))];
    if (choices.length === 1) addColor(identity.productId, choices[0]!);
    else requestAnimationFrame(() => document.querySelector<HTMLElement>('[aria-label="本行调拨颜色"]')?.focus());
  }
  function updateCell(cell: SkuCell, value: string) {
    if (!cell.skuId || !lookup) return;
    if (value !== "" && (!/^\d+$/.test(value) || Number(value) > 99999)) {onError("数量须为 0–99999 的整数"); return;}
    if (!from || !to || from === to) {onError("请先选择不同的调出仓和调入仓"); return;}
    const sku = lookup.skuById(cell.skuId);
    if (!sku) {onError("原 SKU 身份未找到"); return;}
    const existing = draft.lines.find(line => line.sku_id === cell.skuId);
    let lines = draft.lines;
    if (value === "" || value === "0") lines = lines.filter(line => line.sku_id !== cell.skuId);
    else if (existing) lines = lines.map(line => line.source_id === existing.source_id ? {...line, source_quantity: value} : line);
    else {
      const reference = lookup.inputReference(cell);
      const name = finderRefs?.catalog.products.find(item => item.code === sku.product.sourceCode)?.name || "";
      lines = [...lines, makeTransferLine(reference, sku, from, to, value, name)];
    }
    onDraft({...draft, lines}); onError("");
  }
  function removeColor() {
    if (!removeKey) return;
    const [productId, colorId] = removeKey.split(":");
    setChosen(current => current.filter(row => keyOf(row.productId, row.colorId) !== removeKey));
    onDraft({...draft, lines: draft.lines.filter(line => !(line.product_id === productId && line.color_id === colorId))});
    setRemoveKey(null);
  }
  return <div className="lr-transfer-matrix-scroll" aria-label="调拨数量矩阵，可横向与纵向滚动">
    {matrix?.sections.map(section => {
      const rows = section.rows.filter(row => chosenKeys.has(keyOf(row.product.productId, row.color.colorId)));
      if (!rows.length) return null;
      return <section key={section.group.name} className="lr-transfer-matrix-section" data-size-system={section.group.name}>
        <table className="lr-transfer-matrix" style={{minWidth: 518 + section.group.columns.length * 76}}>
          <colgroup><col style={{width: 240}} /><col style={{width: 92}} />{section.group.columns.map(column => <col key={column.key} />)}<col style={{width: 76}} /><col style={{width: 110}} /></colgroup>
          <thead><tr><th className="lr-transfer-matrix-product">商品名称／款号</th><th className="lr-transfer-matrix-color">颜色</th>{section.group.columns.map(column => <th key={column.key}>{column.name}</th>)}<th className="lr-transfer-matrix-subtotal">小计</th><th className="lr-transfer-matrix-action">操作</th></tr></thead>
          <tbody>{rows.map(row => {
            const rowKey = keyOf(row.product.productId, row.color.colorId);
            const name = draft.lines.find(line => line.product_id === row.product.productId)?.source_product_name || finderRefs?.catalog.products.find(item => item.code === row.product.sourceCode)?.name || "";
            return <tr key={rowKey} data-transfer-row={rowKey}>
              <td className="lr-transfer-matrix-product"><strong>{row.product.sourceCode}</strong> <span title={transferText(name)}>{transferText(name)}</span></td>
              <td className="lr-transfer-matrix-color">{row.color.name}</td>
              {row.cells.map(cell => <td key={cell.column.key}>{cell.missing ? <span className="lr-transfer-matrix-missing">—</span> : cell.entries.map(entry => <div key={entry.skuId || cell.column.key} className="lr-transfer-matrix-spec">
                {cell.entries.length > 1 && <small>{entry.originalIdentity.sourceSizeName || entry.fit?.code}</small>}
                {entry.skuId && entry.editable ? <Input aria-label={`${row.product.sourceCode} ${row.color.name} ${cell.column.name} 本次调拨数量`} inputMode="numeric" value={quantities[entry.skuId] || ""} onChange={value => updateCell(entry, value)} onKeyDown={event => {
                  if (event.key !== "Enter" && event.key !== "Tab") return;
                  event.preventDefault(); const inputs = [...document.querySelectorAll<HTMLInputElement>(".lr-transfer-matrix-spec input:not(:disabled)")], index = inputs.indexOf(event.currentTarget as HTMLInputElement);
                  (inputs[index + (event.shiftKey ? -1 : 1)] || document.querySelector<HTMLElement>('[aria-label="调拨行内找货"]'))?.focus();
                }} /> : <span className="lr-transfer-matrix-missing">—</span>}
              </div>)}</td>)}
              <td className="lr-transfer-matrix-subtotal">{row.subtotal.signedQuantity}</td>
              <td className="lr-transfer-matrix-action"><Button type="text" aria-label={`查看商品详情 ${row.product.sourceCode}`} onClick={() => window.open(`/products/${encodeURIComponent(row.product.sourceCode)}`, "_blank", "noopener,noreferrer")}>▤</Button><Button type="text" onClick={() => setRemoveKey(rowKey)}>移除</Button></td>
            </tr>;
          })}</tbody>
        </table>
      </section>;
    })}
    <table className="lr-transfer-matrix lr-transfer-entry-table"><tbody><tr>
      <td className="lr-transfer-matrix-product"><InventoryFinder value={query} refs={finderRefs} showHistory={false} onChange={value => {setQuery(value); setProductCode(""); setColorId("");}} onSelect={pick} onSubmit={() => {const exact = finderRefs?.catalog.products.find(item => item.code.toLowerCase() === query.toLowerCase()); if (exact) pick(exact.code, null);}} /></td>
      <td className="lr-transfer-matrix-color"><Select aria-label="本行调拨颜色" disabled={!productIdentity} value={colorId} placeholder="请选择颜色" options={colors.map(color => ({label: color.name, value: color.colorId}))} onChange={value => {const selected = String(value); setColorId(selected); if (productIdentity) addColor(productIdentity.productId, selected);}} /></td>
      <td className="lr-transfer-entry-hint">选择商品和颜色后，在对应尺码格填写本次调拨数量</td>
    </tr></tbody></table>
    <Modal visible={Boolean(removeKey)} title="移除颜色行" onCancel={() => setRemoveKey(null)} onOk={removeColor} okText="确认移除" maskClosable={false}>该颜色行的本次调拨数量也会移除。</Modal>
  </div>;
}
