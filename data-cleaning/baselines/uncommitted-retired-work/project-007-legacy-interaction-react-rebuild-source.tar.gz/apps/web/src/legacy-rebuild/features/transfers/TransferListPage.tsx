import { useEffect, useMemo, useRef, useState } from "react";
import { Button, DatePicker, Input, Pagination, Select, Table, Tag } from "@arco-design/web-react";
import { api, navigate, readListReturn, saveListReturn, usePagedQuery, type PageRequest } from "@stage05";
import { EntityPicker } from "../sales/EntityPicker";
import { asTransfer, transferHeader, transferSummary, transferText, warehouseIds, type TransferDocument } from "./model";
import "./transfers.css";

type Warehouse = {id: string; name: string; code?: string};
type Filter = {q: string; start: string; end: string; from: string[]; to: string[]; status: string};
const INITIAL: Filter = {q: "", start: "", end: "", from: [], to: [], status: ""};
const multi = (value: unknown): string[] => Array.isArray(value) ? value.map(String) : value ? [String(value)] : [];
export const transferFiltersFromUrl = (search: string): {filter: Filter; page: number} | null => {
  const params = new URLSearchParams(search);
  if (!["q", "number", "start", "end", "from", "to", "status", "page"].some(key => params.has(key))) return null;
  const page = Number(params.get("page"));
  return {filter: {q: params.get("q") || params.get("number") || "", start: params.get("start") || "", end: params.get("end") || "", from: params.getAll("from"), to: params.getAll("to"), status: params.get("status") || ""}, page: Number.isSafeInteger(page) && page > 0 ? page : 1};
};
export function transferListUrl(filter: Filter, page: number): string {
  const params = new URLSearchParams();
  for (const key of ["q", "start", "end", "status"] as const) if (filter[key]) params.set(key, filter[key]);
  for (const key of ["from", "to"] as const) for (const id of filter[key]) params.append(key, id);
  if (page > 1) params.set("page", String(page));
  return "/transfers" + (params.size ? "?" + params : "");
}
const fetchTransfers = async ({applied, page, pageSize, signal}: PageRequest<Filter>) => {
  const result = await api.listRuntimeDocuments("TRANSFER", {page, pageSize, filters: {
    number: applied.q.trim(), start: applied.start, end: applied.end,
    from: applied.from, to: applied.to, status: applied.status,
  }}, signal);
  return {items: result.items.map(asTransfer).sort((a, b) => (Date.parse(b.updated_at || "") || 0) - (Date.parse(a.updated_at || "") || 0) || a.number.localeCompare(b.number)), total: result.total};
};
function goodsSummary(item: TransferDocument, categories: Map<string, string>): string {
  const products = new Map<string, string>();
  for (const line of item.body.lines) {
    const code = transferText(line.source_product_code);
    if (code && !products.has(code)) products.set(code, categories.get(code) || transferText(line.source_product_name) || code);
  }
  const groups = new Map<string, number>();
  for (const name of products.values()) groups.set(name, (groups.get(name) || 0) + 1);
  const parts = [...groups].map(([name, count]) => `${name}${count}`);
  if (!parts.length) return "货品来源未提供";
  const shown = [...groups].slice(0, 2).reduce((sum, [, count]) => sum + count, 0);
  return parts.length > 2 ? `${parts.slice(0, 2).join(" · ")} · +${products.size - shown}款` : parts.join(" · ");
}
function statusName(item: TransferDocument) {
  return item.status === "APPROVED" ? "已审核" : item.status === "DRAFT" ? "未审核" : item.status === "UNAUDITED" ? "已弃审" : "状态未提供";
}
function person(item: TransferDocument, kind: "created" | "audited") {
  const explicit = transferHeader(item.body.header, kind === "created" ? "created_by" : "audited_by") || (kind === "audited" ? transferText(item.original_auditor) : "");
  if (explicit) return explicit === "local-admin" ? "管理员" : explicit;
  return !item.baseline_was_included && kind === "created" ? "管理员" : "—";
}
export function TransferListPage() {
  const {state, controller} = usePagedQuery<Filter, TransferDocument>(INITIAL, 20, fetchTransfers);
  const [warehouses, setWarehouses] = useState<Warehouse[]>([]), [categories, setCategories] = useState(new Map<string, string>());
  const [referenceError, setReferenceError] = useState(""), [dateError, setDateError] = useState("");
  const scroll = useRef<HTMLDivElement>(null), restoredScroll = useRef(false);
  useEffect(() => {
    const abort = new AbortController();
    void Promise.all([
      api.listReference<Warehouse>("warehouses", {page: 1, pageSize: 100}, abort.signal),
      api.getRuntimeCatalog<{products: Array<{code: string; category_name?: string | null}>}>(abort.signal),
    ]).then(([page, catalog]) => {if (!abort.signal.aborted) {setWarehouses(page.items); setCategories(new Map(catalog.products.map(product => [product.code, product.category_name || ""])));}})
      .catch(error => {if (!abort.signal.aborted) setReferenceError(error instanceof Error ? error.message : "调拨基础资料读取失败");});
    const fromUrl = transferFiltersFromUrl(window.location.search), remembered = readListReturn("transfers");
    if (fromUrl) void controller.restore(fromUrl.filter, fromUrl.page);
    else if (remembered) {
      const old = remembered.applied as Partial<Filter> & {number?: string};
      void controller.restore({...INITIAL, ...old, q: old.q || old.number || "", from: multi(old.from), to: multi(old.to)}, 1);
    } else void controller.reload();
    return () => abort.abort();
  }, [controller]);
  useEffect(() => {if (state.hasExecuted) window.history.replaceState({}, "", transferListUrl(state.applied, state.page));}, [state.applied, state.page, state.hasExecuted]);
  useEffect(() => {
    if (restoredScroll.current || !state.hasExecuted || state.loading !== "idle") return;
    restoredScroll.current = true;
    const remembered = readListReturn("transfers");
    if (remembered?.url === window.location.pathname + window.location.search) requestAnimationFrame(() => {if (scroll.current) scroll.current.scrollTop = remembered.scrollY;});
  }, [state.hasExecuted, state.loading]);
  const warehouseNames = useMemo(() => new Map(warehouses.map(item => [item.id, item.name || item.code || item.id])), [warehouses]);
  const warehouseOptions = warehouses.map(item => ({id: item.id, name: item.name || item.code || item.id}));
  function open(path: string) {
    window.history.replaceState({}, "", transferListUrl(state.applied, state.page));
    saveListReturn("transfers", state.applied, scroll.current?.scrollTop || 0);
    navigate(path);
  }
  const f = state.draft, dirty = JSON.stringify(f) !== JSON.stringify(state.applied), pages = Math.max(1, Math.ceil(state.total / 20));
  function setDraft(patch: Partial<Filter>) {controller.setDraft({...f, ...patch}); setDateError("");}
  function query(event?: React.FormEvent) {
    event?.preventDefault();
    if (f.start && f.end && f.start > f.end) {setDateError("开始日期不能晚于结束日期"); return;}
    scroll.current?.scrollTo({top: 0}); void controller.apply();
  }
  function reset() {setDateError(""); scroll.current?.scrollTo({top: 0}); void controller.reset();}
  const columns = [
    {title: "日期", key: "date", render: (_: unknown, item: TransferDocument) => <>{transferHeader(item.body.header, "business_date").replace("T", " ") || "历史未提供"}{transferHeader(item.body.header, "business_date").length === 10 && <small>时分未记录</small>}</>},
    {title: "调拨单号", key: "number", render: (_: unknown, item: TransferDocument) => <Button type="text" className="lr-transfer-number" onClick={() => open(`/transfers/${encodeURIComponent(item.id)}`)}>{item.number}</Button>},
    {title: "货品信息", key: "goods", render: (_: unknown, item: TransferDocument) => <span className="lr-transfer-goods" title={goodsSummary(item, categories)}>{goodsSummary(item, categories)}</span>},
    {title: "调出仓", key: "from", render: (_: unknown, item: TransferDocument) => {const id = warehouseIds(item.body.header, item.body.lines).from; return warehouseNames.get(id) || id || "未提供";}},
    {title: "调入仓", key: "to", render: (_: unknown, item: TransferDocument) => {const id = warehouseIds(item.body.header, item.body.lines).to; return warehouseNames.get(id) || id || "未提供";}},
    {title: "状态", key: "status", render: (_: unknown, item: TransferDocument) => <Tag className="lr-transfer-state">{statusName(item)}</Tag>},
    {title: "总数量", key: "quantity", align: "right" as const, render: (_: unknown, item: TransferDocument) => Number(transferSummary(item.body.lines).quantity).toLocaleString("zh-CN")},
    {title: "创建者", key: "creator", render: (_: unknown, item: TransferDocument) => person(item, "created")},
    {title: "审核人", key: "auditor", render: (_: unknown, item: TransferDocument) => person(item, "audited")},
    {title: "最后更新", key: "updated", render: (_: unknown, item: TransferDocument) => item.updated_at ? new Date(item.updated_at).toLocaleString("zh-CN", {hour12: false}) : "历史未提供"},
    {title: "操作", key: "action", render: (_: unknown, item: TransferDocument) => <Button size="small" onClick={() => open(`/transfers/${encodeURIComponent(item.id)}`)}>查看</Button>},
  ];
  return <section className="lr-transfer-workbench lr-transfer-list">
    <div className="lr-transfer-head"><h1>调拨单列表</h1><Button type="primary" onClick={() => open("/transfers/new")}>新增调拨单</Button></div>
    <form className="lr-transfer-filters" onSubmit={query}>
      <label>日期<DatePicker aria-label="开始日期" {...(f.start ? {value: f.start} : {})} onChange={start => setDraft({start})} /></label>
      <label>至<DatePicker aria-label="结束日期" {...(f.end ? {value: f.end} : {})} onChange={end => setDraft({end})} /></label>
      <Input aria-label="调拨单号" value={f.q} placeholder="调拨单号" onChange={q => setDraft({q})} />
      <EntityPicker label="调出仓" items={warehouseOptions} value={f.from} multiple allLabel="全部" onChange={from => setDraft({from: multi(from)})} />
      <EntityPicker label="调入仓" items={warehouseOptions} value={f.to} multiple allLabel="全部" onChange={to => setDraft({to: multi(to)})} />
      <Select aria-label="筛选单据状态" value={f.status} options={[{label: "全部状态", value: ""}, {label: "未审核", value: "DRAFT"}, {label: "已生效", value: "APPROVED"}, {label: "已弃审", value: "UNAUDITED"}]} onChange={status => setDraft({status: String(status || "")})} />
      <Button htmlType="submit" type="primary" loading={state.loading !== "idle"}>查询</Button><Button onClick={reset}>重置</Button>
    </form>
    <div className="lr-transfer-query-note" data-pending={dirty} role={dateError || referenceError ? "alert" : "status"}>{dateError || referenceError || (dirty ? "条件已修改，点击“查询”更新结果。" : "修改条件后点击“查询”；“重置”恢复全部结果。")}</div>
    <div ref={scroll} className="lr-transfer-list-scroll">{state.loading === "initial" ? <div className="lr-transfer-empty">正在查询…</div> : state.error && !state.stale ? <div className="lr-transfer-empty" role="alert">{state.error.message} <Button onClick={() => void controller.reload()}>重试</Button></div> : <><Table className="lr-transfer-list-table" rowKey="id" columns={columns} data={state.items} pagination={false} tableLayoutFixed={false} scroll={{x: 1500}} size="small" border={{wrapper: false, cell: false}} noDataElement={<div className="lr-transfer-empty">没有符合条件的调拨单</div>} />{state.error && <div role="alert">读取失败，保留上次结果：{state.error.message} <Button onClick={() => void controller.reload()}>重试</Button></div>}</>}</div>
    <footer className="lr-transfer-pagination"><span>共 {state.total} 张调拨单 · 每页 {state.pageSize} 张</span><nav aria-label="调拨列表分页"><Pagination current={state.page} pageSize={state.pageSize} total={state.total} size="small" bufferSize={1} itemRender={(page, type, origin) => type === "prev" ? "上一页" : type === "next" ? "下一页" : origin} onChange={page => void controller.setPage(page)} /><span>第 {state.page} / {pages} 页</span></nav></footer>
  </section>;
}
