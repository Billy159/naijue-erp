import { Button } from "@arco-design/web-react";
import type { TransferView } from "./model";

export function TransferMatrix({view, print = false}: {view: TransferView; print?: boolean}) {
  const productNames = new Map(view.lines.map(({line}) => [line.product_id, String(line.source_product_name || "")]));
  return <div className={print ? "lr-transfer-read-matrix is-print" : "lr-transfer-read-matrix"}>
    {view.matrix.sections.map(section => <section className="lr-transfer-matrix-section" data-size-system={section.group.name} key={section.group.name}>
      <table className="lr-transfer-matrix" style={{minWidth: 518 + section.group.columns.length * 76}}>
        <colgroup><col style={{width: 240}} /><col style={{width: 92}} />{section.group.columns.map(column => <col key={column.key} />)}<col style={{width: 76}} />{!print && <col style={{width: 110}} />}</colgroup>
        <thead><tr><th className="lr-transfer-matrix-product">商品名称／款号</th><th className="lr-transfer-matrix-color">颜色</th>{section.group.columns.map(column => <th key={column.key}>{column.name}</th>)}<th className="lr-transfer-matrix-subtotal">小计</th>{!print && <th className="lr-transfer-matrix-action">操作</th>}</tr></thead>
        <tbody>{section.rows.map(row => <tr key={row.product.productId + ":" + row.color.colorId}>
          <td className="lr-transfer-matrix-product"><strong>{row.product.sourceCode}</strong> <span title={productNames.get(row.product.productId) || ""}>{productNames.get(row.product.productId) || "名称未提供"}</span></td>
          <td className="lr-transfer-matrix-color">{row.color.name}</td>
          {row.cells.map(cell => <td key={cell.column.key}>{cell.missing ? <span className="lr-transfer-matrix-missing">—</span> : cell.entries.map(entry => <div className="lr-transfer-matrix-spec" key={entry.skuId || cell.column.key}>{cell.entries.length > 1 && <small>{entry.originalIdentity.sourceSizeName || entry.fit?.code}</small>}{entry.displayValue ?? "0"}</div>)}</td>)}
          <td className="lr-transfer-matrix-subtotal">{row.subtotal.signedQuantity}</td>
          {!print && <td className="lr-transfer-matrix-action"><Button type="text" aria-label={"查看商品详情 " + row.product.sourceCode} onClick={() => window.open("/products/" + encodeURIComponent(row.product.sourceCode), "_blank", "noopener,noreferrer")}>▤</Button></td>}
        </tr>)}</tbody>
      </table>
    </section>)}
  </div>;
}
