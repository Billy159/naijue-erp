import { useRef, useState } from "react";
import { Alert, Button, Input, Modal, Space, Typography } from "@arco-design/web-react";
import { parseSignedQuantity, type SkuLookup } from "@stage05";
import type { PendingTransferSku } from "./TransferBatchEntry";

export function TransferScanPanel({visible, lookup, warehouseIssue, onCancel, onAppend, onSelectProduct}: {
  visible: boolean; lookup: SkuLookup | null; onCancel: () => void;
  warehouseIssue: string; onAppend: (lines: PendingTransferSku[]) => boolean; onSelectProduct: (productId: string) => void;
}) {
  const [code, setCode] = useState(""), [quantity, setQuantity] = useState("1");
  const [message, setMessage] = useState<{type: "info" | "warning" | "error"; text: string} | null>(null);
  const [productId, setProductId] = useState<string | null>(null);
  const lastEvent = useRef({code: "", time: 0});
  function scan(value: string) {
    const barcode = value.trim();
    if (!barcode) return;
    const now = Date.now();
    if (lastEvent.current.code === barcode && now - lastEvent.current.time < 500) return;
    lastEvent.current = {code: barcode, time: now};
    setProductId(null);
    if (!lookup) {setMessage({type: "error", text: "SKU 目录尚未加载"}); return;}
    try {
      if (parseSignedQuantity(quantity) === 0n) throw Error("扫码追加数量不能为 0");
      const result = lookup.barcode(barcode);
      if (result.kind === "not-found") setMessage({type: "error", text: "未找到条码；不会猜测未生成条码的 SKU。"});
      else if (result.kind === "ambiguous") setMessage({type: "warning", text: `条码关联 ${result.skuIds.length} 个 SKU、${result.productIds.length} 件商品。请核对来源后手动选规格。`});
      else if (result.kind === "product-only") {
        if (result.productIds.length === 1) setProductId(result.productIds[0]!);
        setMessage({type: "info", text: result.productIds.length === 1 ? `只定位到商品 ${lookup.productById(result.productIds[0]!)?.sourceCode || ""}；请在矩阵中选择具体规格。` : "商品级条码关联多个商品，不能自动追加 SKU。"});
      } else {
        const sku = result.sku;
        const cell = lookup.matrixForProduct(sku.product.productId).sections.flatMap(section => section.rows).flatMap(row => row.cells).flatMap(cell => cell.entries).find(entry => entry.skuId === sku.identity.skuId);
        if (!cell || !cell.editable) throw Error("该原 SKU 当前不可录入");
        if (warehouseIssue) {setMessage({type: "warning", text: warehouseIssue}); return;}
        if (!onAppend([{reference: lookup.inputReference(cell), sku, quantity, productName: ""}])) {setMessage({type: "error", text: "规格未追加，请核对仓库和数量"}); return;}
        setMessage({type: "info", text: `已追加原 SKU：${sku.product.sourceCode} · ${sku.color.name} · ${sku.column.name} · ${sku.fit.code}版`});
        setCode("");
      }
    } catch (issue) {setMessage({type: "error", text: issue instanceof Error ? issue.message : "扫码未完成"});}
  }
  return <Modal visible={visible} title="调拨扫码追加" footer={<Button onClick={onCancel}>关闭</Button>} closable onCancel={onCancel} maskClosable={false} unmountOnExit>
    <Space direction="vertical" size="medium" style={{width: "100%"}}>
      {warehouseIssue && <Alert type="warning" showIcon content={warehouseIssue} />}
      <Typography.Text type="secondary">唯一 SKU 条码直接按当前数量追加。商品级条码只定位商品；歧义和未知码不会生成明细。</Typography.Text>
      <label className="s05-transfer-field">本次追加数量<Input aria-label="扫码追加数量" inputMode="decimal" value={quantity} onChange={setQuantity} /></label>
      <Input.Search aria-label="调拨扫码" value={code} onChange={setCode} onSearch={scan} placeholder="扫描或输入已有条码后回车" searchButton="识别并追加" />
      {message && <Alert type={message.type} showIcon content={<Space wrap>{message.text}{productId && <Button size="small" onClick={() => onSelectProduct(productId)}>打开商品矩阵</Button>}</Space>} />}
    </Space>
  </Modal>;
}
