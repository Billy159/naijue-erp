// Shared Stage05 data and domain adapter; UI lives in legacy-rebuild.
export * from "@stage05/features/transfers/export";

import { transferDate, warehouseIds, type TransferDraft } from "./model";

/** The 8877 export action is available before any quantity is entered. */
export async function downloadEmptyTransferXlsx(draft: TransferDraft, number: string, names: ReadonlyMap<string, string>) {
  const { from, to } = warehouseIds(draft.header, draft.lines);
  const rows = [
    ["调拨单号", number, "状态", "未审核", "业务日期", transferDate(draft.header)],
    ["调出仓", names.get(from) || "未选择", "调入仓", names.get(to) || "未选择", "款数", "0", "颜色数", "0", "总数量", "0"],
    [],
    ["原始行ID", "款号", "商品", "颜色", "规格组", "当前尺码", "原尺码", "版型", "原SKU ID", "数量", "调出仓", "调入仓", "单号", "状态"],
    ["合计", "", "", "", "", "", "", "", "", "0"],
  ];
  const XLSX = await import("xlsx");
  const workbook = XLSX.utils.book_new();
  const worksheet = XLSX.utils.aoa_to_sheet(rows);
  worksheet["!cols"] = [18, 20, 22, 16, 15, 15, 16, 12, 39, 12, 24, 24, 24, 14].map(wch => ({ wch }));
  XLSX.utils.book_append_sheet(workbook, worksheet, "调拨明细");
  XLSX.writeFile(workbook, "transfer-unsaved.xlsx");
}
