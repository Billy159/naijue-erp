import React from "react";
import { createRoot } from "react-dom/client";
import "@arco-design/web-react/dist/css/arco.css";
import { LegacyRebuildApp } from "./app/App";

createRoot(document.getElementById("root")!).render(<React.StrictMode><LegacyRebuildApp /></React.StrictMode>);
