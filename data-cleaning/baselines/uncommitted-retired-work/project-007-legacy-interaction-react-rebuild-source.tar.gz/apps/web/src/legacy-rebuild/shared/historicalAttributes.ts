/** Same explicit source-category rule as the frozen 8877 real-data adapter. */
export function historicalYearSeason(attributes: Record<string, unknown> | null | undefined): {year: string | null; season: string | null} {
  const rawSource = attributes?.source as Record<string, unknown> | undefined;
  const category = String(rawSource?.["所属类别"] || attributes?.historicalCategory || "");
  const years = [...new Set(category.match(/(?:19|20)\d{2}/g) || [])];
  const seasons = ["春", "夏", "秋", "冬"].filter(value => category.includes(value));
  return {
    year: attributes?.year == null ? (years.length === 1 ? years[0]! : null) : String(attributes.year),
    season: attributes?.season == null ? (seasons.length ? seasons.join("、") : null) : String(attributes.season),
  };
}
