import react from "@vitejs/plugin-react";
import { fileURLToPath } from "node:url";
import { defineConfig } from "vite";

export default defineConfig({
  plugins: [react(), {
    name: "legacy-rebuild-entry",
    transformIndexHtml: {
      order: "pre",
      handler: html => html.replace(/src="\/src\/main\.tsx(?:\?[^\"]*)?"/, 'src="/src/legacy-rebuild/main.tsx"'),
    },
  }],
  resolve: { alias: { "@stage05": fileURLToPath(new URL("./src/stage05", import.meta.url)) } },
  build: { outDir: "dist-legacy" },
  server: {
    host: "127.0.0.1",
    port: 5184,
    strictPort: true,
    proxy: {
      "/stage05-api": {
        target: "http://127.0.0.1:8878",
        changeOrigin: true,
        rewrite: path => path.replace(/^\/stage05-api/, ""),
        cookiePathRewrite: { "/runtime/": "/stage05-api/runtime/" },
        configure: proxy => { proxy.on("proxyReq", request => request.setHeader("Origin", "http://127.0.0.1:8877")); },
      },
    },
  },
});
