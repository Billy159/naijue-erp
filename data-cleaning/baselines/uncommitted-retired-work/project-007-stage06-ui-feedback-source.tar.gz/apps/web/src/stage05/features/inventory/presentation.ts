import type { ReferenceRecord } from "../products/data";
import type { DisplaySizeGroup } from "../../shared/sku";
import { inventorySizeGroupLabel } from "../../shared/sku/businessSizes";
import type { InventoryMatrixSection, InventoryViewRow } from "./model";

export interface InventoryDisplaySettings {
  category:boolean;
  supplier:boolean;
  fit:boolean;
  sizeGroup:boolean;
  sizeGroupNote:boolean;
  season:boolean;
  colorSubtotal:boolean;
  productTotal:boolean;
}
export const DEFAULT_DISPLAY:InventoryDisplaySettings={category:false,supplier:false,fit:true,sizeGroup:false,sizeGroupNote:false,season:false,colorSubtotal:false,productTotal:true};

export interface InventoryStockDisplayRow {kind:"stock";key:string;stock:InventoryViewRow;section:InventoryMatrixSection;groupCount:number;firstInPage:boolean}
export interface InventorySubtotalDisplayRow {kind:"colorSubtotal"|"productTotal";key:string;stock:InventoryViewRow;section:InventoryMatrixSection;total:string}
export type InventoryDisplayRow=InventoryStockDisplayRow|InventorySubtotalDisplayRow;
export interface InventorySegment {key:string;title:string;historical:boolean;group:DisplaySizeGroup;rows:InventoryDisplayRow[]}

/** Every segment has its own size columns; a source row spanning groups keeps separate, signed group totals. */
export function inventorySegments(rows:readonly InventoryViewRow[],settings:InventoryDisplaySettings,collapsed:ReadonlySet<string>):InventorySegment[] {
  const groups=new Map<string,DisplaySizeGroup>();
  for(const row of rows)for(const section of row.sections)groups.set(section.group.name,section.group);
  const completeProducts=new Set(rows.filter(row=>row.productEnd).map(row=>row.code));
  const completeColors=new Set(rows.filter(row=>row.colorEnd).map(row=>`${row.code}\u0000${row.colorId}`));
  return [...groups.values()].sort((a,b)=>{
    const left=inventorySizeGroupLabel(a.name),right=inventorySizeGroupLabel(b.name);
    return left.order-right.order||Number(left.historical)-Number(right.historical)||a.name.localeCompare(b.name,"zh-CN");
  }).map(group=>{
    const scoped=rows.flatMap(stock=>stock.sections.filter(section=>section.group.name===group.name).map(section=>({stock,section})));
    const counts=new Map<string,number>(),lastProduct=new Map<string,number>(),lastColor=new Map<string,number>();
    scoped.forEach(({stock},index)=>{
      counts.set(stock.code,(counts.get(stock.code)||0)+1);
      lastProduct.set(stock.code,index);
      lastColor.set(`${stock.code}\u0000${stock.colorId}`,index);
    });
    const seen=new Set<string>(),displayRows:InventoryDisplayRow[]=[];
    scoped.forEach(({stock,section},index)=>{
      const first=!seen.has(stock.code);seen.add(stock.code);
      const folded=collapsed.has(stock.code);
      if(!folded||first)displayRows.push({kind:"stock",key:`stock:${group.name}:${stock.key}`,stock,section,groupCount:counts.get(stock.code)||1,firstInPage:first});
      const colorKey=`${stock.code}\u0000${stock.colorId}`;
      if(!folded&&settings.colorSubtotal&&lastColor.get(colorKey)===index&&completeColors.has(colorKey))
        displayRows.push({kind:"colorSubtotal",key:`color:${group.name}:${stock.key}`,stock,section,total:section.colorTotal});
      if(settings.productTotal&&lastProduct.get(stock.code)===index&&completeProducts.has(stock.code))
        displayRows.push({kind:"productTotal",key:`product:${group.name}:${stock.key}`,stock,section,total:section.productTotal});
    });
    const label=inventorySizeGroupLabel(group.name);
    return {key:group.name,title:label.historical?`${label.title}（历史规格）`:label.title,historical:label.historical,group,rows:displayRows};
  });
}

export interface CategoryNode {key:string;title:string;children?:CategoryNode[]}
/** A parent category includes its own directly attached products and all descendants. */
export function categoryScope(code:string,categories:readonly ReferenceRecord[]):string[] {
  if(!code)return [];
  const root=categories.find(row=>row.code===code);
  if(!root)throw Error("分类筛选身份不存在");
  const found=[code],visited=new Set(found);
  for(let index=0;index<found.length;index++)for(const row of categories){
    if(!row.code||visited.has(row.code))continue;
    if(row.parent_code===found[index]||row.parent_id===categories.find(parent=>parent.code===found[index])?.id){
      visited.add(row.code);found.push(row.code);
    }
  }
  return found;
}
export function inventoryCategoryTree(categories:readonly ReferenceRecord[]):CategoryNode[] {
  const byCode=new Map(categories.filter(row=>row.code).map(row=>[row.code!,{key:row.code!,title:row.name||row.code!,children:[] as CategoryNode[]}]));
  const codeById=new Map(categories.filter(row=>row.code).map(row=>[row.id,row.code!]));
  const roots:CategoryNode[]=[];
  for(const row of categories){
    if(!row.code)continue;
    const node=byCode.get(row.code)!;
    const parentCode=row.parent_code||codeById.get(row.parent_id||"");
    const parent=parentCode?byCode.get(parentCode):null;
    if(parent&&parent!==node)parent.children!.push(node);else roots.push(node);
  }
  return roots;
}
