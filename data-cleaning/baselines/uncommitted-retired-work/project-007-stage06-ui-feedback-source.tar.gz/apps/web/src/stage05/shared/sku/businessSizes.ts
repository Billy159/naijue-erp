export interface BusinessSizeGroup { key: string; name: string; sizes: readonly string[] }

/** Current selectable business groups; historical SKU display columns are kept separately. */
export const BUSINESS_SIZE_GROUPS: readonly BusinessSizeGroup[] = [
  { key: "upper", name: "上衣尺码", sizes: ["160/XS", "165/S", "170/M", "175/L", "180/XL", "185/2XL", "190/3XL", "195/4XL", "200/5XL", "205/6XL", "无尺码"] },
  { key: "pants", name: "裤子尺码", sizes: ["29", "30", "31", "32", "33", "34", "35", "36", "38", "40", "无尺码"] },
  { key: "shoes", name: "鞋码", sizes: ["38", "39", "40", "41", "42", "43", "44"] },
  { key: "kids", name: "童装尺码", sizes: ["90", "100", "110", "120", "130", "140"] },
  { key: "accessories", name: "配饰均码", sizes: ["无尺码", "均码"] },
];

/** Exact, presentation-only aliases for the four verified S1 groups. No SKU or size is remapped here. */
const projectionGroups: Readonly<Record<string, { businessKey: string; historical: boolean }>> = {
  "2026年男装上衣尺码组": { businessKey: "upper", historical: false },
  "男装裤子尺码组": { businessKey: "pants", historical: false },
  "女装上衣尺码组1": { businessKey: "upper", historical: true },
  "女装西裤尺码组2": { businessKey: "pants", historical: true },
};

export function inventorySizeGroupLabel(projectionName: string): { title: string; order: number; historical: boolean } {
  const alias = projectionGroups[projectionName];
  if (!alias) return { title: "历史尺码", order: BUSINESS_SIZE_GROUPS.length, historical: true };
  const order = BUSINESS_SIZE_GROUPS.findIndex(group => group.key === alias.businessKey);
  return { title: BUSINESS_SIZE_GROUPS[order]!.name, order, historical: alias.historical };
}
